'use strict';

const Utils = {}

Utils.copyText = () => {
	const that = this;
    const isHTMLElement = that instanceof HTMLElement;
    const isHTMLInputElement = that instanceof HTMLInputElement;
    const isHTMLTextAreaElement = that instanceof HTMLTextAreaElement;
    let data = '';
    if (isHTMLInputElement || isHTMLTextAreaElement) {
      that.focus();
      that.select();
      data = that.value;
    } else if (isHTMLElement) {
      const selection = self.getSelection();
      const range = document.createRange();
      range.selectNodeContents(that);
      selection.removeAllRanges();
      selection.addRange(range);
      data = that.textContent;
    } else return Promise.reject(new Error('未知错误'));
    if (navigator.clipboard) return navigator.clipboard.writeText(data);
    return Promise[document.execCommand('copy') ? 'resolve' : 'reject']();
}

Utils.setText = (str = '') => {
    const that = this;
    const isHTMLElement = that instanceof HTMLElement;
    const isHTMLInputElement = that instanceof HTMLInputElement;
    const isHTMLTextAreaElement = that instanceof HTMLTextAreaElement;
    if (isHTMLInputElement || isHTMLTextAreaElement) that.value = str;
    else if (isHTMLElement) that.textContent = str;
    else return Promise.reject(new Error('未知错误'));
    return Promise.resolve();
}

Utils.formatDate = (locales = navigator.language, options = {}) => {
    const options1 = { dateStyle: 'medium', ...options };
    const b = new Intl.DateTimeFormat(locales, options1);
    const c = b.resolvedOptions();
    for (const i in options1) {
      if (options1[i] === c[i]) continue;
      return time => {
        const d = new Date(time * 1e3);
        return `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日`;
      };
    }
    return time => b.format(time * 1e3);
  },
  
Utils.loadJS = str => new Promise(resolve => {
    const script = document.createElement('script');
    script.onload = resolve;
    script.onerror = resolve;
    try {
      const url = new URL(str);
      script.src = url.href;
      script.crossOrigin = 'anonymous';
    } catch (_) {
      script.textContent = String(str);
    }
    document.head.appendChild(script);
 })
 
Utils.lazyload = (func, ...args) => {
    if (document.readyState === 'complete') return func(...args);
    return new Promise(resolve => {
      self.addEventListener('load', () => resolve(func(...args)), { once: true });
    });
 }

Utils.escapeHTML = (str) => {
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;');
}

Utils.randomUUID = (separator = '-') => {
    let uuid = '';
    if (typeof crypto.randomUUID === 'function') uuid = crypto.randomUUID();
	else {
      const url = URL.createObjectURL(new Blob());
      uuid = url.slice(url.lastIndexOf('/') + 1);
      URL.revokeObjectURL(url);
    }
    return uuid.replace(/-/g, separator);
}

self.Utils = Utils; // export for iOS 14- qwq

// font
(function () {
    const fontLoader = {
		load(familyName, {...options} = {}) {
            const fn = String(familyName).replace('+', ' ');
            const alt = options.alt == null ? fn : String(options.alt);
            if (!fn) throw new SyntaxError('Missing family name');
            const sarr = ['Google', 'Baomitu', 'Local'];
            return new Promise((resolve, reject) => {
                let index = sarr.length;
                const err = new DOMException('The requested font families are not available.', 'Missing font family');
                for (const i of sarr.map(e => this.loadFonts(fn, {alt, from: e}))) Promise.resolve(i).then(resolve, _ => !--index && reject(err));
            });
        },
        async loadFonts(familyName, {...options} = {}) {
            const from = options.from == null ? 'Unknown' : String(options.from);
            const alt = options.alt == null ? familyName : String(options.alt);
            const csst = await this.getFonts(familyName, {alt, from}).catch(_ => []);
            return new Promise((resolve, reject) => {
                Promise.all(csst.map(a => a.load())).then(a => {
                    if (!a.length) {
                        reject(new DOMException('The requested font families are not available.', 'Missing font family'));
                        return
                    }
                    resolve(Object.assign(a, {qwq: from}));
                }, reject);
            });
        },
        async getFonts(name = 'Noto Sans SC', {...options} = {}) {
            const style = options.style == null ? 'Normal' : String(options.style);
            const weight = options.weight == null ? 'Regular' : String(options.weight);
            const from = options.from == null ? 'Unknown' : String(options.from);
            const alt = options.alt == null ? name : String(options.alt);
            const fn = name.replace('+', ' ');
            const sn = style.replace('+', ' ');
            const wn = weight.replace('+', ' ');
            if (!fn) throw new SyntaxError('Missing family name');
            const f1 = fn.toLocaleLowerCase().split(' ').join('-');
            const f2 = fn.replace(' ', '');
            const f3 = fn.split(' ').join('+');
            const s1 = sn.toLocaleLowerCase();
            const w1 = wn.toLocaleLowerCase();
            switch (from) {
            case 'Google': {
                const u0 = './src/fonts/css.css';
                const text = await fetch(u0).then(a => a.text(), _ => '');
                const rg0 = (text.match(/@font-face {.+?}/gs) || []).map(a => a.slice(12, -1));
                const rg = rg0.map(a => Object.fromEntries(a.split(';').filter(b => b.trim()).map(c => c.split(': ').map(d => d.trim()))));
                return rg.map(a => new FontFace(alt || a['font-family'], a.src, {style: a['font-style'], weight: a['font-weight'], unicodeRange: a['unicode-range']}));
            }
            case 'Baomitu': {
                const u0 = `./src/fonts/${f1}-${w1}`;
                const source = [`url('${u0}.woff2')format('woff2')`, `url('${u0}.woff')format('woff')`, `url('${u0}.ttf')format('truetype')`];
                return [new FontFace(alt, source.join())];
            }
            case 'Local': {
                return [new FontFace(alt, `local('${fn}'),local('${f2}-${sn}')`)];
            }
            default:
				return [];
			}
        }
    };
    Utils.addFont = (...args) => fontLoader.load(...args).then(i => i.forEach(a => document.fonts.add(a)));
}());

const _ = localStorage;
if (String(_.setItem) === 'function (a,b){}') delete _.setItem;
if (String(_.getItem) === 'function (a){return null}') delete _.getItem;
if (String(_.removeItem) === 'function (a){}') delete _.removeItem;
if (String(_.clear) === 'function (){}') delete _.clear
if (String(_.key) === 'function (a){return null}') delete _.key;

Utils.lazyload(() => {
	const fd = Utils.formatDate(navigator.language);
	const w = `作者：<a style="text-decoration:underline"target="_blank"href="https://space.bilibili.com/274753872">lchz\x683\x3473</a>`;
	const a = `修改：<a style="text-decoration:underline"target="_blank"href="https://space.bilibili.com/305797550">memzzmem</a>`;
	const b = `背景模糊/暂停相关(<a style="text-decoration:underline"target="_blank" href="//kev1nweng.gitlab.io/phisim-newui/">phisim-newui</a>)：<a style="text-decoration:underline"target="_blank" href="//space.bilibili.com/544365132">kev1nweng</a>，<a style="text-decoration:underline" target="_blank" href="//space.bilibili.com/295247346">scar922</a>`;
	document.title = `${self._i[0]} - lchz\x683\x3473制作`;
	for (const i of document.querySelectorAll('.title')) i.innerHTML = `${self._i[0]}&nbsp;<small>v${self._i[1].join('.')}</small>`;
	for (const i of document.querySelectorAll('.info')) i.innerHTML = `${w}&nbsp;${a}&nbsp;<br>${b}&nbsp;<br><br>最后更新于${fd(self._i[3])}`;
	for (const i of document.querySelectorAll('.main')) i.style.display = 'block';
	return undefined;
});



window.Interact = class Interact {
  /** @param {HTMLElement} element */
  constructor(element) {
    this.element = element;
    /** @type {any[]} */
    this.callbacks = [];
  }
  /**
   * @typedef {object} MouseCallbacks
   * @property {(ev:MouseEvent)=>void} [mousedownCallback]
   * @property {(ev:MouseEvent)=>void} [mousemoveCallback]
   * @property {(ev:MouseEvent)=>void} [mouseupCallback]
   * @property {(ev:MouseEvent)=>void} [mouseoutCallback]
   * @param {MouseCallbacks} param0
   */
  setMouseEvent({
    mousedownCallback = function() {},
    mousemoveCallback = function() {},
    mouseupCallback = function() {},
    mouseoutCallback = function() {}
  }) {
    /** @type {(ev:MouseEvent)=>void} */
    const mousedown = evt => {
      evt.preventDefault();
      mousedownCallback(evt);
    };
    // 踩坑：对move和up进行preventDefault会影响input元素交互
    /** @type {(ev:MouseEvent)=>void} */
    const mousemove = evt => {
      // 踩坑：新版浏览器按下鼠标即使不移动也会定期触发mousemove事件
      if (!evt.movementX && !evt.movementY) return;
      mousemoveCallback(evt);
    };
    /** @type {(ev:MouseEvent)=>void} */
    const mouseup = evt => {
      mouseupCallback(evt);
    };
    /** @type {(ev:MouseEvent)=>void} */
    const mouseout = evt => {
      mouseoutCallback(evt);
    };
    this.element.addEventListener('mousedown', mousedown);
    self.addEventListener('mousemove', mousemove);
    self.addEventListener('mouseup', mouseup);
    this.element.addEventListener('mouseout', mouseout);
    return this.callbacks.push({ mousedown, mousemove, mouseup, mouseout });
  }
  /** @param {number} id */
  clearMouseEvent(id) {
    const { mousedown, mousemove, mouseup, mouseout } = this.callbacks[id - 1];
    this.element.removeEventListener('mousedown', mousedown);
    self.removeEventListener('mousemove', mousemove);
    self.removeEventListener('mouseup', mouseup);
    this.element.removeEventListener('mouseout', mouseout);
    this.callbacks[id - 1] = null;
  }
  /**
   * @typedef {object} TouchCallbacks
   * @property {(ev:TouchEvent)=>void} [touchstartCallback]
   * @property {(ev:TouchEvent)=>void} [touchmoveCallback]
   * @property {(ev:TouchEvent)=>void} [touchendCallback]
   * @property {(ev:TouchEvent)=>void} [touchcancelCallback]
   * @param {TouchCallbacks} param0
   */
  setTouchEvent({
    touchstartCallback = function() {},
    touchmoveCallback = function() {},
    touchendCallback = function() {},
    touchcancelCallback = function() {}
  }) {
    const passive = { passive: false }; // warning
    /** @type {(ev:TouchEvent)=>void} */
    const touchstart = evt => {
      evt.preventDefault();
      touchstartCallback(evt);
    };
    /** @type {(ev:TouchEvent)=>void} */
    const touchmove = evt => {
      evt.preventDefault();
      touchmoveCallback(evt);
    };
    /** @type {(ev:TouchEvent)=>void} */
    const touchend = evt => {
      evt.preventDefault();
      touchendCallback(evt);
    };
    /** @type {(ev:TouchEvent)=>void} */
    const touchcancel = evt => {
      evt.preventDefault();
      touchcancelCallback(evt);
    };
    this.element.addEventListener('touchstart', touchstart, passive);
    this.element.addEventListener('touchmove', touchmove, passive);
    this.element.addEventListener('touchend', touchend);
    this.element.addEventListener('touchcancel', touchcancel);
    return this.callbacks.push({ touchstart, touchmove, touchend, touchcancel });
  }
  /** @param {number} id */
  clearTouchEvent(id) {
    const { touchstart, touchmove, touchend, touchcancel } = this.callbacks[id - 1];
    this.element.removeEventListener('touchstart', touchstart);
    this.element.removeEventListener('touchmove', touchmove);
    this.element.removeEventListener('touchend', touchend);
    this.element.removeEventListener('touchcancel', touchcancel);
    this.callbacks[id - 1] = null;
  }
  /**
   * @typedef {object} KeyboardCallbacks
   * @property {(ev:KeyboardEvent)=>void} [keydownCallback]
   * @property {(ev:KeyboardEvent)=>void} [keyupCallback]
   * @param {KeyboardCallbacks} param0
   */
  setKeyboardEvent({
    keydownCallback = function() {},
    keyupCallback = function() {}
  }) {
    const isInput = () => {
      const elem = document.activeElement;
      if (elem instanceof HTMLTextAreaElement) return true;
      if (elem instanceof HTMLInputElement) {
        const type = elem.getAttribute('type') || '';
        if (/^(button|checkbox|image|radio|reset|submit)$/.test(type)) return false;
        return true;
      }
      if (elem.contentEditable === 'true') return true;
      return false;
    };
    /** @type {(ev:KeyboardEvent)=>void} */
    const keydown = evt => {
      if (isInput()) return;
      evt.preventDefault();
      keydownCallback(evt);
    };
    /** @type {(ev:KeyboardEvent)=>void} */
    const keyup = evt => {
      if (isInput()) return;
      evt.preventDefault();
      keyupCallback(evt);
    };
    self.addEventListener('keydown', keydown);
    self.addEventListener('keyup', keyup);
    return this.callbacks.push({ keydown, keyup });
  }
  /** @param {number} id */
  clearKeyboardEvent(id) {
    const { keydown, keyup } = this.callbacks[id - 1];
    self.removeEventListener('keydown', keydown);
    self.removeEventListener('keyup', keyup);
    this.callbacks[id - 1] = null;
  }
}
window.InteractProxy = class InteractProxy {
  /** @param {HTMLElement} element */
  constructor(element) {
    this.interact = new Interact(element);
    this.mouseEvent = null;
    this.touchEvent = null;
    this.keyboardEvent = null;
    this.mouseEventId = 0;
    this.touchEventId = 0;
    this.keyboardEventId = 0;
  }
  /** @param {MouseCallbacks} callbacks */
  setMouseEvent(callbacks) {
    this.mouseEvent = callbacks;
  }
  /** @param {TouchCallbacks} callbacks */
  setTouchEvent(callbacks) {
    this.touchEvent = callbacks;
  }
  /** @param {KeyboardCallbacks} callbacks */
  setKeyboardEvent(callbacks) {
    this.keyboardEvent = callbacks;
  }
  activate() {
    if (this.mouseEvent) this.mouseEventId = this.interact.setMouseEvent(this.mouseEvent);
    if (this.touchEvent) this.touchEventId = this.interact.setTouchEvent(this.touchEvent);
    if (this.keyboardEvent) this.keyboardEventId = this.interact.setKeyboardEvent(this.keyboardEvent);
  }
  deactive() {
    if (this.mouseEventId) this.interact.clearMouseEvent(this.mouseEventId);
    if (this.touchEventId) this.interact.clearTouchEvent(this.touchEventId);
    if (this.keyboardEventId) this.interact.clearKeyboardEvent(this.keyboardEventId);
  }
}
