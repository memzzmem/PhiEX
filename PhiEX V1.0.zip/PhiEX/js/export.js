const e = hook.define({
    name: "Export",
    description: "Export Chart as JSON",
    contents: [{
            type: "command",
            meta: ["/dl", function () {
                    if (!hook.app.chart)
                        return void hook.toast("请先播放谱面");
                    const e = document.createElement("a"),
                    o = JSON.stringify(function (e) {
                        const o = {
                            formatVersion: 3,
                            offset: e.offset,
                            numOfNotes: e.numOfNotes,
                            judgeLineList: []
                        };
                        for (const n of e.judgeLineList) {
                            const e = {
                                numOfNotes: n.numOfNotes,
                                numOfNotesAbove: n.numOfNotesAbove,
                                numOfNotesBelow: n.numOfNotesBelow,
                                bpm: n.bpm,
                                speedEvents: [],
                                notesAbove: [],
                                notesBelow: [],
                                judgeLineDisappearEvents: [],
                                judgeLineMoveEvents: [],
                                judgeLineRotateEvents: []
                            };
                            for (const o of n.speedEvents) {
                                if (o.startTime === o.endTime)
                                    continue;
                                const n = {};
                                n.startTime = o.startTime,
                                n.endTime = o.endTime,
                                n.value = t(o.value),
                                n.floorPosition = t(o.floorPosition),
                                e.speedEvents.push(n)
                            }
                            for (const o of n.notesAbove) {
                                const n = {};
                                n.type = o.type,
                                n.time = o.time,
                                n.positionX = t(o.positionX),
                                n.holdTime = o.holdTime,
                                n.speed = t(o.speed),
                                n.floorPosition = t(o.floorPosition),
                                e.notesAbove.push(n)
                            }
                            for (const o of n.notesBelow) {
                                const n = {};
                                n.type = o.type,
                                n.time = o.time,
                                n.positionX = t(o.positionX),
                                n.holdTime = o.holdTime,
                                n.speed = t(o.speed),
                                n.floorPosition = t(o.floorPosition),
                                e.notesBelow.push(n)
                            }
                            for (const o of n.judgeLineDisappearEvents) {
                                if (o.startTime === o.endTime)
                                    continue;
                                const n = {};
                                n.startTime = o.startTime,
                                n.endTime = o.endTime,
                                n.start = t(o.start),
                                n.end = t(o.end),
                                e.judgeLineDisappearEvents.push(n)
                            }
                            for (const o of n.judgeLineMoveEvents) {
                                if (o.startTime === o.endTime)
                                    continue;
                                const n = {};
                                n.startTime = o.startTime,
                                n.endTime = o.endTime,
                                n.start = t(o.start),
                                n.end = t(o.end),
                                n.start2 = t(o.start2),
                                n.end2 = t(o.end2),
                                e.judgeLineMoveEvents.push(n)
                            }
                            for (const o of n.judgeLineRotateEvents) {
                                if (o.startTime === o.endTime)
                                    continue;
                                const n = {};
                                n.startTime = o.startTime,
                                n.endTime = o.endTime,
                                n.start = t(o.start),
                                n.end = t(o.end),
                                e.judgeLineRotateEvents.push(n)
                            }
                            o.judgeLineList.push(e)
                        }
                        return o
                    }
                            (hook.app.chart));
                    e.href = URL.createObjectURL(new Blob([o], {
                                type: "application/json"
                            })),
                    e.download = `chart_${Date.now()}.json`,
                    e.click()
                }
            ]
        }
    ]
});
function t(e) {
    const t = Math.fround(e);
    if (!isFinite(t))
        return null;
    for (let e = 1; e < 1e3; e++) {
        const o = t.toPrecision(e),
        n = Number(o);
        if (Math.fround(n) === t) {
            if (3 !== parseFloat(o.slice(-1)))
                return n;
            const e = parseFloat(o.slice(0, -1) + 2);
            return t - e == n - t && Math.fround(e) === t ? e : n
        }
    }
    throw new Error("frix error")
}
export {
    e as default
};