const t = hook.define({
    name: "PhiZone",
    description: "PhiZone API",
    contents: [{
            type: "command",
            meta: ["/pz", p]
        }, {
            type: "command",
            meta: ["/pzs", p]
        }, {
            type: "command",
            meta: ["/pzc", async function (t) {
                    const a = t || h("请输入谱面ID");
                    if ("" === a || null == a)
                        return void f("未输入谱面ID，已取消操作");
                    const n = await async function (t) {
                        e("等待服务器响应...");
                        const a = await fetch(s(0 | t));
                        if (!a.ok)
                            throw new Error(`${a.status} ${a.statusText}`);
                        const n = ((await a.json()).data || [])[0];
                        if (!n || !n.file)
                            return {
                                charts: []
                            };
                        const r = await fetch(o(n.songId));
                        if (!r.ok)
                            throw new Error(`${r.status} ${r.statusText}`);
                        return g([n], (await r.json()).data)
                    }
                    (a).catch(d);
                    if (console.log(n), n) {
                        if (!n.charts.length)
                            return void w(a);
                        await $(n)
                    }
                }
            ]
        }, {
            type: "command",
            meta: ["/random", async function () {
                    const t = await async function () {
                        e("等待服务器响应...");
                        const t = await fetch(u());
                        if (!t.ok)
                            throw new Error(`${t.status} ${t.statusText}`);
                        const a = (await t.json()).data,
                        n = await fetch(o(a.songId));
                        if (!n.ok)
                            throw new Error(`${n.status} ${n.statusText}`);
                        return g([a], (await n.json()).data)
                    }
                    ().catch(d);
                    if (console.log(t), t) {
                        if (!t.charts.length)
                            return void w("<random>");
                        await $(t)
                    }
                }
            ]
        }
    ]
}), {
    sendText: e,
    uploader: a
} = hook, n = "https://api.phizone.cn", o = (t = "") => `${n}/songs/${t}/`, r = (t = 0) => `${n}/songs/?perpage=1&page=${t}`, s = (t = 0) => `${n}/charts/?perpage=1&page=${t}`, c = (t = "") => `${n}/songs/${t}/charts/`, i = (t = "") => `${n}/charts/${t}/assets/?perpage=-1`, u = () => `${n}/charts/random/?rangeFormat=0&rangeFormat=1`, l = "PhiZone API v0.9.0", h = t => prompt(`${l}\n${t}`), f = t => hook.toast(`${l}\n${t}`), d = t => {
    f(`无法连接至服务器\n错误代码：${t.message}`),
    e("无法连接至服务器")
}, w = t => {
    f(`歌曲ID ${t} 对应的谱面不存在`),
    e(`歌曲ID ${t} 对应的谱面不存在`)
};
async function p(t) {
    const a = t || h("请输入歌曲ID");
    if ("" === a || null == a)
        return void f("未输入歌曲ID，已取消操作");
    const n = await async function (t) {
        e("等待服务器响应...");
        const a = await fetch(r(0 | t));
        if (!a.ok)
            throw new Error(`${a.status} ${a.statusText}`);
        const n = ((await a.json()).data || [])[0];
        if (!n)
            return {
                charts: []
            };
        const o = await fetch(c(n.id));
        if (!o.ok)
            throw new Error(`${o.status} ${o.statusText}`);
        return g(((await o.json()).data || []).filter((t => t.file)), n)
    }
    (a).catch(d);
    if (console.log(n), n) {
        if (!n.charts.length)
            return void w(a);
        await $(n)
    }
}
async function g(t, e) {
    console.log("getData::base", ...t),
    console.log("getData::song", e);
    for (const e of t) {
        const t = await fetch(i(e.id));
        if (!t.ok)
            throw new Error(`${t.status} ${t.statusText}`);
        const a = (await t.json()).data || [];
        a.length && console.log("getData::assets", ...a),
        e.assets = a.map((t => ({
                        name: t.name,
                        url: t.file
                    })))
    }
    return {
        charts: t.map((t => ({
                    id: t.id,
                    chart: t.file,
                    level: `${t.level} Lv.${0|t.difficulty}`,
                    charter: t.authorName.replace(/\[PZUser:\d+:([^\]]+?)(:PZRT)?\]/g, "$1"),
                    assets: t.assets
                }))),
        composer: e.authorName,
        illustration: e.illustration,
        illustrator: e.illustrator,
        name: e.title,
        song: e.file
    }
}
async function $(t) {
    const {
        charts: n
    } = t,
    o = [t.song, t.illustration];
    for (const t of n) {
        t.chart && o.push(t.chart);
        for (const e of t.assets)
            o.push(e.url)
    }
    const r = new m,
    s = t => decodeURIComponent(t.match(/[^/]+$/)[0]);
    e("获取资源列表..."),
    await r.add(o, (({
                url: t,
                status: e,
                statusText: a
            }) => {
            f(`资源 '${s(t)}' 加载失败\n错误代码：${e} ${a}`)
        })),
    await r.start(a.fireProgress.bind(a));
    const c = async(t, e) => {
        const n = await r.getData(t) || new ArrayBuffer(0);
        a.fireLoad({
            name: e
        }, n)
    };
    await c(t.song, s(t.song)),
    await c(t.illustration, s(t.illustration));
    for (let e = 0; e < n.length; e++) {
        const o = n[e];
        for (const t of o.assets)
            await c(t.url, t.name);
        await c(o.chart, s(o.chart));
        const r = new TextEncoder,
        i = y(o.id),
        u = `\n      #\n      Name: ${t.name}\n      Song: ${s(t.song)}\n      Picture: ${s(t.illustration)}\n      Chart: ${s(o.chart)}\n      Level: ${o.level}\n      Composer: ${t.composer}\n      Charter: ${o.charter}\n      Illustrator: ${t.illustrator}\n      Offset: ${i}\n    `,
        l = r.encode(u);
        a.fireLoad({
            name: "info.txt"
        }, l.buffer)
    }
}
function m() {
    this.xhrs = Object.create(null)
}
function y(t) {
    return "2eb9e940-4350-4509-a244-068abd937f44" === t ? -50 : 0
}
m.prototype.add = function (t = [], e = t => {}) {
    return Promise.all(t.filter((t => !this.xhrs[t])).map((async t => {
                try {
                    const e = await async function (t) {
                        try {
                            const e = await fetch(t, {
                                method: "HEAD"
                            }).catch((() => {
                                        throw Object.assign(new Error, {
                                            url: t,
                                            status: 0,
                                            statusText: "Network Error"
                                        })
                                    })),
                            a = e.headers.get("content-length");
                            if (null == a)
                                throw new Error("No Content-Length Header");
                            if (e.ok)
                                return Number(a)
                        } catch {
                            const e = await fetch(t, {
                                method: "GET"
                            }).catch((() => {
                                        throw Object.assign(new Error, {
                                            url: t,
                                            status: 0,
                                            statusText: "Network Error"
                                        })
                                    }));
                            if (e.body.cancel(), !e.ok)
                                throw Object.assign(new Error, {
                                    url: t,
                                    status: e.status,
                                    statusText: e.statusText
                                });
                            return Number(e.headers.get("content-length")) || 0
                        }
                        throw Object.assign(new Error, {
                            url: t,
                            status: 0,
                            statusText: "Unknown Error"
                        })
                    }
                    (t);
                    this.xhrs[t] = {
                        event: {
                            loaded: 0,
                            total: e
                        }
                    }
                } catch (t) {
                    e(t)
                }
            })))
}, m.prototype.start = function (t = (...t) => {}) {
    const e = Object.entries(this.xhrs);
    return Promise.all(e.map((([e, a]) => function (t, e = t => {}) {
                return new Promise(((a, n) => {
                        const o = new XMLHttpRequest;
                        o.open("GET", t, !0),
                        o.responseType = "arraybuffer",
                        o.onprogress = e,
                        o.onload = t => (200 === o.status ? a : n)(t),
                        o.onerror = n,
                        o.send()
                    }))
            }
                (e, (e => {
                        a.event = e,
                        t(this.loaded, this.total)
                    })).then((t => a.event = t)).catch((t => a.event = t)))))
}, m.prototype.getData = function (t) {
    if (!this.xhrs[t])
        return null;
    const {
        event: e
    } = this.xhrs[t];
    return e.loaded >= e.total ? e.target.response : null
}, Object.defineProperty(m.prototype, "loaded", {
    get() {
        return Object.values(this.xhrs).reduce(((t, e) => t + e.event.loaded), 0)
    }
}), Object.defineProperty(m.prototype, "total", {
    get() {
        return Object.values(this.xhrs).reduce(((t, e) => t + Math.max(e.event.loaded, e.event.total)), 0)
    }
});
export {
    t as default
};