const e = hook.define({
    name: "Video Recorder",
    description: "Record video",
    contents: [{
            type: "config",
            meta: ["启用视频录制", function (e, t) {
                    if (!s.checkSupport())
                        return e.checked = !1, t.classList.add("disabled"), void(t.querySelector("label").textContent += "(当前设备或浏览器不支持)");
                    e.addEventListener("change", (() => {
                            e.checked ? (s.createUI(), hook.before.set("video", (() => {
                                        o = !0,
                                        n || a()
                                    })), hook.end.set("video", (() => {
                                        i && a(),
                                        o = !1
                                    }))) : (s.destroyUI(), hook.before.delete("video"), hook.end.delete("video"))
                        })),
                    hook.status.reg("enableVideoRecorder", e)
                }
            ]
        }
    ]
}), t = e => hook.toast(e);
let o = !1, n = !1, i = !1;
const s = {
    container: null,
    createUI() {
        this.container || (this.container = document.createElement("div"), this.container.textContent = "", Object.assign(this.container.style, {
                background: "rgb(139, 195, 74)",
                color: "rgb(240, 241, 254)",
                borderRadius: "2vmin",
                padding: "1vmin",
                zIndex: "150",
                position: "absolute",
                fontFamily: '"Material Icons"',
                fontSize: "4vmin",
                opacity: "0.8",
                lineHeight: "initial",
                left: "100px",
                top: "100px"
            }), this.container.addEventListener("mousedown", (e => {
                    e.preventDefault();
                    let t = !1;
                    setTimeout((() => {
                            !t && !i && c(),
                            t = !0
                        }), 500);
                    const o = d(this.container, e, (() => t = !0));
                    window.addEventListener("mousemove", o),
                    window.addEventListener("mouseup", (() => {
                            window.removeEventListener("mousemove", o),
                            t || a(),
                            t = !0
                        }), {
                        once: !0
                    })
                })), this.container.addEventListener("touchstart", (e => {
                    e.preventDefault();
                    let t = !1;
                    setTimeout((() => {
                            !t && !i && c(),
                            t = !0
                        }), 500);
                    const o = d(this.container, e, (() => t = !0));
                    window.addEventListener("touchmove", o, {
                        passive: !1
                    }),
                    window.addEventListener("touchend", (() => {
                            window.removeEventListener("touchmove", o),
                            t || a(),
                            t = !0
                        }), {
                        once: !0
                    })
                })), hook.app.stage.appendChild(this.container))
    },
    destroyUI() {
        this.container && (this.container.remove(), this.container = null)
    },
    msdest: null,
    chunks: [],
    objectURL: null,
    fileName: null,
    fileSize: null,
    checkSupport() {
        const e = (self.AudioContext || self.webkitAudioContext).prototype.createMediaStreamDestination,
        t = HTMLCanvasElement.prototype.captureStream,
        o = self.MediaRecorder;
        return e && t && o
    },
    record() {
        const {
            audio: {
                actx: e
            },
            app: {
                canvas: o
            }
        } = hook;
        this.msdest || (this.msdest = e.createMediaStreamDestination()),
        hook.audio.msdest = this.msdest;
        const n = ["video/mp4;codecs=avc1", "video/mp4;codecs=mp4a", "video/webm;codecs=vp9,pcm", "video/webm;codecs=vp8,pcm", "video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus"].find((e => MediaRecorder.isTypeSupported(e))),
        s = o.captureStream(),
        a = this.msdest.stream,
        d = new MediaStream([s.getVideoTracks()[0], a.getAudioTracks()[0]]);
        try {
            const e = new MediaRecorder(d, {
                videoBitsPerSecond: 2e7,
                mimeType: n || ""
            });
            e.ondataavailable = e => e.data && e.data.size && this.chunks.push(e.data),
            e.onstop = () => {
                if (s.getTracks().forEach((e => e.stop())), this.chunks.length) {
                    this.objectURL && (URL.revokeObjectURL(this.objectURL), this.objectURL = null);
                    const t = new Blob(this.chunks, {
                        type: e.mimeType
                    });
                    this.objectURL = URL.createObjectURL(t),
                    this.fileName = `${Math.floor(Date.now()/1e3)}.${n.match(/\/(.+)?;/)[1]}`,
                    this.fileSize = t.size,
                    this.chunks.length = 0,
                    c()
                } else
                    t("Recording Failed: No Data Available")
            },
            e.start(),
            i = !0,
            this.stop = () => {
                e.stop(),
                i = !1
            }
        } catch (e) {
            t(`Recording Failed: ${e.message}`)
        }
    },
    stop() {}
};
function a() {
    o ? i ? (s.container.style.background = "rgb(139, 195, 74)", s.stop()) : (s.container.style.background = "rgb(195, 75, 79)", s.record()) : (n = !n, s.container.textContent = n ? "" : "")
}
function c() {
    const e = hook.fireModal("<p>录制预览</p>", ""),
    t = s.objectURL;
    if (!t)
        return void(e.innerHTML = "<p>当前无可用数据</p>");
    const o = document.createElement("video");
    o.style.width = "100%",
    o.src = t,
    o.controls = !0,
    e.appendChild(o);
    const n = document.createElement("a");
    n.style.display = "inline-block",
    n.style.margin = "1em 0",
    n.href = t,
    n.download = s.fileName,
    n.textContent = `保存到本地(${function(e=0){let t=e;return t<1024?`${t}B`:(t/=1024)<1024?`${t.toFixed(2)}KB`:(t/=1024)<1024?`${t.toFixed(2)}MB`:(t/=1024)<1024?`${t.toFixed(2)}GB`:(t/=1024)<1024?`${t.toFixed(2)}TB`:(t/=1024)<1024?`${t.toFixed(2)}PB`:(t/=1024)<1024?`${t.toFixed(2)}EB`:(t/=1024)<1024?`${t.toFixed(2)}ZB`:(t/=1024)<1024?`${t.toFixed(2)}YB`:(t/=1024,`${t}BB`)}(s.fileSize)})`,e.appendChild(n)}
function d(e, t, o) {
    const n = t.changedTouches ? t.changedTouches[0] : t,
    i = n.pageX,
    s = n.pageY,
    a = e.offsetLeft,
    c = e.offsetTop,
    d = e.offsetWidth / 2,
    r = e.offsetHeight / 2,
    h = e.parentElement;
    return function (t) {
        const n = t.changedTouches ? t.changedTouches[0] : t;
        if (0 === n.movementX && 0 === n.movementY)
            return;
        const l = a + n.pageX - i + d,
        p = c + n.pageY - s + r,
        u = d / h.offsetWidth * 100,
        m = r / h.offsetHeight * 100,
        f = l / h.offsetWidth * 100,
        v = p / h.offsetHeight * 100;
        e.style.left = f > 50 ? "auto" : `${Math.max(0,f-u)}%`,
        e.style.right = f > 50 ? 100 - Math.min(100, f + u) + "%" : "auto",
        e.style.top = v > 50 ? "auto" : `${Math.max(0,v-m)}%`,
        e.style.bottom = v > 50 ? 100 - Math.min(100, v + m) + "%" : "auto",
        o()
    }
}
export {
    e as default
};