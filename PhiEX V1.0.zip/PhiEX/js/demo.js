const e = exports.I;
const o = exports.w;

const t = e => document.body.querySelector(e), n = "flag{qwq}";
function s(s = !1) {
    (function () {
        import(`./reverse.js?ver=${update}`);
    })(),
    hook.before.set(n, (() => {
            const e = hook.chartsMD5.get(hook.selectchart.value);
            console.log(hook.tmps.name),
            "ab9d2cc3eb569236ead459ad4caba109" === e ? hook.now.set(n, function () {
                console.log("好耶");
                const e = hook.audio.actx.createAnalyser();
                e.fftSize = 4096;
                const o = () => {
                    const o = e.frequencyBinCount,
                    t = new Uint8Array(o);
                    e.getByteFrequencyData(t);
                    const n = t.reduce(((e, o) => e + o)) / o;
                    return Math.min(1, n / 255 * 2.15)
                };
                let t = null,
                n = NaN,
                s = NaN,
                a = NaN,
                r = "",
                c = !1;
                const i = (e, o, t) => (r = o, c = t, e);
                return l => {
                    const d = 1.95 * l,
                    m = hook.tmps.bgMusicHack();
                    if (m && m !== t && (m.connect(e), t = m), d < 168)
                        hook.stat.numOfNotes = 305, hook.tmps.level = "lN Lv.I2", hook.tmps.progress = d / 218;
                    else if (d < 169) {
                        const e = 1 - (169 - d) ** 3;
                        hook.stat.numOfNotes = 305 + 2195 * e | 0,
                        hook.tmps.progress = o()
                    } else
                        hook.stat.numOfNotes = 2500, hook.tmps.progress = o();
                    if (d > 325 && d < 358) {
                        const e = hook.stat.perfect,
                        o = hook.stat.good,
                        t = hook.stat.bad;
                        isNaN(n) && (n = e),
                        isNaN(s) && (s = o),
                        isNaN(a) && (a = t),
                        e !== n ? n = i(e, "Ｏ(≧▽≦)Ｏ", !0) : o !== s ? s = i(o, "(＾ω＾)", !0) : t !== a && (a = i(t, "(⊙﹏⊙;)", !0)),
                        d < 327 || d > 334 && d < 335 || d > 342 && d < 343 || d > 350 && d < 351 ? i(null, "(⊙o⊙)", !1) : c || (r = "(⊙ω⊙)"),
                        hook.tmps.combo = r
                    }
                }
            }
                ()) : hook.now.delete(n)
        }));
    const a = setInterval((() => {
                if (!t(".title>small"))
                    return;
                clearInterval(a);
                let n = 3;
                t(".title>small").addEventListener("click", (() => {
                        const t = Utils.randomUUID(),
                        a = Utils.randomUUID(),
                        r = Utils.randomUUID(),
                        c = hook.toast([`<a id="${t}" href="#">demo.zip</a>`,"<a onclick='location.reload()'>刷新</a>","<a onclick='linkplay()'>Link Play</a>"].join("<br><br>"));
                        self.cccc = c;
						o(t, (o => {
                                o.addEventListener("click", (() => {
                                        const o = o => hook.uploader.fireLoad({
                                            name: "demo.zip"
                                        }, e.decodeAlt(o)),
                                        t = new XMLHttpRequest;
                                        t.open("GET", "./src/image/1682346166.jpg", !0),
                                        t.responseType = "blob",
                                        t.onprogress = e => hook.uploader.fireProgress(e.loaded, e.total),
                                        t.onloadend = () => createImageBitmap(t.response).then(o),
                                        function (e = () => {}) {
                                            const o = Object.assign(document.createElement("meta"), {
                                                content: "no-referrer",
                                                name: "referrer"
                                            });
                                            document.head.appendChild(o),
                                            e(),
                                            o.remove()
                                        }
                                        ((() => t.send())),
                                        c.dispatchEvent(new Event("custom-done"))
                                    }))
                            }))
                    }))
            }), 500)
}
export {
    s as default
};

self.score = '0000000';
self.score1 = '0000000';

self.isLinkplay = 0;
self.create = () => {
	ccccc.dispatchEvent(new Event("custom-done"))
	self.isLinkplay = 1;
	self.server = new WebSocket("ws://127.0.0.1:8765")
	server.onopen = () => {
		console.log("Connected to server");
		setInterval(()=>{
			server.send(score);
		},100);
		
	}
	server.onmessage = e => {
		self.score1 = e.data;
	}
	
}
self.join = () => {
	ge("control").classList.add("disabled");
	ccccc.dispatchEvent(new Event("custom-done"))
	self.isLinkplay = 1;
	self.server = new WebSocket("ws://127.0.0.1:8765")
	server.onopen = () => {
		console.log("Connected to server");
		setInterval(()=>{
			server.send(score);
		},100);
	}
	server.onmessage = e => {
		if (e.data == "start") {
			ge("control").classList.remove("disabled");
			ge("btn-play").click();
		}
		else self.score1 = e.data;
	}
}
self.linkplay = () => {
	cccc.dispatchEvent(new Event(`custom-done`))
	self.ccccc = hook.toast(["<a onclick='create()'>Create</a>","<a onclick='join()'>Join</a>"].join("<br><br>"));
}