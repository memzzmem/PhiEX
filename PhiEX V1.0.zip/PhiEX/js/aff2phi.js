class fuckTap {
	constructor(time,lane) {
		this.time = time;
		this.lane = lane;
	}
}

class fuckHold {
	constructor(startTime,endTime,lane) {
		this.startTime = startTime;
		this.endTime = endTime;
		this.lane = lane;
	}
}

class arc {
	constructor(startTime, endTime, startX, endX, easing, startY, endY, color, hitsound, arcType, arctap) {
		this.startTime = startTime;
		this.endTime = endTime;
		this.startX = startX;
		this.endX = endX;
		this.easing = easing;
		this.startY = startY;
		this.endY = endY;
		this.color = color;
		this.hitsound = hitsound;
		this.arcType = arcType;
		this.arctap = arctap;
	}
}

class note {
    constructor(type, x, startime, endtime, speed = 1, raw = {}) {
        this.above = 1,
        this.alpha = 255,
        this.endTime = endtime ? endtime : startime,
        this.isFake = 0,
        this.positionX = x,
        this.size = 1,
        this.speed = speed,
        this.startTime = startime,
        this.type = type,
        this.visibleTime = 999999,
        this.yOffset = 0;
    }
}

const json = {BPMList:[{bpm:0,startTime:[0,0,1]}],META:{RPEVersion:140,background:"base.jpg",charter:"",composer:"",id:"",level:"",name:"",offset:0,song:"base.ogg"},judgeLineGroup:["Default"],judgeLineList:[{Group:0,Name:"",Texture:"line.png",alphaControl:[{alpha:1,easing:1,x:0},{alpha:1,easing:1,x:9999999}],bpmfactor:1,eventLayers:[{alphaEvents:[{bezier:0,bezierPoints:[0,0,0,0],easingLeft:0,easingRight:1,easingType:1,end:255,endTime:[1,0,1],linkgroup:0,start:255,startTime:[0,0,1]}],moveXEvents:[{bezier:0,bezierPoints:[0,0,0,0],easingLeft:0,easingRight:1,easingType:1,end:0,endTime:[1,0,1],linkgroup:0,start:0,startTime:[0,0,1]}],moveYEvents:[{bezier:0,bezierPoints:[0,0,0,0],easingLeft:0,easingRight:1,easingType:1,end:-300,endTime:[1,0,1],linkgroup:0,start:-300,startTime:[0,0,1]}],rotateEvents:[{bezier:0,bezierPoints:[0,0,0,0],easingLeft:0,easingRight:1,easingType:1,end:0,endTime:[1,0,1],linkgroup:0,start:0,startTime:[0,0,1]}],speedEvents:[{end:12,endTime:[1,0,1],linkgroup:0,start:12,startTime:[0,0,1]}]}],extended:{inclineEvents:[{bezier:0,bezierPoints:[0,0,0,0],easingLeft:0,easingRight:1,easingType:0,end:0,endTime:[1,0,1],linkgroup:0,start:0,startTime:[0,0,1]}]},father:-1,isCover:1,notes:[],numOfNotes:9,posControl:[{easing:1,pos:1,x:0},{easing:1,pos:1,x:9999999}],sizeControl:[{easing:1,size:1,x:0},{easing:1,size:1,x:9999999}],skewControl:[{easing:1,skew:0,x:0},{easing:1,skew:0,x:9999999}],yControl:[{easing:1,x:0,y:1},{easing:1,x:9999999,y:1}],zOrder:0}],multiLineString:"",multiScale:1};
const notes = [];
const used = [];
const time = (bpm, time) => [time / 1e3 / (60 / bpm), 0, 1];
const fix = i => i.match(/\((.*?)\)/)[1].split(',').map((a) => (a == 'true' || a == 'false') ? (a == 'true') : (isNaN(Number(a)) ? String(a) : Number(a)));


const positionX = lane => {
	const x = -750 + 300 * Number(lane);
	return x > 450 ? 450 : (x < -450 ? -450 : x);
}


const time2lane = (arc, tapTime) => {
    const mode = arc.startX > arc.endX ? -1 : 1
    const changeX = (tapTime - arc.startTime) / (arc.endTime - arc.startTime) * Math.abs(arc.endX - arc.startX);
    x = arc.startX + mode * changeX;
    let lane;
    if ((-0.5 <= x && x <= 0) || x < -0.5) lane = 1;
    else if (0 <= x && x <= 0.5) lane = 2;
    else if (0.5 <= x && x <= 1) lane = 3;
    else if ((1 <= x && x <= 1.5) || x > 1.5) lane = 4;
	else throw [arc, tapTime];
    return lane;
}


const check = (a, b, c) => {
    for (let i = 0; i < used.length; i++) {
        const [$a, $b, $c] = used[i];
        if (!(b < $a || a > $b) && c == $c) return 0;
        if ((Math.abs(a - $a) <= .01 || Math.abs(b - $b) <= .01) &&  c == $c) return 0;
    }
    return 1;
}


const addTap = (time, x, mode) => {
	const xx = x;
	if (!check(time[0], time[0], x)) {
		while (!check(time[0], time[0], x)) x += mode * 300; //沿arc方向移动
		if (x > 450 || x < -450) {
			console.warn(`over screen!将向${mode == -1 ? '右' : '左'}移动`);
			x = xx;
		}
		while (!check(time[0], time[0], x)) x -= mode * 300; //沿arc相反方向移动	
		if (x > 450 || x < -450) {
			console.warn(`轨道已满!无法添加note`);
			return;
		} else {
			console.log(`fix:${xx} -> ${x}`);
			totalFix++;
		}
	}
	used.push([time[0], time[0], x]);
	notes.push(new note(1, x, time, time, 1));
}


self.aff2json = text => {
	self.aff = {
		notes: {
			taps: [],
			holds: [],
			arcs: []
		}
	}
    const data = text.replaceAll('\r', '').replaceAll('  ', '').split('\n');
	aff.offset = Number(data[0].replace('AudioOffset:', ''));
	for (const i of data) {
		if (!aff.base_bpm && i.search('timing') != -1) aff.base_bpm = Number(i.slice(i.indexOf(',') + 1, i.indexOf(',', i.indexOf(',') + 1)));
		else if (('head' + i).search('head\\(') != -1) aff.notes.taps.push(new fuckTap(...fix(i)));
		else if (i.search('hold\\(')!= -1) aff.notes.holds.push(new fuckHold(...fix(i)));
		else if (i.search('arc\\(')!= -1) aff.notes.arcs.push(new arc(...fix(i),i.search('arctap') != -1 ? i.match(/arctap\((\d+)\)/g).map(m => +m.match(/\d+/)[0]) : []));
	}
    self.aff_notes = aff.notes;
    const bpm = aff.base_bpm;
	for (const i of aff_notes.taps) notes.push(new note(1, positionX(i.lane), time(bpm, i.time)));
	for (const i of aff_notes.holds) notes.push(new note(2, positionX(i.lane), time(bpm, i.startTime), time(bpm, i.endTime)));
	notes.forEach((e) => used.push([e.startTime[0], e.endTime[0], e.positionX]));
	self.totalFix = 0;
	for (const i of aff_notes.arcs) {
		if (i.arcType) {
			i.arctap.forEach((e)=> {
				const t = time(bpm, e);
				const x = positionX(time2lane(i, e));
				const mode = i.startX > i.endX ? -1 : 1;
				addTap(t, x, mode);
			});
		}
	} 
	for (const i of aff_notes.arcs) {
		if (!i.arcType) {
			if (i.startTime == i.endTime) continue;
			const t = time(bpm, i.startTime);
			const x = positionX(time2lane(i, i.startTime));
			const mode = i.startX > i.endX ? -1 : 1;
			addTap(t, x, mode);
		}
	}
	notes.sort((a,b) => a.startTime[0] - b.startTime[0]);
	json.BPMList[0].bpm = bpm;
	json.judgeLineList[0].numOfNotes = notes.length;
	json.META.offset = aff.offset;
	json.judgeLineList[0].notes = JSON.parse(JSON.stringify(notes));
	used.length = 0;
	notes.length = 0;
	return JSON.stringify(json);
}