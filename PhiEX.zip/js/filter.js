const e = hook.define({
    name: "Filter",
    description: "Apply filter to canvas",
    contents: [{
            type: "config",
            meta: ["启用滤镜", function (e, t) {
                    const {
                        status: a
                    } = hook,
                    o = document.createElement("textarea");
                    Object.assign(o, {
                        placeholder: "在此输入着色器代码"
                    }),
                    o.style.cssText += ";width:150px;height:1em;margin-left:10px",
                    o.addEventListener("change", (() => {
                            try {
                                const e = new r(o.value);
                                hook.filter = (t, r, a) => {
                                    e.apply(t.canvas),
                                    t.drawImage(e.getImage(r, a, hook.filterOptions), 0, 0)
                                }
                            } catch (e) {
                                console.error(e),
                                hook.filter = null
                            }
                        })),
                    a.reg("filterText", o, !1),
                    t.appendChild(o),
                    e.addEventListener("change", (() => {
                            o.classList.toggle("disabled", !e.checked),
                            e.checked ? o.dispatchEvent(new Event("change")) : hook.filter = null
                        })),
                    a.reg("enableFilter", e)
                }
            ]
        }
    ]
}), t = "\n  attribute vec2 a_position;\n  attribute vec2 a_texCoord;\n  varying vec2 v_texCoord;\n  void main() {\n    gl_Position = vec4(a_position, 0, 1);\n    v_texCoord = a_texCoord;\n  }\n";
function r(e) {
    this.fsSource = e.replace(/\xa0/g, " ");
    const r = document.createElement("canvas"),
    a = r.getContext("webgl2") || r.getContext("webgl") || r.getContext("experimental-webgl"),
    o = a.createProgram(),
    n = a.createShader(a.VERTEX_SHADER);
    a.shaderSource(n, t),
    a.compileShader(n),
    a.attachShader(o, n);
    const i = a.createShader(a.FRAGMENT_SHADER);
    if (a.shaderSource(i, this.fsSource), a.compileShader(i), !a.getShaderParameter(i, a.COMPILE_STATUS))
        throw new SyntaxError(a.getShaderInfoLog(i) || "Unknown error");
    a.attachShader(o, i),
    a.linkProgram(o),
    a.useProgram(o);
    const c = a.createBuffer();
    a.bindBuffer(a.ARRAY_BUFFER, c),
    a.bufferData(a.ARRAY_BUFFER, new Float32Array([-1, 1, 1, 1, 1, -1, -1, -1]), a.STATIC_DRAW);
    const s = a.getAttribLocation(o, "a_position");
    a.enableVertexAttribArray(s),
    a.vertexAttribPointer(s, 2, a.FLOAT, !1, 0, 0);
    const h = a.createBuffer();
    a.bindBuffer(a.ARRAY_BUFFER, h),
    a.bufferData(a.ARRAY_BUFFER, new Float32Array([0, 0, 1, 0, 1, 1, 0, 1]), a.STATIC_DRAW);
    const E = a.getAttribLocation(o, "a_texCoord");
    a.enableVertexAttribArray(E),
    a.vertexAttribPointer(E, 2, a.FLOAT, !1, 0, 0);
    const g = a.createTexture();
    a.bindTexture(a.TEXTURE_2D, g),
    a.texParameteri(a.TEXTURE_2D, a.TEXTURE_MIN_FILTER, a.LINEAR),
    a.texParameteri(a.TEXTURE_2D, a.TEXTURE_MAG_FILTER, a.LINEAR),
    a.texParameteri(a.TEXTURE_2D, a.TEXTURE_WRAP_S, a.CLAMP_TO_EDGE),
    a.texParameteri(a.TEXTURE_2D, a.TEXTURE_WRAP_T, a.CLAMP_TO_EDGE);
    const T = a.getUniformLocation(o, "u_image");
    a.uniform1i(T, 1),
    a.activeTexture(a.TEXTURE1),
    a.bindTexture(a.TEXTURE_2D, g),
    this.canvas = r,
    this.gl = a,
    this.program = o
}
r.prototype.apply = function (e) {
    const {
        gl: t,
        canvas: r
    } = this;
    return r.width = e.width,
    r.height = e.height,
    t.viewport(0, 0, r.width, r.height),
    t.texImage2D(t.TEXTURE_2D, 0, t.RGBA, t.RGBA, t.UNSIGNED_BYTE, e),
    r
}, r.prototype.getImage = function (e, t, r = {}) {
    const {
        gl: a
    } = this,
    o = a.getProgramParameter(this.program, a.ACTIVE_UNIFORMS);
    for (let n = 0; n < o; n++) {
        const {
            type: o,
            name: i
        } = a.getActiveUniform(this.program, n),
        c = a.getUniformLocation(this.program, i);
        switch (i) {
        case "u_name":
            a.uniform1f(c, e);
            break;
        case "u_now":
            a.uniform1f(c, t);
            break;
        case "u_aspect":
            a.uniform1f(c, this.canvas.width / this.canvas.height);
            break;
        default:
            o === a.FLOAT && void 0 !== r[i] && a.uniform1f(c, r[i])
        }
    }
    return a.drawArrays(a.TRIANGLE_FAN, 0, 4),
    this.canvas
};
export {
    e as default
};