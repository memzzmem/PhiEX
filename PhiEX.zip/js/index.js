const s = window.InteractProxy;
var e = Object.defineProperty, t = (t, s, n) => ((t, s, n) => s in t ? e(t, s, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : t[s] = n)(t, "symbol" != typeof s ? s + "" : s, n);

const n = {
    toggle(e) {
        if (!this.enabled)
            return Promise.reject(new Error("Fullscreen is not supported"));
        const t = () => new Promise(((e, t) => {
                document.addEventListener(this.onchange, e, {
                    once: !0
                }),
                document.addEventListener(this.onerror, t, {
                    once: !0
                })
            }));
        if (this.element) {
            const e = document.exitFullscreen || document.webkitExitFullscreen || document.mozCancelFullScreen;
            if (e)
                return e.call(document), t()
        } else {
            const s = e instanceof HTMLElement ? e : document.body,
            n = s.requestFullscreen || s.webkitRequestFullscreen || s.mozRequestFullScreen;
            if (n)
                return n.call(s), t()
        }
        return Promise.reject(new Error("Fullscreen is not supported"))
    },
    check(e) {
        const t = e instanceof HTMLElement ? e : document.body;
        return this.element === t
    },
    get onchange() {
        return void 0 !== document.onfullscreenchange ? "fullscreenchange" : void 0 !== document.onwebkitfullscreenchange ? "webkitfullscreenchange" : void 0 !== document.onmozfullscreenchange ? "mozfullscreenchange" : null
    },
    get onerror() {
        return void 0 !== document.onfullscreenerror ? "fullscreenerror" : void 0 !== document.onwebkitfullscreenerror ? "webkitfullscreenerror" : void 0 !== document.onmozfullscreenerror ? "mozfullscreenerror" : null
    },
    get element() {
        return document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || null
    },
    get enabled() {
        return document.fullscreenEnabled || document.webkitFullscreenEnabled || document.mozFullScreenEnabled || !1
    }
}, i = {
    async checkSupport() {
        const e = screen.orientation;
        if (!e)
            return !1;
        try {
            return await e.lock(e.type),
            e.unlock(),
            hook.toast("如果你看到了这个提示，请联系开发者：Unexpected Allow Orientation Lock Without Permission"),
            !0
        } catch (e) {
            if ("SecurityError" === e.name)
                return "The operation is insecure." !== e.message;
            if ("NotSupportedError" === e.name)
                return !1;
            if ("TypeError" === e.name)
                return !1;
            throw e
        }
    },
    lockLandscape() {
        const e = screen.orientation;
        return e ? e.lock("landscape-primary") : Promise.reject(new Error("Orientation is not supported"))
    },
    lockPortrait() {
        const e = screen.orientation;
        return e ? e.lock("portrait-primary") : Promise.reject(new Error("Orientation is not supported"))
    },
    unlock() {
        const e = screen.orientation;
        return e ? e.unlock() : Promise.reject(new Error("Orientation is not supported"))
    }
}, a = e => void 0 === self[e]; {
    try {
        Reflect.construct(EventTarget, [])
    } catch {
        self.EventTarget = function () {
            this.listeners = {}
        },
        EventTarget.prototype = {
            constructor: EventTarget,
            addEventListener(e, t) {
                e in this.listeners || (this.listeners[e] = []),
                this.listeners[e].push(t)
            },
            removeEventListener(e, t) {
                if (!(e in this.listeners))
                    return;
                const s = this.listeners[e];
                for (let e = 0, n = s.length; e < n; e++)
                    if (s[e] === t)
                        return void s.splice(e, 1)
            },
            dispatchEvent(e) {
                if (!(e.type in this.listeners))
                    return !0;
                const t = this.listeners[e.type];
                for (let s = 0, n = t.length; s < n; s++)
                    t[s].call(this, e);
                return !e.defaultPrevented
            }
        }
    }
    const e = new Error;
    if (new Error("", {
            cause: e
        }).cause !== e) {
        class e extends self.Error {
            constructor(e, {
                cause: t
            } = {}) {
                super(e),
                this.cause = t
            }
        }
        Object.defineProperty(e, "name", {
            value: "Error"
        }),
        self.Error = e
    }
    class t extends self.DOMException {
        constructor(e, s) {
            super(e, s),
            Error.captureStackTrace ? Error.captureStackTrace(this, t) : this.stack = (new Error).stack.replace(/.+\n/, "")
        }
    }
    Object.defineProperty(t, "name", {
        value: "DOMException"
    }),
    self.DOMException = t,
    a("AudioContext") && (self.AudioContext = self.webkitAudioContext),
    void 0 === Object.hasOwn && Object.defineProperty(Object, "hasOwn", {
        value: (e, t) => Object.prototype.hasOwnProperty.call(e, t)
    }),
    void 0 === Array.prototype.findLast && Object.defineProperty(Array.prototype, "findLast", {
        value(e, t) {
            for (let s = this.length - 1; s >= 0; s--)
                if (e.call(t, this[s], s, this))
                    return this[s]
        }
    }),
    void 0 === Array.prototype.toReversed && Object.defineProperty(Array.prototype, "toReversed", {
        value() {
            return this.slice().reverse()
        }
    })
}
class o {
    constructor() {
        t(this, "t0"),
        t(this, "t1"),
        t(this, "isPaused"),
        this.t0 = 0,
        this.t1 = 0,
        this.isPaused = !0
    }
    get time() {
        return this.isPaused ? this.t0 : this.t0 + performance.now() - this.t1
    }
    get second() {
        return this.time / 1e3
    }
    play() {
        if (!this.isPaused)
            throw new Error("Time has been playing");
        this.t1 = performance.now(),
        this.isPaused = !1
    }
    pause() {
        if (this.isPaused)
            throw new Error("Time has been paused");
        this.t0 = this.time,
        this.isPaused = !0
    }
    reset() {
        this.t0 = 0,
        this.t1 = 0,
        this.isPaused = !0
    }
    addTime(e = 0) {
        this.t0 += e
    }
}
function r(e, t) {
    const s = e.replace(/\ufeff|\r/g, "").split("\n"),
    n = [];
    for (const e of s) {
        let t = "",
        s = !1,
        i = !1;
        const a = [];
        for (const n of e)
            if ('"' === n)
                s ? i ? (t += n, i = !1) : i = !0 : s = !0;
            else if ("," === n)
                s ? i ? (a.push(t), t = "", s = !1, i = !1) : t += n : (a.push(t), t = "");
            else {
                if (i)
                    throw new SyntaxError("Unexpected token , (-1)");
                t += n
            }
        if (s) {
            if (!i)
                throw new SyntaxError("Unexpected token , (-2)");
            a.push(t),
            t = "",
            s = !1,
            i = !1
        } else
            a.push(t), t = "";
        n.push(a)
    }
    const i = [];
    for (let e = 1; e < n.length; e++) {
        const t = {};
        for (let s = 0; s < n[0].length; s++)
            t[n[0][s]] = n[e][s];
        i.push(t)
    }
    return i
}
function l(e) {
    const t = ["utf-8", "gbk", "big5", "shift_jis"];
    for (const s of t) {
        const n = new TextDecoder(s, {
            fatal: !0
        });
        try {
            return n.decode(e)
        } catch (e) {
            if (s === t[t.length - 1])
                throw e
        }
    }
    throw new Error("Unknown encoding")
}
var c, h;
(h = c || (c = {})).int = function (e) {
    return 0 | Number(e)
}, h.float = function (e) {
    return Number(e) || 0
}, h.bool = function (e) {
    return !!e
}, h.str = function (e) {
    return String(e)
}, h.arr = function (e, t) {
    return Array.isArray(e) ? e.map((e => new t(e || {}))) : []
}, h.obj = function (e, t) {
    return new t(e || {})
};
const d = c;
class f {
    constructor(e) {
        t(this, "startTime"),
        t(this, "endTime"),
        t(this, "value"),
        this.startTime = d.int(e.startTime),
        this.endTime = d.int(e.endTime),
        this.value = d.float(e.value)
    }
}
class u {
    constructor(e) {
        t(this, "type"),
        t(this, "time"),
        t(this, "positionX"),
        t(this, "holdTime"),
        t(this, "speed"),
        t(this, "floorPosition"),
        this.type = d.int(e.type),
        this.time = d.int(e.time),
        this.positionX = d.float(e.positionX),
        this.holdTime = d.int(e.holdTime),
        this.speed = d.float(e.speed),
        this.floorPosition = d.float(e.floorPosition)
    }
}
class p {
    constructor(e) {
        t(this, "startTime"),
        t(this, "endTime"),
        t(this, "start"),
        t(this, "end"),
        t(this, "start2"),
        t(this, "end2"),
        this.startTime = d.int(e.startTime),
        this.endTime = d.int(e.endTime),
        this.start = d.float(e.start),
        this.end = d.float(e.end),
        this.start2 = d.float(e.start2),
        this.end2 = d.float(e.end2)
    }
}
class g {
    constructor(e) {
        t(this, "numOfNotes"),
        t(this, "numOfNotesAbove"),
        t(this, "numOfNotesBelow"),
        t(this, "bpm"),
        t(this, "speedEvents"),
        t(this, "notesAbove"),
        t(this, "notesBelow"),
        t(this, "judgeLineDisappearEvents"),
        t(this, "judgeLineMoveEvents"),
        t(this, "judgeLineRotateEvents"),
        this.numOfNotes = d.int(e.numOfNotes),
        this.numOfNotesAbove = d.int(e.numOfNotesAbove),
        this.numOfNotesBelow = d.int(e.numOfNotesBelow),
        this.bpm = d.float(e.bpm),
        this.speedEvents = d.arr(e.speedEvents, f),
        this.notesAbove = d.arr(e.notesAbove, u),
        this.notesBelow = d.arr(e.notesBelow, u),
        null == e.numOfNotesAbove && (this.numOfNotesAbove = this.notesAbove.length),
        null == e.numOfNotesBelow && (this.numOfNotesBelow = this.notesBelow.length),
        null == e.numOfNotes && (this.numOfNotes = this.numOfNotesAbove + this.numOfNotesBelow),
        this.judgeLineDisappearEvents = d.arr(e.judgeLineDisappearEvents, p),
        this.judgeLineMoveEvents = d.arr(e.judgeLineMoveEvents, p),
        this.judgeLineRotateEvents = d.arr(e.judgeLineRotateEvents, p)
    }
}
class m {
    constructor(e) {
        t(this, "formatVersion"),
        t(this, "offset"),
        t(this, "numOfNotes"),
        t(this, "judgeLineList");
        const s = e || {};
        this.formatVersion = d.int(s.formatVersion),
        this.offset = d.float(s.offset),
        this.numOfNotes = d.int(s.numOfNotes),
        this.judgeLineList = d.arr(s.judgeLineList, g),
        null == s.numOfNotes && (this.numOfNotes = this.judgeLineList.reduce(((e, t) => e + t.numOfNotes), 0))
    }
    duplicate() {
        return d.obj(this, m)
    }
}
function v(e, t) {
    const s = d.obj(e, m);
    switch (s.formatVersion) {
    case 1:
        for (const e of s.judgeLineList)
            for (const t of e.judgeLineMoveEvents)
                t.start2 = t.start % 1e3 / 520, t.end2 = t.end % 1e3 / 520, t.start = Math.floor(t.start / 1e3) / 880, t.end = Math.floor(t.end / 1e3) / 880;
    case 3:
    case 3473:
        break;
    default:
        throw new Error(`Unsupported formatVersion: ${s.formatVersion}`)
    }
    const n = [],
    i = [],
    a = s.judgeLineList.length;
    var o;
    a > 100 && (o = `Expected at most 100 items in judgeLineList, but got ${a}`, i.push({
            host: "Core",
            code: 1,
            name: "LineCountWarning",
            message: o,
            target: t
        }));
    let r = 0;
    for (const {
        bpm: e,
        notesAbove: t,
        notesBelow: n
    }
        of s.judgeLineList) {
        for (const {
            type: s,
            time: n,
            holdTime: i
        }
            of t) {
            const t = (n % 1e9 + (3 === s && i > 0 ? i : 0)) / e * 1.875;
            t > r && (r = t)
        }
        for (const {
            type: t,
            time: s,
            holdTime: i
        }
            of n) {
            const n = (s % 1e9 + (3 === t && i > 0 ? i : 0)) / e * 1.875;
            n > r && (r = n)
        }
    }
    for (let e = 0; e < a; e++) {
        const t = s.judgeLineList[e],
        i = [];
        if (t.bpm > 0) {
            const e = Math.ceil(r * t.bpm / 1.875),
            s = s => {
                if (t[s].length) {
                    let n = 0;
                    for (const {
                        endTime: e
                    }
                        of t[s])
                        e > n && (n = e);
                    n < e && i.push(`Maximum time for ${s} is too small`)
                } else
                    i.push(`Expected at least 1 item in ${s}`)
            };
            s("speedEvents"),
            s("judgeLineDisappearEvents"),
            s("judgeLineMoveEvents"),
            s("judgeLineRotateEvents")
        } else
            i.push(`Expected bpm > 0, but got ${t.bpm}`);
        i.length && n.push(`JudgeLine ${e}:\n${i.map((e=>` $ {
            e
        }
`)).join("\n")}`)
    }
    if (n.length)
        throw new Error(`Invalid chart input\n${n.map((e=>` $ {
            e.split("\n").join("\n  ")
        }
`)).join("\n")}`);
    if (!a)
        throw new Error("No judge lines available");
    return {
        data: s,
        messages: i
    }
}
function b(e, t) {
    const s = [];
    for (const n of e) {
        if (null == n.Chart)
            continue;
        const e = {
            chart: n.Chart
        };
        if (null != n.Name && (e.name = n.Name), null != n.Musician && (e.artist = n.Musician), null != n.Composer && (e.artist = n.Composer), null != n.Artist && (e.artist = n.Artist), null != n.Level && (e.level = n.Level), null != n.Illustrator && (e.illustrator = n.Illustrator), null != n.Designer && (e.charter = n.Designer), null != n.Charter && (e.charter = n.Charter), null != n.Music && (e.music = n.Music), null != n.Image && (e.image = n.Image), null != n.AspectRatio) {
            const t = parseFloat(n.AspectRatio);
            isFinite(t) && (e.aspectRatio = t)
        }
        if (null != n.ScaleRatio) {
            const t = 8080 / parseFloat(n.ScaleRatio);
            isFinite(t) && (e.noteScale = t)
        }
        if (null != n.NoteScale) {
            const t = parseFloat(n.NoteScale);
            isFinite(t) && (e.noteScale = t)
        }
        if (null != n.GlobalAlpha) {
            const t = parseFloat(n.GlobalAlpha);
            isFinite(t) && (e.backgroundDim = t)
        }
        if (null != n.BackgroundDim) {
            const t = parseFloat(n.BackgroundDim);
            isFinite(t) && (e.backgroundDim = t)
        }
        if (null != n.Offset) {
            const t = parseFloat(n.Offset);
            isFinite(t) && (e.offset = t)
        }
        s.push(e),
        t && (e.chart = `${t}/${e.chart}`, null != e.music && (e.music = `${t}/${e.music}`), null != e.image && (e.image = `${t}/${e.image}`))
    }
    return s
}
function w(e, t) {
    const s = [];
    for (const n of e) {
        if (null == n.Chart)
            continue;
        const e = {
            chart: n.Chart
        };
        if (null != n.LineId && (e.lineId = Number(n.LineId)), null != n.Image && (e.image = n.Image), null != n.Vert) {
            const t = parseFloat(n.Vert);
            isFinite(t) && (e.scaleOld = t)
        }
        if (null != n.Horz) {
            const t = parseFloat(n.Horz);
            isFinite(t) && (e.aspect = t)
        }
        if (null != n.IsDark) {
            const t = parseFloat(n.IsDark);
            isFinite(t) && (e.useBackgroundDim = !!t)
        }
        if (null != n.Scale) {
            const t = parseFloat(n.Scale);
            isFinite(t) && (e.scale = t)
        }
        if (null != n.Aspect) {
            const t = parseFloat(n.Aspect);
            isFinite(t) && (e.aspect = t)
        }
        if (null != n.UseBackgroundDim) {
            const t = parseFloat(n.UseBackgroundDim);
            isFinite(t) && (e.useBackgroundDim = !!t)
        }
        if (null != n.UseLineColor) {
            const t = parseFloat(n.UseLineColor);
            isFinite(t) && (e.useLineColor = !!t)
        }
        if (null != n.UseLineScale) {
            const t = parseFloat(n.UseLineScale);
            isFinite(t) && (e.useLineScale = !!t)
        }
        s.push(e),
        t && (e.chart = `${t}/${e.chart}`, null != e.image && (e.image = `${t}/${e.image}`))
    }
    return s
}
function y(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
}
var x = {
    exports: {}
}, k = {
    exports: {}
};
!function () {
    var e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
    t = {
        rotl: function (e, t) {
            return e << t | e >>> 32 - t
        },
        rotr: function (e, t) {
            return e << 32 - t | e >>> t
        },
        endian: function (e) {
            if (e.constructor == Number)
                return 16711935 & t.rotl(e, 8) | 4278255360 & t.rotl(e, 24);
            for (var s = 0; s < e.length; s++)
                e[s] = t.endian(e[s]);
            return e
        },
        randomBytes: function (e) {
            for (var t = []; e > 0; e--)
                t.push(Math.floor(256 * Math.random()));
            return t
        },
        bytesToWords: function (e) {
            for (var t = [], s = 0, n = 0; s < e.length; s++, n += 8)
                t[n >>> 5] |= e[s] << 24 - n % 32;
            return t
        },
        wordsToBytes: function (e) {
            for (var t = [], s = 0; s < 32 * e.length; s += 8)
                t.push(e[s >>> 5] >>> 24 - s % 32 & 255);
            return t
        },
        bytesToHex: function (e) {
            for (var t = [], s = 0; s < e.length; s++)
                t.push((e[s] >>> 4).toString(16)), t.push((15 & e[s]).toString(16));
            return t.join("")
        },
        hexToBytes: function (e) {
            for (var t = [], s = 0; s < e.length; s += 2)
                t.push(parseInt(e.substr(s, 2), 16));
            return t
        },
        bytesToBase64: function (t) {
            for (var s = [], n = 0; n < t.length; n += 3)
                for (var i = t[n] << 16 | t[n + 1] << 8 | t[n + 2], a = 0; a < 4; a++)
                    8 * n + 6 * a <= 8 * t.length ? s.push(e.charAt(i >>> 6 * (3 - a) & 63)) : s.push("=");
            return s.join("")
        },
        base64ToBytes: function (t) {
            t = t.replace(/[^A-Z0-9+\/]/gi, "");
            for (var s = [], n = 0, i = 0; n < t.length; i = ++n % 4)
                0 != i && s.push((e.indexOf(t.charAt(n - 1)) & Math.pow(2, -2 * i + 8) - 1) << 2 * i | e.indexOf(t.charAt(n)) >>> 6 - 2 * i);
            return s
        }
    };
    k.exports = t
}
();
var L = k.exports, S = {
    utf8: {
        stringToBytes: function (e) {
            return S.bin.stringToBytes(unescape(encodeURIComponent(e)))
        },
        bytesToString: function (e) {
            return decodeURIComponent(escape(S.bin.bytesToString(e)))
        }
    },
    bin: {
        stringToBytes: function (e) {
            for (var t = [], s = 0; s < e.length; s++)
                t.push(255 & e.charCodeAt(s));
            return t
        },
        bytesToString: function (e) {
            for (var t = [], s = 0; s < e.length; s++)
                t.push(String.fromCharCode(e[s]));
            return t.join("")
        }
    }
}, E = S, T = function (e) {
    return null != e && (M(e) || function (e) {
        return "function" == typeof e.readFloatLE && "function" == typeof e.slice && M(e.slice(0, 0))
    }
        (e) || !!e._isBuffer)
};
/*!
 * Determine if an object is a Buffer
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */
function M(e) {
    return !!e.constructor && "function" == typeof e.constructor.isBuffer && e.constructor.isBuffer(e)
}
!function () {
    var e = L,
    t = E.utf8,
    s = T,
    n = E.bin,
    i = function (a, o) {
        a.constructor == String ? a = o && "binary" === o.encoding ? n.stringToBytes(a) : t.stringToBytes(a) : s(a) ? a = Array.prototype.slice.call(a, 0) : !Array.isArray(a) && a.constructor !== Uint8Array && (a = a.toString());
        for (var r = e.bytesToWords(a), l = 8 * a.length, c = 1732584193, h = -271733879, d = -1732584194, f = 271733878, u = 0; u < r.length; u++)
            r[u] = 16711935 & (r[u] << 8 | r[u] >>> 24) | 4278255360 & (r[u] << 24 | r[u] >>> 8);
        r[l >>> 5] |= 128 << l % 32,
        r[14 + (l + 64 >>> 9 << 4)] = l;
        var p = i._ff,
        g = i._gg,
        m = i._hh,
        v = i._ii;
        for (u = 0; u < r.length; u += 16) {
            var b = c,
            w = h,
            y = d,
            x = f;
            c = p(c, h, d, f, r[u + 0], 7, -680876936),
            f = p(f, c, h, d, r[u + 1], 12, -389564586),
            d = p(d, f, c, h, r[u + 2], 17, 606105819),
            h = p(h, d, f, c, r[u + 3], 22, -1044525330),
            c = p(c, h, d, f, r[u + 4], 7, -176418897),
            f = p(f, c, h, d, r[u + 5], 12, 1200080426),
            d = p(d, f, c, h, r[u + 6], 17, -1473231341),
            h = p(h, d, f, c, r[u + 7], 22, -45705983),
            c = p(c, h, d, f, r[u + 8], 7, 1770035416),
            f = p(f, c, h, d, r[u + 9], 12, -1958414417),
            d = p(d, f, c, h, r[u + 10], 17, -42063),
            h = p(h, d, f, c, r[u + 11], 22, -1990404162),
            c = p(c, h, d, f, r[u + 12], 7, 1804603682),
            f = p(f, c, h, d, r[u + 13], 12, -40341101),
            d = p(d, f, c, h, r[u + 14], 17, -1502002290),
            c = g(c, h = p(h, d, f, c, r[u + 15], 22, 1236535329), d, f, r[u + 1], 5, -165796510),
            f = g(f, c, h, d, r[u + 6], 9, -1069501632),
            d = g(d, f, c, h, r[u + 11], 14, 643717713),
            h = g(h, d, f, c, r[u + 0], 20, -373897302),
            c = g(c, h, d, f, r[u + 5], 5, -701558691),
            f = g(f, c, h, d, r[u + 10], 9, 38016083),
            d = g(d, f, c, h, r[u + 15], 14, -660478335),
            h = g(h, d, f, c, r[u + 4], 20, -405537848),
            c = g(c, h, d, f, r[u + 9], 5, 568446438),
            f = g(f, c, h, d, r[u + 14], 9, -1019803690),
            d = g(d, f, c, h, r[u + 3], 14, -187363961),
            h = g(h, d, f, c, r[u + 8], 20, 1163531501),
            c = g(c, h, d, f, r[u + 13], 5, -1444681467),
            f = g(f, c, h, d, r[u + 2], 9, -51403784),
            d = g(d, f, c, h, r[u + 7], 14, 1735328473),
            c = m(c, h = g(h, d, f, c, r[u + 12], 20, -1926607734), d, f, r[u + 5], 4, -378558),
            f = m(f, c, h, d, r[u + 8], 11, -2022574463),
            d = m(d, f, c, h, r[u + 11], 16, 1839030562),
            h = m(h, d, f, c, r[u + 14], 23, -35309556),
            c = m(c, h, d, f, r[u + 1], 4, -1530992060),
            f = m(f, c, h, d, r[u + 4], 11, 1272893353),
            d = m(d, f, c, h, r[u + 7], 16, -155497632),
            h = m(h, d, f, c, r[u + 10], 23, -1094730640),
            c = m(c, h, d, f, r[u + 13], 4, 681279174),
            f = m(f, c, h, d, r[u + 0], 11, -358537222),
            d = m(d, f, c, h, r[u + 3], 16, -722521979),
            h = m(h, d, f, c, r[u + 6], 23, 76029189),
            c = m(c, h, d, f, r[u + 9], 4, -640364487),
            f = m(f, c, h, d, r[u + 12], 11, -421815835),
            d = m(d, f, c, h, r[u + 15], 16, 530742520),
            c = v(c, h = m(h, d, f, c, r[u + 2], 23, -995338651), d, f, r[u + 0], 6, -198630844),
            f = v(f, c, h, d, r[u + 7], 10, 1126891415),
            d = v(d, f, c, h, r[u + 14], 15, -1416354905),
            h = v(h, d, f, c, r[u + 5], 21, -57434055),
            c = v(c, h, d, f, r[u + 12], 6, 1700485571),
            f = v(f, c, h, d, r[u + 3], 10, -1894986606),
            d = v(d, f, c, h, r[u + 10], 15, -1051523),
            h = v(h, d, f, c, r[u + 1], 21, -2054922799),
            c = v(c, h, d, f, r[u + 8], 6, 1873313359),
            f = v(f, c, h, d, r[u + 15], 10, -30611744),
            d = v(d, f, c, h, r[u + 6], 15, -1560198380),
            h = v(h, d, f, c, r[u + 13], 21, 1309151649),
            c = v(c, h, d, f, r[u + 4], 6, -145523070),
            f = v(f, c, h, d, r[u + 11], 10, -1120210379),
            d = v(d, f, c, h, r[u + 2], 15, 718787259),
            h = v(h, d, f, c, r[u + 9], 21, -343485551),
            c = c + b >>> 0,
            h = h + w >>> 0,
            d = d + y >>> 0,
            f = f + x >>> 0
        }
        return e.endian([c, h, d, f])
    };
    i._ff = function (e, t, s, n, i, a, o) {
        var r = e + (t & s | ~t & n) + (i >>> 0) + o;
        return (r << a | r >>> 32 - a) + t
    },
    i._gg = function (e, t, s, n, i, a, o) {
        var r = e + (t & n | s & ~n) + (i >>> 0) + o;
        return (r << a | r >>> 32 - a) + t
    },
    i._hh = function (e, t, s, n, i, a, o) {
        var r = e + (t ^ s ^ n) + (i >>> 0) + o;
        return (r << a | r >>> 32 - a) + t
    },
    i._ii = function (e, t, s, n, i, a, o) {
        var r = e + (s ^ (t | ~n)) + (i >>> 0) + o;
        return (r << a | r >>> 32 - a) + t
    },
    i._blocksize = 16,
    i._digestsize = 16,
    x.exports = function (t, s) {
        if (null == t)
            throw new Error("Illegal argument " + t);
        var a = e.wordsToBytes(i(t, s));
        return s && s.asBytes ? a : s && s.asString ? n.bytesToString(a) : e.bytesToHex(a)
    }
}
();
const C = y(x.exports);
function A(e) {
    return new Worker("" + new URL(`./lib/zip.worker.js?ver=${ver}`, import.meta.url).href, {
        name: null == e ? void 0 : e.name
    })
}
class B extends EventTarget {
    constructor() {
        super(),
        t(this, "input"),
        this.input = Object.assign(document.createElement("input"), {
            type: "file",
            accept: "",
            multiple: !0,
            onchange: () => {
                this.fireChange(this.input.files);
                for (const e of this.input.files || []) {
                    const t = new FileReader;
                    t.readAsArrayBuffer(e),
                    t.onprogress = e => this.fireProgress(e.loaded, e.total),
                    t.onload = t => t.target && t.target.result instanceof ArrayBuffer && this.fireLoad(e, t.target.result)
                }
                this.input.value = ""
            }
        })
    }
    uploadFile() {
        this.input.webkitdirectory = !1,
        this.input.click()
    }
    uploadDir() {
        this.input.webkitdirectory = !0,
        this.input.click()
    }
    fireChange(e) {
        return this.dispatchEvent(Object.assign(new Event("change"), {
                files: e
            }))
    }
    fireProgress(e, t) {
        return this.dispatchEvent(new ProgressEvent("progress", {
                lengthComputable: !0,
                loaded: e,
                total: t
            }))
    }
    fireLoad(e, t) {
        return this.dispatchEvent(Object.assign(new ProgressEvent("load"), {
                file: e,
                buffer: t
            }))
    }
}
class R extends EventTarget {
    constructor({
        handler: e = async e => Promise.resolve(e)
    }) {
        super(),
        t(this, "total"),
        t(this, "worker"),
        t(this, "handler"),
        this.worker = null,
        this.total = 0,
        this.handler = e
    }
    read(e) {
        if (!this.worker) {
            this.dispatchEvent(new CustomEvent("loadstart"));
            const e = new A;
            e.addEventListener("message", (e => {
                    (async() => {
                        const {
                            data: t
                        } = e;
                        this.total = t.total;
                        const s = await this.handler(t.data);
                        this.dispatchEvent(new CustomEvent("read", {
                                detail: s
                            }))
                    })().catch((e => this.dispatchEvent(new CustomEvent("error", {
                                    detail: e
                                }))))
                })),
            this.worker = e
        }
        this.worker.postMessage(e, [e.buffer])
    }
    terminate() {
        this.worker && (this.worker.terminate(), this.worker = null)
    }
}
const I = [{
        pattern: /\.(mp3|ogg|wav|mp4|webm|ogv|mpg|mpeg|avi|mov|flv|wmv|mkv)$/i,
        read: async(e, {
            createAudioBuffer: t
        } = {}) => async function (e, t) {
            const s = document.createElement("video");
            return await new Promise((t => {
                    s.src = URL.createObjectURL(new Blob([e.buffer])),
                    s.preload = "metadata",
                    s.onloadedmetadata = t,
                    s.onerror = t
                })), {
                pathname: e.pathname,
                type: "media",
                data: {
                    audio: await t(e.buffer.slice(0)),
                    video: s.videoWidth && s.videoHeight ? s : null
                }
            }
        }
        (e, (async e => "function" == typeof t ? t(e) : async function (e) {
                const t = new self.AudioContext;
                return await t.close(),
                new Promise(((s, n) => {
                        const i = t.decodeAudioData(e, s, n);
                        i instanceof Promise && i.then(s, n)
                    })).catch((e => {
                        throw e instanceof Error ? e : new DOMException("Unable to decode audio data", "EncodingError")
                    }))
            }
                (e)))
    }, {
        pattern: /\.json$/i,
        type: "json",
        read(e) {
            const t = e.text,
            s = JSON.parse(t, ((e, t) => "number" == typeof t ? Math.fround(t) : t)), {
                data: n,
                messages: i
            } = v(s, e.pathname),
            a = `PGS(${n.formatVersion})`;
            return {
                pathname: e.pathname,
                type: "chart",
                md5: C(t),
                data: n,
                msg: i,
                format: a
            }
        }
    }, {
        pattern: /\.(png|jpg|jpeg|gif|bmp|webp|svg)$/i,
        async read(e) {
            const t = new Blob([e.buffer]),
            s = await createImageBitmap(t);
            return {
                pathname: e.pathname,
                type: "image",
                data: s
            }
        }
    }, {
        pattern: /^line\.csv$/i,
        type: "text",
        mustMatch: !0,
        read(e) {
            const {
                path: t
            } = F(e.pathname),
            s = w(r(e.text), t);
            return {
                pathname: e.pathname,
                type: "line",
                data: s
            }
        }
    }, {
        pattern: /^info\.csv$/i,
        type: "text",
        mustMatch: !0,
        read(e) {
            const {
                path: t
            } = F(e.pathname),
            s = b(r(e.text), t);
            return {
                pathname: e.pathname,
                type: "info",
                data: s
            }
        }
    }
], D = function (e) {
    const t = I.map(e);
    return {
        async read(e, s = {}) {
            const {
                name: n
            } = F(e.pathname),
            i = t.filter((e => e.pattern.test(n) || !e.mustMatch));
            i.sort(((e, t) => e.pattern.test(n) && !t.pattern.test(n) ? -1 : !e.pattern.test(n) && t.pattern.test(n) ? 1 : e.weight > t.weight ? -1 : e.weight < t.weight ? 1 : 0));
            const a = [],
            o = (e, t) => {
                e.pattern.test(n) && a.push(t)
            };
            for (const t of i)
                try {
                    const n = await t.read(e, s);
                    if (n)
                        return n
                } catch (e) {
                    o(t, e)
                }
            return {
                pathname: e.pathname,
                type: "unknown",
                data: a.join("\n")
            }
        },
        use(s) {
            if (Array.isArray(s))
                for (const e of s)
                    this.use(e);
            else
                t.push(e(s))
        }
    }
}
((function (e) {
        const {
            pattern: t,
            type: s = "binary",
            mustMatch: n = !1,
            weight: i = 0,
            read: a
        } = e,
        o = {
            pattern: t,
            type: s,
            mustMatch: n,
            weight: i,
            read: a
        };
        return "text" === s && (o.read = async e => {
                if (null == e.isText)
                    try {
                        e.text = l(e.buffer),
                        e.isText = !0
                    } catch {
                        e.isText = !1
                    }
                return e.isText ? a(e) : null
            }),
        "json" === s && (o.read = async e => {
                if (null == e.isText)
                    try {
                        e.text = l(e.buffer),
                        e.isText = !0
                    } catch {
                        e.isText = !1
                    }
                if (null == e.isJSON)
                    try {
                        e.data = JSON.parse(e.text),
                        e.isJSON = !0
                    } catch {
                        e.isJSON = !1
                    }
                return e.isJSON ? a(e) : null
            }),
        o
    }));
function F(e) {
    const t = e.lastIndexOf("/");
    return {
        name: e.slice(t + 1),
        path: ~t ? e.slice(0, t) : ""
    }
}
class P {
    constructor(e, s, n, i) {
        t(this, "type"),
        t(this, "id"),
        t(this, "offsetX"),
        t(this, "offsetY"),
        t(this, "isActive"),
        t(this, "isTapped"),
        t(this, "isMoving"),
        t(this, "lastDeltaX"),
        t(this, "lastDeltaY"),
        t(this, "nowDeltaX"),
        t(this, "nowDeltaY"),
        t(this, "deltaTime"),
        t(this, "currentTime"),
        t(this, "flicking"),
        t(this, "flicked"),
        this.type = e,
        this.id = s,
        this.offsetX = n,
        this.offsetY = i,
        this.isActive = !0,
        this.isTapped = !1,
        this.isMoving = !1,
        this.lastDeltaX = 0,
        this.lastDeltaY = 0,
        this.nowDeltaX = 0,
        this.nowDeltaY = 0,
        this.deltaTime = 0,
        this.currentTime = performance.now(),
        this.flicking = !1,
        this.flicked = !1
    }
    move(e, t) {
        this.lastDeltaX = this.nowDeltaX,
        this.lastDeltaY = this.nowDeltaY,
        this.nowDeltaX = e - this.offsetX,
        this.nowDeltaY = t - this.offsetY,
        this.offsetX = e,
        this.offsetY = t;
        const s = performance.now();
        this.deltaTime = s - this.currentTime,
        this.currentTime = s,
        this.isMoving = !0;
        const n = (this.nowDeltaX * this.lastDeltaX + this.nowDeltaY * this.lastDeltaY) / Math.sqrt(this.lastDeltaX ** 2 + this.lastDeltaY ** 2) / this.deltaTime;
        this.flicking && n < .5 ? (this.flicking = !1, this.flicked = !1) : !this.flicking && n > 1 && (this.flicking = !0)
    }
}
class N {
    constructor(e, s, n, i) {
        t(this, "offsetX"),
        t(this, "offsetY"),
        t(this, "type"),
        t(this, "judged"),
        t(this, "event"),
        t(this, "preventBad"),
        this.offsetX = e,
        this.offsetY = s,
        this.type = 0 | n,
        this.judged = !1,
        this.event = i,
        this.preventBad = !1
    }
}
class j {
    constructor() {
        t(this, "level"),
        t(this, "noteRank"),
        t(this, "combos"),
        t(this, "maxcombo"),
        t(this, "combo"),
        t(this, "cumDisp"),
        t(this, "curDisp"),
        t(this, "numDisp"),
        t(this, "numOfNotes"),
        t(this, "data"),
        t(this, "id"),
        t(this, "format"),
        this.level = 0,
        this.noteRank = [0, 0, 0, 0, 0, 0, 0, 0],
        this.combos = [0, 0, 0, 0, 0],
        this.cumDisp = 0,
        this.curDisp = 0,
        this.numDisp = 0,
        this.maxcombo = 0,
        this.combo = 0,
        this.numOfNotes = 0,
        this.data = {},
        this.id = "",
        this.format = ""
    }
    get good() {
        return this.noteRank[7] + this.noteRank[3]
    }
    get bad() {
        return this.noteRank[6]
    }
	get miss() {
		return this.noteRank[2]
	}
    get great() {
        return this.noteRank[5] + this.noteRank[1]
    }
    get perfect() {
        return this.noteRank[4]
    }
    get all() {
        return this.perfect + this.good + this.bad + this.miss + this.great
    }
    get scoreNum() {
        const e = 1e6 * (perfectScore * this.perfect + greatScore * this.great + goodScore * this.good + badScore * this.bad + missScore * this.miss + comboScore * this.maxcombo) / this.numOfNotes;
        return isFinite(e) ? e : 0
    }
    get scoreStr() {
        const e = this.scoreNum.toFixed(0);
        return "0".repeat(e.length < 7 ? 7 - e.length : 0) + e
    }
    get accNum() {
        const e = (this.perfect + this.great + .65 * this.good) / this.all;
        return isFinite(e) ? e : 1
    }
    get accStr() {
        return `${(100*this.accNum).toFixed(2)}％`
    }
    get avgDispStr() {
        const e = Math.trunc(this.cumDisp / this.numDisp * 1e3) || 0;
        return `${e>0?"+":""}${e.toFixed(0)}ms`
    }
    get curDispStr() {
        const e = Math.trunc(1e3 * this.curDisp);
        return `${e>0?"+":""}${e.toFixed(0)}ms`
    }
    get lineStatus() {
        return (this.bad + this.miss) ? 0 : this.good ? 3 : 1
    }
    get rankStatus() {
        const e = Math.round(this.scoreNum);
        return e >= 1e6 ? 0 : e >= 96e4 ? 1 : e >= 92e4 ? 2 : e >= 88e4 ? 3 : e >= 82e4 ? 4 : e >= 7e5 ? 5 : 6
    }
    get localData() {
        return Math.round(1e4 * this.accNum + 566).toString(22).slice(-3) + Math.round(this.scoreNum + 40672).toString(32).slice(-4) + this.level.toString(36).slice(-1)
    }
    static removeLegacy(e) {
        const t = localStorage.getItem("phi");
        null != t && (localStorage.setItem(e, t), localStorage.removeItem("phi"))
    }
    getData(e, t = "") {
        const s = this.data[this.id].slice(0, 3),
        n = this.data[this.id].slice(3, 7),
        i = Math.round(1e4 * this.accNum + 566).toString(22).slice(-3),
        a = Math.round(this.scoreNum + 40672).toString(32).slice(-4),
        o = this.level.toString(36).slice(-1),
        r = parseInt(n, 32) - 40672,
        l = r.toFixed(0),
        c = "0".repeat(l.length < 7 ? 7 - l.length : 0) + l;
        e || (this.data[this.id] = (s > i ? s : i) + (n > a ? n : a) + o);
        const h = [];
        for (const [e, t] of Object.entries(this.data))
            h.push(e + t);
        localStorage.setItem(`phi-${t}`, h.sort((() => Math.random() - .5)).join(""));
        const d = {
            newBestColor: n < a ? "#18ffbf" : "#fff",
            newBestStr: n < a ? "NEW BEST" : "BEST",
            scoreBest: c,
            scoreDelta: `${n>a?"- ":"+ "}${Math.abs(r-Math.round(this.scoreNum))}`,
            textAboveColor: "#65fe43",
            textAboveStr: "  ( Speed {SPEED}x )",
            textBelowColor: "#fe4365",
            textBelowStr: "AUTO PLAY / TESTMODE"
        };
        return e ? Object.assign(d, {
            newBestColor: "#fff",
            newBestStr: "BEST",
            scoreDelta: ""
        }) : 1 === this.lineStatus ? Object.assign(d, {
            textBelowStr: "ALL  PERFECT",
            textBelowColor: "#ffc500"
        }) : 3 === this.lineStatus ? Object.assign(d, {
            textBelowStr: "FULL  COMBO",
            textBelowColor: "#00bef1"
        }) : Object.assign(d, {
            textBelowStr: ""
        })
    }
    reset(e, t, s, n = "") {
        var i;
        const a = `phi-${n}`;
        this.numOfNotes = 0 | e,
        this.combo = 0,
        this.maxcombo = 0,
        this.noteRank = [0, 0, 0, 0, 0, 0, 0, 0],
        this.combos = [0, 0, 0, 0, 0],
        this.cumDisp = 0,
        this.curDisp = 0,
        this.numDisp = 0,
        "" === n && j.removeLegacy(a);
        const o = null !== (i = localStorage.getItem(a)) && void 0 !== i ? i : (localStorage.setItem(a, ""), "");
        for (let e = 0; e < Math.floor(o.length / 40); e++) {
            const t = o.slice(40 * e, 40 * e + 40);
            this.data[t.slice(0, 32)] = t.slice(-8)
        }
        t && (this.data[t] || (this.data[t] = this.localData), this.id = t),
        this.format = s
    }
    addCombo(e, t, index) {
		if (e == 2 && preventMiss) return;
		if (save) window.addCombo[index] = [e, t];
        this.noteRank[e]++,
        this.combo = e % 4 == 2 ? 0 : this.combo + 1,
        this.combo > this.maxcombo && (this.maxcombo = this.combo),
        this.combos[0]++,
        this.combos[t]++
    }
    addDisp(e) {
        this.curDisp = e,
        this.cumDisp += e,
        this.numDisp++
    }
}
let O = null, $ = null, H = null, X = !1;
const Y = [], _ = [];
class z {
    constructor(e, s, n) {
        t(this, "res"),
        t(this, "loop"),
        t(this, "offset"),
        t(this, "playbackrate"),
        t(this, "interval"),
        t(this, "dest"),
        t(this, "startTime"),
        t(this, "_bfs");
        const {
            loop: i,
            offset: a,
            playbackrate: o,
            interval: r
        } = n;
        this.res = e,
        this.dest = s,
        this.loop = i,
        this.offset = a,
        this.playbackrate = o,
        this.interval = r,
        this.startTime = NaN,
        this._bfs = null
    }
    get bfs() {
        return this._bfs || O.createBufferSource()
    }
    start() {
        this.startTime = performance.now() / 1e3,
        this._loop()
    }
    stop() {
        this._bfs && (this._bfs.onended = null, this._bfs.stop())
    }
    _loop() {
        this._bfs = O.createBufferSource();
        const e = this._bfs;
        e.buffer = this.res,
        e.loop = this.loop,
        e.connect(this.dest),
        e.playbackRate.value = this.playbackrate;
        const t = (this.offset + (performance.now() / 1e3 - this.startTime) * this.playbackrate) % this.res.duration;
        e.start(O.currentTime, t, this.interval),
        e.onended = s => {
            e.onended = null,
            (!(t + this.interval > this.res.duration) || this.loop) && this._loop()
        }
    }
}
function U(e, t, s) {
    const {
        loop: n,
        offset: i,
        playbackrate: a,
        interval: o
    } = s;
    if (isFinite(o) && o > 0) {
        const n = new z(e, t, s);
        return n.start(),
        _[_.length] = n,
        () => n.bfs
    }
    const r = O.createBufferSource();
    return r.buffer = e,
    r.loop = n,
    r.connect(t),
    r.playbackRate.value = a,
    r.start(0, i),
    _[_.length] = r,
    () => r
}
const V = {
    get actx() {
        return O
    },
    get gainNode() {
        return $
    },
    get msdest() {
        return H
    },
    set msdest(e) {
        e ? $.connect(e) : H && $.disconnect(H),
        H = e
    },
    init(e = self.AudioContext || self.webkitAudioContext) {
        O = new e,
        $ = O.createGain(),
        $.connect(O.destination),
        X = !0;
        for (const e of Y)
            e();
        return O
    },
    test(e) {
        X && e(),
        Y[Y.length] = e
    },
    decode: async e => O.decodeAudioData(e),
    mute: e => O.createBuffer(2, 44100 * e, 44100),
    sine(e, t = 440, s = 1) {
        const n = O.createBuffer(1, 44100 * e, 44100),
        i = n.getChannelData(0);
        for (let e = 0; e < i.length; e++)
            i[e] = Math.sin(e * t * 2 * Math.PI / 44100) * s;
        return n
    },
    sawtooth(e, t = 440, s = 1) {
        const n = O.createBuffer(1, 44100 * e, 44100),
        i = n.getChannelData(0);
        for (let e = 0; e < i.length; e++)
            i[e] = 2 * (e * t / 44100 % 1 - .5) * s;
        return n
    },
    square(e, t = 440, s = 1) {
        const n = O.createBuffer(1, 44100 * e, 44100),
        i = n.getChannelData(0);
        for (let e = 0; e < i.length; e++)
            i[e] = (e * t / 44100 % 1 < .5 ? 1 : -1) * s;
        return n
    },
    triangle(e, t = 440, s = 1) {
        const n = O.createBuffer(1, 44100 * e, 44100),
        i = n.getChannelData(0);
        for (let e = 0; e < i.length; e++)
            i[e] = (Math.abs(4 * (e * t / 44100 % 1 - .5)) - 1) * s;
        return n
    },
    noise(e, t = 1) {
        const s = O.createBuffer(1, 44100 * e, 44100),
        n = s.getChannelData(0);
        for (let e = 0; e < n.length; e++)
            n[e] = (2 * Math.random() - 1) * t;
        return s
    },
    play(e, t = {}) {
        const {
            loop: s = !1,
            offset: n = 0,
            playbackrate: i = 1,
            interval: a = 0
        } = t;
        return U(e, $, {
            loop: s,
            offset: n,
            playbackrate: i,
            interval: a
        })
    },
    stop() {
        for (const e of _)
            e.stop();
        _.length = 0
    }
};
class q {
    constructor() {
        t(this, "gainNode"),
        this.gainNode = null,
        V.test(this.init.bind(this))
    }
    init() {
        const e = O.createGain();
        e.connect($),
        this.gainNode = e
    }
    play(e, t = {}) {
        const {
            loop: s = !1,
            offset: n = 0,
            playbackrate: i = 1,
            interval: a = 0
        } = t;
        return U(e, this.gainNode, {
            loop: s,
            offset: n,
            playbackrate: i,
            interval: a
        })
    }
}
function W(e, t, s) {
    const n = document.createElement("canvas");
    Object.assign(n, {
        width: e,
        height: t
    });
    const i = n.getContext("2d", s);
    if (!i)
        throw new TypeError("Failed to create canvas context");
    return i
}
function J(e) {
    return (J = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (e) {
        return typeof e
    }
         : function (e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    })(e)
}
var Z, G = [512, 512, 456, 512, 328, 456, 335, 512, 405, 328, 271, 456, 388, 335, 292, 512, 454, 405, 364, 328, 298, 271, 496, 456, 420, 388, 360, 335, 312, 292, 273, 512, 482, 454, 428, 405, 383, 364, 345, 328, 312, 298, 284, 271, 259, 496, 475, 456, 437, 420, 404, 388, 374, 360, 347, 335, 323, 312, 302, 292, 282, 273, 265, 512, 497, 482, 468, 454, 441, 428, 417, 405, 394, 383, 373, 364, 354, 345, 337, 328, 320, 312, 305, 298, 291, 284, 278, 271, 265, 259, 507, 496, 485, 475, 465, 456, 446, 437, 428, 420, 412, 404, 396, 388, 381, 374, 367, 360, 354, 347, 341, 335, 329, 323, 318, 312, 307, 302, 297, 292, 287, 282, 278, 273, 269, 265, 261, 512, 505, 497, 489, 482, 475, 468, 461, 454, 447, 441, 435, 428, 422, 417, 411, 405, 399, 394, 389, 383, 378, 373, 368, 364, 359, 354, 350, 345, 341, 337, 332, 328, 324, 320, 316, 312, 309, 305, 301, 298, 294, 291, 287, 284, 281, 278, 274, 271, 268, 265, 262, 259, 257, 507, 501, 496, 491, 485, 480, 475, 470, 465, 460, 456, 451, 446, 442, 437, 433, 428, 424, 420, 416, 412, 408, 404, 400, 396, 392, 388, 385, 381, 377, 374, 370, 367, 363, 360, 357, 354, 350, 347, 344, 341, 338, 335, 332, 329, 326, 323, 320, 318, 315, 312, 310, 307, 304, 302, 299, 297, 294, 292, 289, 287, 285, 282, 280, 278, 275, 273, 271, 269, 267, 265, 263, 261, 259], K = [9, 11, 12, 13, 13, 14, 14, 15, 15, 15, 15, 16, 16, 16, 16, 17, 17, 17, 17, 17, 17, 17, 18, 18, 18, 18, 18, 18, 18, 18, 18, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24], Q = function e() {
    (function (e, t) {
        if (!(e instanceof t))
            throw new TypeError("Cannot call a class as a function")
    })(this, e),
    this.r = 0,
    this.g = 0,
    this.b = 0,
    this.a = 0,
    this.next = null
};
function ee(e) {
    const t = W(1, 1);
    return t.fillStyle = e,
    t.fillRect(0, 0, 1, 1),
    t.getImageData(0, 0, 1, 1).data
}
async function te(e, t, s = 512) {
    const n = ee(t),
    i = W(e.width, e.height, {
        willReadFrequently: !0
    });
    i.drawImage(e, 0, 0);
    for (let t = 0; t < e.height; t += s)
        for (let a = 0; a < e.width; a += s) {
            const e = i.getImageData(a, t, s, s);
            for (let t = 0; t < e.data.length / 4; t++)
                e.data[4 * t] *= n[0] / 255, e.data[4 * t + 1] *= n[1] / 255, e.data[4 * t + 2] *= n[2] / 255, e.data[4 * t + 3] *= n[3] / 255;
            i.putImageData(e, a, t)
        }
    return createImageBitmap(i.canvas)
}
async function se(e, t, s) {
    const n = Math.floor(null != t ? t : Math.min(e.width, e.height)),
    i = Math.floor(null != s ? s : n),
    a = [];
    for (let t = 0; t < e.height; t += i)
        for (let s = 0; s < e.width; s += n)
            a.push(createImageBitmap(e, s, t, n, i));
    return Promise.all(a)
}
(e => {
    e.decode = function (e, t = 0) {
        const s = W(e.width - 2 * t, e.height - 2 * t);
        s.drawImage(e, -t, -t);
        const n = s.getImageData(0, 0, s.canvas.width, s.canvas.width),
        i = new Uint8Array(n.data.length / 4 * 3);
        for (let e = 0; e < i.length; e++)
            i[e] = n.data[4 * (e / 3 | 0) + e % 3] ^ 3473 * e;
        const a = new DataView(i.buffer, 0, 4).getUint32(0);
        return i.buffer.slice(4, a + 4)
    },
    e.decodeAlt = function (e) {
        const t = W(e.width, e.height);
        t.drawImage(e, 0, 0);
        const s = t.getImageData(0, 0, t.canvas.width, t.canvas.height),
        n = new Uint8Array(s.data.length / 4 * 3),
        i = (e = 0, t = 0) => e ^ t ** 2 * 3473 & 255;
        for (let e = 0; e < n.length; e++)
            n[e] = s.data[4 * (e / 3 | 0) + e % 3];
        const a = new Uint8Array(n.length / 2);
        for (let e = 0; e < n.length / 2; e++)
            a[e] = i((n[2 * e] + 8) / 17 << 4 | (n[2 * e + 1] + 8) / 17, e);
        const o = new DataView(a.buffer, 0, 4).getUint32(0);
        return a.buffer.slice(4, o + 4)
    }
})(Z || (Z = {}));
class ne {
    constructor(e, s = !1) {
        t(this, "container"),
        t(this, "checkbox"),
        t(this, "label"),
        this.container = document.createElement("div"),
        this.checkbox = document.createElement("input"),
        this.checkbox.type = "checkbox",
        this.checkbox.id = Utils.randomUUID(),
        this.checkbox.checked = s,
        this.label = document.createElement("label"),
        this.label.htmlFor = this.checkbox.id,
        this.label.textContent = e,
        this.container.appendChild(this.checkbox),
        this.container.appendChild(this.label)
    }
    get checked() {
        return this.checkbox.checked
    }
    set checked(e) {
        this.checkbox.checked = e,
        this.checkbox.dispatchEvent(new Event("change"))
    }
    appendTo(e) {
        return e.appendChild(this.container),
        this
    }
    appendBefore(e) {
        if (null == e.parentNode)
            throw new Error("Node must have a parent node");
        return e.parentNode.insertBefore(this.container, e),
        this
    }
    toggle() {
        this.checked = !this.checkbox.checked
    }
    hook(e) {
        return e(this.checkbox, this.container),
        this
    }
}
class ie extends Array {
    constructor({
        updateCallback: e = () => !1,
        iterateCallback: s = () => {}
    } = {}) {
        super(),
        t(this, "update"),
        t(this, "animate"),
        this.update = this.defilter.bind(this, e),
        this.animate = this.iterate.bind(this, s)
    }
    defilter(e) {
        let t = this.length;
        for (; t--; )
            e(this[t]) && this.splice(t, 1);
        return this
    }
    iterate(e) {
        for (const t of this)
            e(t)
    }
    add(e) {
        if (hitFX) this[this.length] = e
    }
    clear() {
        this.length = 0
    }
}
class ae {
    constructor(e, s, n, i) {
        t(this, "offsetX"),
        t(this, "offsetY"),
        t(this, "color"),
        t(this, "text"),
        t(this, "time"),
        this.offsetX = e,
        this.offsetY = s,
        this.color = n,
        this.text = i,
        this.time = 0
    }
    static tap(e, t) {
        return new ae(e, t, "cyan", "")
    }
    static hold(e, t) {
        return new ae(e, t, "lime", "")
    }
    static move(e, t) {
        return new ae(e, t, "violet", "")
    }
}
class oe {
    constructor(e, s, n, i) {
        t(this, "offsetX"),
        t(this, "offsetY"),
        t(this, "time"),
        t(this, "duration"),
        t(this, "effects"),
        t(this, "direction"),
        t(this, "color");
        const a = hook.noteRender.hitFX[n];
        this.offsetX = e || 0,
        this.offsetY = s || 0,
        this.time = performance.now(),
        this.duration = a.duration,
        this.effects = a.effects,
        this.direction = Array(a.numOfParts || 0).fill(0).map((() => [80 * Math.random() + 185, 2 * Math.random() * Math.PI])),
        this.color = i
    }
    static perfect(e, t, s) {
        return new oe(e, t, "Perfect", "#ffeca0")
    }
    static good(e, t, s) {
        return new oe(e, t, "Good", "#b4e1ff")
    }
}
class re {
    constructor(e, s, n, i) {
        t(this, "offsetX"),
        t(this, "offsetY"),
        t(this, "time"),
        t(this, "duration"),
        t(this, "color"),
        t(this, "text"),
        this.offsetX = e || 0,
        this.offsetY = s || 0,
        this.time = performance.now(),
        this.duration = 250,
        this.color = n,
        this.text = i
    }
    static early(e, t) {
        return new re(e, t, "#03aaf9", "Early")
    }
    static late(e, t) {
        return new re(e, t, "#ff4612", "Late")
    }
}
class le {
    constructor(e, s, n = !1) {
        t(this, "full"),
        t(this, "head"),
        t(this, "body"),
        t(this, "tail");
        const i = -e.width / 2 * s,
        a = -e.height / 2 * s,
        o = e.width * s,
        r = e.height * s;
        this.full = t => t.drawImage(e, i, a, o, r),
        this.head = t => t.drawImage(e, i, 0, o, r),
        this.body = (t, s, n) => t.drawImage(e, i, s, o, n),
        this.tail = (t, s) => t.drawImage(e, i, s - r, o, r),
        n && (this.head = t => t.drawImage(e, i, a, o, r), this.tail = (t, s) => t.drawImage(e, i, s - r - a, o, r))
    }
}
function ce(e, t, s) {
    const {
        width: n,
        height: i
    } = e, {
        width: a,
        height: o
    } = t;
    return a * i > o * n ? [a * (1 - s) / 2, (o - a * i / n * s) / 2, a * s, a * i / n * s] : [(a - o * n / i * s) / 2, o * (1 - s) / 2, o * n / i * s, o * s]
}
class he {
    constructor(e) {
        t(this, "host"),
        t(this, "code"),
        t(this, "name"),
        t(this, "target"),
        t(this, "list"),
        t(this, "updateHTML"),
        this.host = e.host,
        this.code = e.code,
        this.name = e.name,
        this.target = e.target,
        this.list = [e],
        this.updateHTML = () => {}
    }
    appendMessage(e) {
        return this.host === e.host && this.code === e.code && this.name === e.name && this.target === e.target && (this.list.push(e), this.updateHTML(), !0)
    }
}
class de {
    constructor() {
        t(this, "lastMessage", ""),
        t(this, "betterMessageBoxes"),
        this.betterMessageBoxes = []
    }
    addBox(e = "warn") {
        const t = document.createElement("div");
        return t.setAttribute("type", e),
        t.classList.add("msgbox"),
        this.nodeView.appendChild(t)
    }
    removeNodeBox(e) {
        e.remove(),
        this.updateText(this.lastMessage)
    }
    removeBetterMessageBox(e) {
        const t = this.betterMessageBoxes.indexOf(e);
        -1 !== t && this.betterMessageBoxes.splice(t, 1)
    }
    msgbox(e = "", t = "", s = !1) {
        const n = this.addBox(t);
        n.innerHTML = e;
        const i = document.createElement("a");
        i.innerText = "忽略",
        i.style.float = "right",
        i.onclick = () => this.removeNodeBox(n),
        i.classList.toggle("disabled", s),
        n.appendChild(i)
    }
    bmsgbox(e) {
        const t = new he(e),
        s = {
            page: 1,
            size: 5,
            get pages() {
                return Math.ceil(t.list.length / this.size)
            }
        },
        n = document.createTextNode(""),
        i = document.createElement("a");
        i.innerText = "全部忽略",
        i.classList.add("bm-rbtn");
        const a = document.createElement("span");
        a.textContent = String(s.page),
        a.contentEditable = "true",
        a.style.cssText = ";color:red;outline:none;text-decoration:underline";
        const o = document.createElement("span");
        o.textContent = String(s.pages);
        const r = document.createElement("a");
        r.innerText = "上一页";
        const l = document.createElement("a");
        l.innerText = "下一页";
        const c = document.createElement("div");
        c.classList.add("bm-item"),
        c.append(a, " / ", o, " 页 ", r, " ", l);
        const h = this.addBox(["notice", "warn", "error"][t.code]);
        h.append(n, i, c),
        i.setAttribute("bm-ctrl", ""),
        c.setAttribute("bm-ctrl", "");
        const d = e => {
            isNaN(e) || (s.page = Math.max(1, Math.min(e, s.pages))),
            a.textContent = String(s.page),
            t.updateHTML()
        };
        a.onblur = () => d(parseInt(a.textContent)),
        r.onclick = () => d(s.page - 1),
        l.onclick = () => d(s.page + 1),
        i.onclick = () => {
            this.removeBetterMessageBox(t),
            this.removeNodeBox(h)
        };
        let f = 0;
        return t.updateHTML = () => {
            clearTimeout(f),
            f = self.setTimeout((() => {
                        const {
                            pages: e
                        } = s;
                        s.page > e && (s.page = e);
                        const i = (s.page - 1) * s.size;
                        n.textContent = `${t.code?` $ {
                            t.host
                        }
                        : 检测到 $ {
                            t.list.length
                        }
                        个 $ {
                            t.name
                        }
                         \ n `:""}来自 ${t.target}`,
                        a.textContent = String(s.page),
                        o.textContent = String(e);
                        for (const t of h.querySelectorAll("[bm-ctrl]"))
                            t.classList.toggle("hide", e <= 1);
                        for (const e of h.querySelectorAll("[bm-cell]"))
                            e.remove();
                        for (const e of t.list.slice(i, i + s.size)) {
                            const s = document.createElement("a");
                            s.innerText = "忽略",
                            s.classList.add("bm-rbtn"),
                            s.onclick = () => {
                                t.list.splice(t.list.indexOf(e), 1),
                                t.updateHTML(),
                                0 === t.list.length ? (this.removeBetterMessageBox(t), this.removeNodeBox(h)) : this.updateText(this.lastMessage)
                            };
                            const n = document.createElement("div");
                            n.setAttribute("bm-cell", ""),
                            n.classList.add("bm-item"),
                            n.append(`${e.name}: ${e.message}`, s),
                            h.appendChild(n)
                        }
                    }))
        },
        this.betterMessageBoxes.push(t),
        t
    }
    getBetterMessageBox(e) {
        for (const t of this.betterMessageBoxes)
            if (t.appendMessage(e))
                return t;
        return this.bmsgbox(e)
    }
    updateText(e = "", t = "") {
        const s = this.nodeView.querySelectorAll(".msgbox[type=warn]").length + this.betterMessageBoxes.reduce(((e, t) => e + t.list.length - 1), 0);
        "error" === t ? (this.nodeText.className = "error", this.nodeText.innerText = e) : (this.nodeText.className = s ? "warning" : "accept", this.nodeText.innerText = e + (s ? `（发现${s}个问题，点击查看）` : ""), this.lastMessage = e)
    }
    sendWarning(e = "", t = !1) {
        "string" == typeof e ? this.msgbox(t ? e : Utils.escapeHTML(e), "warn") : this.getBetterMessageBox(e).updateHTML(),
        this.updateText(this.lastMessage)
    }
    sendError(e = "", t = "", s = !1) {
        if (t) {
            const e = /([A-Za-z][A-Za-z+-.]{2,}:\/\/|www\.)[^\s\x00-\x20\x7f-\x9f"]{2,}[^\s\x00-\x20\x7f-\x9f"!'),.:;?\]}]/g,
            n = t.replace(e, ((e = "") => {
                        const t = e.startsWith("www.") ? `//${e}` : e,
                        s = e.replace(`${location.origin}/`, "");
                        return e.includes(location.origin) ? `<a href="#"style="color:#023b8f;text-decoration:underline;">${s}</a>` : `<a href="${t}"target="_blank"style="color:#023b8f;text-decoration:underline;">${s}</a>`
                    }));
            this.msgbox(n, "error", s)
        }
        this.updateText(e, "error")
    }
}
const fe = {
    sp: [0, 0],
    ez: [1, 7],
    hd: [3, 13],
    in: [6, 15],
    at: [13, 16]
}, ue = ["ez", "hd", "in", "at"], pe = ["PhiEX", ver.split("."), 1611795955, 1727753598];
self._i = pe;
const ge = e => document.getElementById(e) || (() => {
    throw new Error(`Cannot find element: ${e}`)
})(), me = e => document.body.querySelector(e), ve = ge("view-nav"), be = ge("view-cfg"), we = ge("view-msg"), ye = ge("view-nav2"), xe = ge("view-rmg"), ke = ge("view-ext"), Le = ge("cover-dark"), Se = ge("cover-rmg"), Ee = ge("cover-view"), Te = ge("btn-rmg"), Me = ge("btn-docs"), Ce = ge("btn-more"), Ae = ge("nav-cfg"), Be = ge("nav-msg"), Re = ge("nav-rmg"), Ie = ge("msg-out"), De = ge("uploader"), Fe = ge("stage"), Pe = ge("select-note-scale"), Ne = ge("select-aspect-ratio"), je = ge("select-background-dim"), Oe = ge("highLight"), $e = ge("input-offset"), He = ge("lineColor"), Xe = ge("autoplay"), Ye = ge("showTransition"), _e = ge("feedback"), ze = ge("imageBlur"), Ue = ge("select-bg"), Ve = ge("btn-play"), qe = ge("btn-pause"), We = ge("select-bgm"), Je = ge("select-chart"), Ze = ge("select-flip"), Ge = ge("select-speed"), Ke = ge("input-name"), Qe = ge("input-artist"), et = ge("input-charter"), tt = ge("input-illustrator"), st = ge("select-difficulty"), nt = ge("select-level"), it = new class {
    constructor(e, s) {
        t(this, "selectDifficulty"),
        t(this, "selectLevel"),
        t(this, "text", ""),
        this.selectDifficulty = e,
        this.selectLevel = s,
        //Object.keys(fe).forEach((e => this.selectDifficulty.add(new Option(e.toUpperCase()))));
        //for (let e = 0; e < 17; e++) this.selectLevel.add(new Option(String(e || "?")));
        this.selectDifficulty.addEventListener("change", (() => this.updateInternal(0))),
        this.selectLevel.addEventListener("change", (() => this.updateInternal(1))),
        this.updateInternal(-1)
    }
    updateInternal(e) {
        /*let t = (this.selectDifficulty.value || "SP").toLowerCase(),
        s = 0 | Number(this.selectLevel.value);
        if (0 === e) {
            const e = fe[t];
            s < e[0] && (s = e[0]),
            s > e[1] && (s = e[1]),
            this.selectLevel.value = String(s || "?")
        } else
            1 === e && (fe[t][1] < s ? t = ue.find((e => fe[e][1] >= s)) || "sp" : fe[t][0] > s && (t = ue.findLast((e => fe[e][0] <= s)) || "sp"), this.selectDifficulty.value = t.toUpperCase());
        const n = this.selectDifficulty.value,
        i = this.selectLevel.value;
        this.text = [n, i].join("Lv.")
		*/
		this.text = this.selectDifficulty.value + ' ' + this.selectLevel.value;
    }
    updateLevelText(e) {
        this.text = e;
        const t = this.text.toUpperCase().split("LV.").map((e => e.trim()));
        t[0] && (this.selectDifficulty.value = t[0]),
        t[1] && (this.selectLevel.value = t[1])
    }
    getDifficultyIndex() {
        return ["ez", "hd", "in", "at"].indexOf(this.text.slice(0, 2).toLowerCase())
    }
    getLevelNumber() {
        return Number(/\d+$/.exec(this.text))
    }
}(st, nt),
at = ge("select-volume"),
ot = ge("uploader-select"),
rt = ge("uploader-upload"),
lt = ge("uploader-file"),
ct = ge("uploader-dir"),
ht = ge("select"),
dt = ge("mask"),
ft = e => Math.sin(e * Math.PI / 2),
ut = e => 1 + (e - 1) ** 3,
pt = (e = 0) => `${Math.floor(e / 60)}:${`00${Math.floor(e % 60)}`.slice(-2)}`,
gt = {modify : e => e,pressTime : 0};
gt.before = new Map, gt.now = new Map, gt.after = new Map, gt.afterAll = new Map, gt.end = new Map, gt.filter = null, gt.filterOptions = {}, document.oncontextmenu = e => e.preventDefault();
for (const e of ve.children)
    e.addEventListener("click", (function () {
            for (const e of ve.children)
                e.classList.toggle("active", e === this);
            be.classList.toggle("hide", "nav-cfg" !== this.id),
            we.classList.toggle("hide", "nav-msg" !== this.id)
        }));
for (const e of ye.children)
    e.addEventListener("click", (function () {
            for (const e of ye.children)
                e.classList.toggle("active", e === this);
            xe.classList.toggle("hide", "nav-rmg" !== this.id),
            ke.classList.toggle("hide", "nav-ext" !== this.id)
        }));
Le.addEventListener("click", (() => {
        Le.classList.add("fade"),
        Se.classList.add("fade"),
        Ee.classList.add("fade")
    })), Te.addEventListener("click", (() => {
        Le.classList.remove("fade"),
        Se.classList.remove("fade"),
        Re.click()
    })), Me.addEventListener("click", (() => {
        gt.fireModal("<p>提示</p>", '<p><a href="https://docs.lchzh.net/project/sim-phi-core" target="_blank">点击此处</a>查看使用说明</p>')
    })), Ce.addEventListener("click", (() => {
        Le.classList.remove("fade"),
        Ee.classList.remove("fade"),
        Ae.click()
    })), Ie.addEventListener("click", (() => {
        Le.classList.remove("fade"),
        Ee.classList.remove("fade"),
        Be.click()
    }));
const mt = new class extends de {
    constructor() {
        super(...arguments),
        t(this, "nodeView", we),
        t(this, "nodeText", Ie)
    }
}, vt = mt.updateText.bind(mt), bt = mt.sendWarning.bind(mt), wt = mt.sendError.bind(mt), yt = new j, xt = new class {
    constructor(e) {
        t(this, "aspectRatio"),
        t(this, "isFull"),
        t(this, "stage"),
        this.aspectRatio = 0,
        this.isFull = !1,
        this.stage = e,
        this.resize()
    }
    resize(e = 0) {
        this.aspectRatio = e || this.aspectRatio || 16 / 9;
        const t = self.devicePixelRatio || 1,
        s = Math.min(854, .8 * document.body.getBoundingClientRect().width),
        n = Math.round(s * t),
        i = n / t,
        a = Math.ceil(n / this.aspectRatio) / t;
        this.isFull ? this.stage.style.cssText = ";position:fixed;top:0;left:0;bottom:0;right:0" : this.stage.style.cssText = `;width:${i.toFixed(3)}px;height:${a.toFixed(3)}px`
    }
    getFull() {
        return this.isFull
    }
    setFull(e) {
        return this.isFull = e
    }
}
(Fe), app = new class {
    constructor(e) {
        if (t(this, "stage"), t(this, "canvas"), t(this, "ctx"), t(this, "canvasfg"), t(this, "ctxfg"), t(this, "wlen"), t(this, "hlen"), t(this, "scaleX"), t(this, "scaleY"), t(this, "width"), t(this, "height"), t(this, "matX"), t(this, "matY"), t(this, "matR"), t(this, "speed"), t(this, "lineScale"), t(this, "noteScale"), t(this, "noteScaleRatio"), t(this, "brightness"), t(this, "multiHint"), t(this, "playMode"), t(this, "musicVolume"), t(this, "soundVolume"), t(this, "enableFR"), t(this, "enableVP"), t(this, "lowResFactor"), t(this, "lines"), t(this, "notes"), t(this, "taps"), t(this, "drags"), t(this, "flicks"), t(this, "holds"), t(this, "linesReversed"), t(this, "notesReversed"), t(this, "tapsReversed"), t(this, "dragsReversed"), t(this, "flicksReversed"), t(this, "holdsReversed"), t(this, "tapholds"), t(this, "chart"), t(this, "bgMusic"), t(this, "bgVideo"), t(this, "_mirrorType"), t(this, "initialized"), !(e instanceof HTMLDivElement))
            throw new Error("Not a container");
        const s = () => {
            throw new Error("Failed to initialize canvas")
        };
        this.stage = e,
        this.canvas = document.createElement("canvas"),
        this.ctx = this.canvas.getContext("2d", {
            alpha: !1
        }) || s(),
        this.canvasfg = document.createElement("canvas"),
        this.ctxfg = this.canvasfg.getContext("2d") || s(),
        this.stage.appendChild(this.canvas),
        this.canvas.style.cssText = ";position:absolute;top:0px;left:0px;right:0px;bottom:0px",
        console.log("Hello, Phixos!"),
        this.speed = 1,
        this.lineScale = 57.6,
        this.noteScale = 1,
        this.noteScaleRatio = 8e3,
        this.brightness = .6,
        this.multiHint = !0,
        this.playMode = 1,
        this.musicVolume = 1,
        this.soundVolume = 1,
        this._mirrorType = 0,
        this.enableFR = !1,
        this.enableVP = !1,
        this.chart = null,
        this.bgMusic = null,
        this.bgVideo = null,
        this.lines = [],
        this.notes = [],
        this.taps = [],
        this.drags = [],
        this.flicks = [],
        this.holds = [],
        this.linesReversed = [],
        this.notesReversed = [],
        this.tapsReversed = [],
        this.dragsReversed = [],
        this.flicksReversed = [],
        this.holdsReversed = [],
        this.tapholds = [],
        this.lowResFactor = 1,
        this.width = 0,
        this.height = 0,
        this.wlen = 0,
        this.hlen = 0,
        this.scaleX = 0,
        this.scaleY = 0,
        this.matX = e => e,
        this.matY = e => e,
        this.matR = e => e,
        this.initialized = !1,
        this._setLowResFactor(1),
        this.resizeCanvas()
    }
    get duration() {
        if (this.bgMusic)
            return this.bgMusic.duration;
        if (this.chart)
            return this.chart.maxSeconds + .5;
        throw new TypeError("Illegal state")
    }
    setNoteScale(e = 1) {
        this.noteScale = e,
        this.noteScaleRatio = this.canvasfg.width * this.noteScale / 8080
    }
    setLowResFactor(e = 1) {
        this._setLowResFactor(e),
        this._resizeCanvas()
    }
    resizeCanvas() {
        const {
            width: e,
            height: t
        } = this.stage.getBoundingClientRect();
        this.width === e && this.height === t || (this.width = e, this.height = t, this.canvas.style.cssText += `;width:${e.toFixed(3)}px;height:${t.toFixed(3)}px`, this._resizeCanvas())
    }
    mirrorView(e = this._mirrorType) {
        const t = 3 & e;
        this._mirrorType = t,
        this.transformView(1 & t ? -1 : 1, 2 & t ? -1 : 1, 0, 0)
    }
    transformView(e = 1, t = 1, s = 0, n = 0) {
        const {
            canvasfg: i
        } = this,
        a = i.width * e,
        o = .5 * (i.width - a),
        r = -i.height * t,
        l = .5 * (i.height - r),
        c = -Math.sign(e * t) * Math.PI / 180,
        h = t > 0 ? 0 : Math.PI,
        d = Math.sign(t) * a * .05625,
        f = Math.sign(t) * -r * .6;
        this.matX = e => o + a * (e - s),
        this.matY = e => l + r * (e - n),
        this.matR = e => h + c * e,
        this.scaleX = d,
        this.scaleY = f,
        this.initialized = !0
    }
    prerenderChart(e) {
		this.hold = [],
		this.nohold = [],
        this.lines.length = 0,
        this.notes.length = 0,
        this.taps.length = 0,
        this.drags.length = 0,
        this.flicks.length = 0,
        this.holds.length = 0,
        this.tapholds.length = 0;
        const t = e.duplicate();
        for (const e of t.judgeLineList) {
            let t = Math.fround(e.speedEvents[0].startTime / e.bpm * 1.875),
            s = t;
            for (const n of e.speedEvents) {
				n.value *= fallSpeed;
                n.floorPosition = t,
                n.floorPosition2 = s;
                const i = (n.endTime - n.startTime) / e.bpm * 1.875;
                t += i * n.value,
                s += Math.fround(Math.fround(i) * n.value),
                t = Math.fround(t),
                s = Math.fround(s)
            }
        }
        const s = {
            aniStart: 1e9,
            aniEnd: 0,
            hitStart: 1e9,
            hitEnd: 0
        },
        n = e => {
            e < s.aniStart && (s.aniStart = e),
            e > s.aniEnd && (s.aniEnd = e)
        },
        i = e => {
            n(e),
            e < s.hitStart && (s.hitStart = e),
            e > s.hitEnd && (s.hitEnd = e)
        },
        a = (e, t) => {
            for (const s of e)
                s.startSeconds = s.startTime / t * 1.875, s.endSeconds = s.endTime / t * 1.875, s.startTime > -999999 && n(s.startSeconds), s.endTime < 1e9 && s.endTime !== e[e.length - 1].endTime && n(s.endSeconds)
        },
        o = (e, t, s, n, a) => {
			if (!save && startTime && e.time * t < startTime + .5) return;
			switch (e.type) {
				case 1:
					if (tapReplace == 'random')  e.type = randomNote();
					else e.type = Number(tapReplace);
					if (e.type == 3) e.speed = this.hold.sort((a, b) => Math.abs(e.time - a.time) - Math.abs(e.time - b.time))[0].speed;
				break;
				case 2:
					if (dragReplace == 'random') e.type = randomNote();
					else e.type = Number(dragReplace);
					if (e.type == 3) e.speed = this.hold.sort((a, b) => Math.abs(e.time - a.time) - Math.abs(e.time - b.time))[0].speed;
				break;
				case 3:
					if (holdReplace == 'random')  e.type = randomNote();
					else e.type = Number(holdReplace);
					if (e.type != 3) e.speed = this.nohold.sort((a, b) => Math.abs(e.time - a.time) - Math.abs(e.time - b.time))[0].speed;
				break;
				case 4:
					if (flickReplace == 'random')  e.type = randomNote();
					else e.type = Number(flickReplace);
					if (e.type == 3) e.speed = this.hold.sort((a, b) => Math.abs(e.time - a.time) - Math.abs(e.time - b.time))[0].speed;
				break;
			}
			e.speed *= e.type == 3 ? fallSpeed : 1,
			e.floorPosition *= fallSpeed,
            e.offsetX = 0,
            e.offsetY = 0,
            e.alpha = 0,
            e.seconds = e.time * t,
            e.holdSeconds = e.holdTime * t,
            e.maxVisiblePos = (e => {
                const t = Math.fround(e);
                if (!isFinite(t))
                    throw new TypeError("Argument must be a finite number");
                const s = 11718.75,
                n = t >= s ? 2 ** Math.floor(1 + Math.log2(t / s)) : 1,
                i = t / n + .001,
                a = Math.fround(i);
                if (a <= i)
                    return a * n;
                const o = new Float32Array([i]);
                return new Uint32Array(o.buffer)[0] += o[0] <= 0 ? 1 : -1,
                o[0] * n
            })(e.floorPosition),
            e.time < 1e9 && (i(e.seconds), i(e.seconds + e.holdSeconds)),
            e.line = s,
            e.lineId = s.lineId,
            e.noteId = n,
            e.isAbove = a,
            e.name = `${s.lineId}${a?"+":"-"}${n}${"?tdhf"[e.type]}`,
            this.notes.push(e),
            1 === e.type ? this.taps.push(e) : 2 === e.type ? this.drags.push(e) : 3 === e.type ? this.holds.push(e) : 4 === e.type && this.flicks.push(e),
            (1 === e.type || 3 === e.type) && this.tapholds.push(e)
        },
        r = (e, t) => e.seconds - t.seconds || e.lineId - t.lineId || e.noteId - t.noteId;
        t.judgeLineList.forEach(((e, t) => e.lineId = t));
		for (const e of t.judgeLineList) {
			for (const i of e.notesAbove) if (i.type == 3) this.hold.push(i); else this.nohold.push(i);
			for (const i of e.notesBelow) if (i.type == 3) this.hold.push(i); else this.nohold.push(i);
		}
		this.hold = JSON.parse(JSON.stringify(this.hold));
		this.nohold = JSON.parse(JSON.stringify(this.nohold));
        for (const e of t.judgeLineList)
            e.bpm *= this.speed, e.offsetX = 0, e.offsetY = 0, e.alpha = 0, e.rotation = 0, e.positionY = 0, e.positionY2 = 0, e.disappearEventsIndex = 0, e.moveEventsIndex = 0, e.rotateEventsIndex = 0, e.speedEventsIndex = 0, a(e.speedEvents, e.bpm), a(e.judgeLineDisappearEvents, e.bpm), a(e.judgeLineMoveEvents, e.bpm), a(e.judgeLineRotateEvents, e.bpm), this.lines.push(e), e.notesAbove.forEach(((t, s) => o(t, 1.875 / e.bpm, e, s, !0))), e.notesBelow.forEach(((t, s) => o(t, 1.875 / e.bpm, e, s, !1)));
        this.notes.sort(r),
        this.taps.sort(r),
        this.drags.sort(r),
        this.holds.sort(r),
        this.flicks.sort(r),
        this.notesReversed = this.notes.toReversed(),
        this.tapsReversed = this.taps.toReversed(),
        this.dragsReversed = this.drags.toReversed(),
        this.holdsReversed = this.holds.toReversed(),
        this.flicksReversed = this.flicks.toReversed(),
        this.linesReversed = this.lines.toReversed(),
        this.tapholds.sort(r);
        const l = {};
        for (const e of this.notes)
            l[e.seconds.toFixed(6)] = l[e.seconds.toFixed(6)] ? 2 : 1;
        for (const e of this.notes)
            e.isMulti = 2 === l[e.seconds.toFixed(6)];
        for (let e = 0; e < this.flicks.length; e++) {
            const t = this.flicks[e];
            t.nearNotes = [];
            for (let s = e + 1; s < this.flicks.length; s++) {
                const e = this.flicks[s];
                if (Math.fround(e.seconds - t.seconds) > .01)
                    break;
                t.nearNotes.push(e)
            }
        }
        for (let e = 0; e < this.tapholds.length; e++) {
            const t = this.tapholds[e];
            t.nearNotes = [];
            for (let s = e + 1; s < this.tapholds.length; s++) {
                const e = this.tapholds[s];
                if (Math.fround(e.seconds - t.seconds) > .01)
                    break;
                t.nearNotes.push(e)
            }
        }
        this.chart = t,
        this.chart.maxSeconds = s.aniEnd,
        console.table(s)
    }
    seekLineEventIndex(e) {
        if (!this.initialized)
            throw new Error("Not initialized");
        for (const t of this.lines)
            if (t.speedEventsIndex = 0, t.disappearEventsIndex = 0, t.moveEventsIndex = 0, t.rotateEventsIndex = 0, null != e) {
                for (; t.speedEventsIndex < t.speedEvents.length && t.speedEvents[t.speedEventsIndex].endSeconds < e; )
                    t.speedEventsIndex++;
                for (; t.disappearEventsIndex < t.judgeLineDisappearEvents.length && t.judgeLineDisappearEvents[t.disappearEventsIndex].endSeconds < e; )
                    t.disappearEventsIndex++;
                for (; t.moveEventsIndex < t.judgeLineMoveEvents.length && t.judgeLineMoveEvents[t.moveEventsIndex].endSeconds < e; )
                    t.moveEventsIndex++;
                for (; t.rotateEventsIndex < t.judgeLineRotateEvents.length && t.judgeLineRotateEvents[t.rotateEventsIndex].endSeconds < e; )
                    t.rotateEventsIndex++
            }
    }
    updateByTime(e) {
        if (!this.initialized)
            throw new Error("Not initialized");
        for (const t of this.lines) {
            for (let s = t.disappearEventsIndex, n = t.judgeLineDisappearEvents.length; s < n; s++) {
                const n = t.judgeLineDisappearEvents[s];
                if (e > n.endSeconds)
                    continue;
                const i = (e - n.startSeconds) / (n.endSeconds - n.startSeconds);
                t.alpha = n.start + (n.end - n.start) * i,
                t.alpha > 1 && (t.alpha = 1),
                t.disappearEventsIndex = s;
                break
            }
            for (let s = t.moveEventsIndex, n = t.judgeLineMoveEvents.length; s < n; s++) {
                const n = t.judgeLineMoveEvents[s];
                if (e > n.endSeconds)
                    continue;
                const i = (e - n.startSeconds) / (n.endSeconds - n.startSeconds);
                t.offsetX = this.matX(n.start + (n.end - n.start) * i),
                t.offsetY = this.matY(n.start2 + (n.end2 - n.start2) * i),
                t.moveEventsIndex = s;
                break
            }
            for (let s = t.rotateEventsIndex, n = t.judgeLineRotateEvents.length; s < n; s++) {
                const n = t.judgeLineRotateEvents[s];
                if (e > n.endSeconds)
                    continue;
                const i = (e - n.startSeconds) / (n.endSeconds - n.startSeconds);
                t.rotation = this.matR(n.start + (n.end - n.start) * i),
                t.cosr = Math.cos(t.rotation),
                t.sinr = Math.sin(t.rotation),
                t.rotateEventsIndex = s;
                break
            }
            for (let s = t.speedEventsIndex, n = t.speedEvents.length; s < n; s++) {
                const n = t.speedEvents[s];
                if (!(e > n.endSeconds)) {
                    t.positionY = (e - n.startSeconds) * this.speed * n.value + (this.enableFR ? n.floorPosition2 : n.floorPosition),
                    t.positionY2 = (e - n.startSeconds) * this.speed * n.value + n.floorPosition2,
                    t.speedEventsIndex = s;
                    break
                }
            }
            const s = s => 3 !== s.type ? (s.floorPosition - t.positionY) * s.speed : s.seconds < e ? (s.seconds - e) * this.speed * s.speed : s.floorPosition - t.positionY,
            n = e => null == e.badTime ? s(e) : (performance.now() - e.badTime > 500 && delete e.badTime, null == e.badY && (e.badY = s(e)), e.badY),
            i = (n, i, a) => {
                if (n.projectX = t.offsetX + i * n.cosr, n.offsetX = n.projectX + a * n.sinr, n.projectY = t.offsetY + i * n.sinr, n.offsetY = n.projectY - a * n.cosr, n.visible = (n.offsetX - this.wlen) ** 2 + (n.offsetY - this.hlen) ** 2 < (1.23625 * this.wlen + this.hlen + this.scaleY * n.holdSeconds * this.speed * n.speed) ** 2, n.showPoint = !1, null == n.badTime)
                    if (n.seconds > e) {
                        n.showPoint = !0;
                        const e = n.maxVisiblePos < t.positionY2;
                        n.alpha = e || this.enableVP && .6 * s(n) > 2 || 3 === n.type && 0 === n.speed ? 0 : 1
                    } else
                        n.frameCount = null == n.frameCount ? 0 : n.frameCount + 1, 3 === n.type ? (n.showPoint = !0, n.alpha = 0 === n.speed ? 0 : n.status % 4 == 2 ? .45 : 1) : n.alpha = Math.max(1 - (e - n.seconds) / badEarly, 0)
            };
            for (const e of t.notesAbove)
                e.cosr = t.cosr, e.sinr = t.sinr, i(e, this.scaleX * e.positionX, this.scaleY * n(e));
            for (const e of t.notesBelow)
                e.cosr = -t.cosr, e.sinr = -t.sinr, i(e, -this.scaleX * e.positionX, this.scaleY * n(e))
        }
    }
    _setLowResFactor(e = 1) {
        this.lowResFactor = e
    }
    _resizeCanvas() {
        const {
            canvas: e,
            canvasfg: t,
            width: s,
            height: n
        } = this,
        i = this.lowResFactor * self.devicePixelRatio,
        a = s * i,
        o = n * i;
        e.width = a,
        e.height = o,
        t.width = Math.min(a, 16 * o / 9),
        t.height = o,
        this.wlen = t.width / 2,
        this.hlen = t.height / 2,
        this.mirrorView(),
        this.setNoteScale(this.noteScale),
        this.lineScale = t.width > .75 * t.height ? t.height / 18.75 : t.width / 14.0625
    }
}
(Fe), {
    canvas: Lt,
    ctx: St,
    canvasfg: canvasos,
    ctxfg: ctxos
} = app;
self.addEventListener("resize", (() => xt.resize()));
class Mt extends EventTarget {
    constructor(e = "") {
        super(),
        t(this, "status"),
        this.status = e
    }
    emit(e = "") {
        this.status !== e && (this.status = e, this.dispatchEvent(new Event("change")))
    }
    eq(e = "") {
        return this.status === e
    }
    ne(e = "") {
        return this.status !== e
    }
}
const Ct = new Mt("stop"), At = {
    text: "",
    list: [],
    reg(e, t, s) {
        this.list[this.list.length] = {
            toString: () => s(e)
        },
        e.addEventListener(t, this.update.bind(this))
    },
    update() {
        const e = this.list.map(String).filter(Boolean);
        this.text = 0 === e.length ? "" : `(${e.join("+")})`
    }
};
class Bt {
    constructor(e) {
        t(this, "base"),
        t(this, "width"),
        t(this, "height"),
        t(this, "_blur"),
        this.base = e,
        this.width = e.width,
        this.height = e.height,
        this._blur = null
		this._betterBlur = null;
    }
    get blur() {
        return this.setBetterBlur(), this.setBlur(), (bb.checked ? this._betterBlur : this._blur) || this.base
    }
    async setBlur() {
        this.setBlur = async() => {},
        this._blur = await async function (e) {
            const t = W(e.width, e.height), {
                width: s,
                height: n
            } = t.canvas;
            return t.drawImage(e, 0, 0),
            function (e, t, s, n, i, a) {
                if (!(isNaN(a) || a < 1)) {
                    a |= 0;
                    var o = function (e, t, s, n, i) {
                        if ("string" == typeof e && (e = document.getElementById(e)), !e || "object" !== J(e) || !("getContext" in e))
                            throw new TypeError("Expecting canvas with `getContext` method in processCanvasRGB(A) calls!");
                        var a = e.getContext("2d");
                        try {
                            return a.getImageData(0, 0, n, i)
                        } catch (e) {
                            throw new Error("unable to access image data: " + e)
                        }
                    }
                    (e, 0, 0, n, i);
                    o = function (e, t, s, n, i, a) {
                        for (var o, r = e.data, l = 2 * a + 1, c = n - 1, h = i - 1, d = a + 1, f = d * (d + 1) / 2, u = new Q, p = u, g = 1; g < l; g++)
                            p = p.next = new Q, g === d && (o = p);
                        p.next = u;
                        for (var m = null, v = null, b = 0, w = 0, y = G[a], x = K[a], k = 0; k < i; k++) {
                            p = u;
                            for (var L = r[w], S = r[w + 1], E = r[w + 2], T = r[w + 3], M = 0; M < d; M++)
                                p.r = L, p.g = S, p.b = E, p.a = T, p = p.next;
                            for (var C = 0, A = 0, B = 0, R = 0, I = d * L, D = d * S, F = d * E, P = d * T, N = f * L, j = f * S, O = f * E, $ = f * T, H = 1; H < d; H++) {
                                var X = w + ((c < H ? c : H) << 2),
                                Y = r[X],
                                _ = r[X + 1],
                                z = r[X + 2],
                                U = r[X + 3],
                                V = d - H;
                                N += (p.r = Y) * V,
                                j += (p.g = _) * V,
                                O += (p.b = z) * V,
                                $ += (p.a = U) * V,
                                C += Y,
                                A += _,
                                B += z,
                                R += U,
                                p = p.next
                            }
                            m = u,
                            v = o;
                            for (var q = 0; q < n; q++) {
                                var W = $ * y >>> x;
                                if (r[w + 3] = W, 0 !== W) {
                                    var J = 255 / W;
                                    r[w] = (N * y >>> x) * J,
                                    r[w + 1] = (j * y >>> x) * J,
                                    r[w + 2] = (O * y >>> x) * J
                                } else
                                    r[w] = r[w + 1] = r[w + 2] = 0;
                                N -= I,
                                j -= D,
                                O -= F,
                                $ -= P,
                                I -= m.r,
                                D -= m.g,
                                F -= m.b,
                                P -= m.a;
                                var Z = q + a + 1;
                                Z = b + (Z < c ? Z : c) << 2,
                                N += C += m.r = r[Z],
                                j += A += m.g = r[Z + 1],
                                O += B += m.b = r[Z + 2],
                                $ += R += m.a = r[Z + 3],
                                m = m.next;
                                var ee = v,
                                te = ee.r,
                                se = ee.g,
                                ne = ee.b,
                                ie = ee.a;
                                I += te,
                                D += se,
                                F += ne,
                                P += ie,
                                C -= te,
                                A -= se,
                                B -= ne,
                                R -= ie,
                                v = v.next,
                                w += 4
                            }
                            b += n
                        }
                        for (var ae = 0; ae < n; ae++) {
                            var oe = r[w = ae << 2],
                            re = r[w + 1],
                            le = r[w + 2],
                            ce = r[w + 3],
                            he = d * oe,
                            de = d * re,
                            fe = d * le,
                            ue = d * ce,
                            pe = f * oe,
                            ge = f * re,
                            me = f * le,
                            ve = f * ce;
                            p = u;
                            for (var be = 0; be < d; be++)
                                p.r = oe, p.g = re, p.b = le, p.a = ce, p = p.next;
                            for (var we = n, ye = 0, xe = 0, ke = 0, Le = 0, Se = 1; Se <= a; Se++) {
                                w = we + ae << 2;
                                var Ee = d - Se;
                                pe += (p.r = oe = r[w]) * Ee,
                                ge += (p.g = re = r[w + 1]) * Ee,
                                me += (p.b = le = r[w + 2]) * Ee,
                                ve += (p.a = ce = r[w + 3]) * Ee,
                                Le += oe,
                                ye += re,
                                xe += le,
                                ke += ce,
                                p = p.next,
                                Se < h && (we += n)
                            }
                            w = ae,
                            m = u,
                            v = o;
                            for (var Te = 0; Te < i; Te++) {
                                var Me = w << 2;
                                r[Me + 3] = ce = ve * y >>> x,
                                ce > 0 ? (ce = 255 / ce, r[Me] = (pe * y >>> x) * ce, r[Me + 1] = (ge * y >>> x) * ce, r[Me + 2] = (me * y >>> x) * ce) : r[Me] = r[Me + 1] = r[Me + 2] = 0,
                                pe -= he,
                                ge -= de,
                                me -= fe,
                                ve -= ue,
                                he -= m.r,
                                de -= m.g,
                                fe -= m.b,
                                ue -= m.a,
                                Me = ae + ((Me = Te + d) < h ? Me : h) * n << 2,
                                pe += Le += m.r = r[Me],
                                ge += ye += m.g = r[Me + 1],
                                me += xe += m.b = r[Me + 2],
                                ve += ke += m.a = r[Me + 3],
                                m = m.next,
                                he += oe = v.r,
                                de += re = v.g,
                                fe += le = v.b,
                                ue += ce = v.a,
                                Le -= oe,
                                ye -= re,
                                xe -= le,
                                ke -= ce,
                                v = v.next,
                                w += n
                            }
                        }
                        return e
                    }
                    (o, 0, 0, n, i, a),
                    e.getContext("2d").putImageData(o, 0, 0)
                }
            }
            (t.canvas, 0, 0, s, n, Math.ceil(.0125 * Math.min(s, n))),
            createImageBitmap(t.canvas)
        }(this.base)
    }
	async setBetterBlur() {
        this.setBetterBlur = async() => {}
		const canvas = document.createElement('canvas');
		const {width, height} = this.base;
		let w, h;
		if (ge('fixBg').checked == true) {
			w = canvas.width;
			h = canvas.height;
		} else {
			//const scale = 1920 / Math.max(height * 16 / 9, 1920);
			//const w = canvas.width = width * scale;
			//const h = canvas.height = height * scale;
			const imgAspectRatio = width / height;
			h = canvas.height = Math.min(1080, height);
			w = canvas.width = h * imgAspectRatio;
		}
		const ctx = canvas.getContext('2d');
		ctx.drawImage(this.base, 0, 0, canvas.width, canvas.height);
		StackBlur.canvasRGBA(canvas, 0, 0, w, h, Math.ceil(Math.min(w, h) * 0.15));
		createImageBitmap(canvas).then((e) => this._betterBlur = e);
    }
}
const Rt = new Map, It = new Map, Dt = new Map, Ft = new Map, Pt = new Map, Nt = [], jt = [];
Pe.addEventListener("change", (e => app.setNoteScale(Number(e.target.value)))), Ne.addEventListener("change", (e => xt.resize(Number(e.target.value)))), je.addEventListener("change", (e => app.brightness = Number(e.target.value))), Oe.addEventListener("change", (e => app.multiHint = e.target.checked));
const Ot = new class {
    constructor(e) {
        t(this, "key"),
        t(this, "data"),
        this.key = e,
        this.data = {}
    }
    init(e) {
        var t;
        return this.data = JSON.parse(null !== (t = localStorage.getItem(this.key)) && void 0 !== t ? t : "{}"),
        "function" == typeof e && e(this.data) && this.reset(),
        this
    }
    save() {
        localStorage.setItem(this.key, JSON.stringify(this.data))
    }
    reset() {
        this.data = {},
        this.save()
    }
    get(e) {
        return this.data[e]
    }
    set(e, t) {
        this.data[e] = t,
        this.save()
    }
    reg(e, t, s = !0) {
        if (t instanceof HTMLInputElement || t instanceof HTMLSelectElement) {
            const n = "checkbox" === t.type ? "checked" : "value",
            i = this.get(e);
            void 0 !== i && (t[n] = i),
            t.addEventListener("change", (() => {
                    this.set(e, t[n])
                })),
            s && t.dispatchEvent(new Event("change"))
        } else {
            if (!(t instanceof HTMLTextAreaElement))
                throw new Error("Node must be <input>, <select> or <textarea>"); {
                const n = this.get(e);
                void 0 !== n && (t.value = n),
                t.addEventListener("change", (() => {
                        this.set(e, t.value)
                    })),
                s && t.dispatchEvent(new Event("change"))
            }
        }
    }
}
("sim-phi-status").init((e => e.resetCfg));
Ot.reg("feedback", _e), Ot.reg("imageBlur", ze), Ot.reg("highLight", Oe), Ot.reg("lineColor", He), Ot.reg("autoplay", Xe), Ot.reg("showTransition", Ye);
const $t = new ne("恢复默认设置(刷新生效)").appendTo(be).hook(Ot.reg.bind(Ot, "resetCfg")), Ht = new ne("Early/Late特效").appendBefore($t.container).hook(Ot.reg.bind(Ot, "showCE2")), Xt = new ne("显示定位点").appendBefore($t.container).hook(Ot.reg.bind(Ot, "showPoint")), Yt = new ne("显示Acc").appendBefore($t.container).hook(Ot.reg.bind(Ot, "showAcc")), _t = new ne("显示统计").appendBefore($t.container).hook(Ot.reg.bind(Ot, "showStat")), zt = new ne("低分辨率").appendBefore($t.container).hook(Ot.reg.bind(Ot, "lowRes")), Ut = new ne("横屏锁定", !0).appendBefore($t.container).hook(Ot.reg.bind(Ot, "lockOri")), Vt = new ne("限制帧率").appendBefore($t.container).hook(Ot.reg.bind(Ot, "maxFrame")), qt = new ne("音画实时同步(若声音卡顿则建议关闭)", !0).appendBefore($t.container).hook(Ot.reg.bind(Ot, "autoDelay")), Wt = new ne("隐藏距离较远的音符").appendBefore($t.container).hook(Ot.reg.bind(Ot, "enableVP"));
Wt.checkbox.addEventListener("change", (e => app.enableVP = e.target.checked)), Wt.checkbox.dispatchEvent(new Event("change"));
const Jt = new ne("使用单精度浮点运算").appendBefore($t.container).hook(Ot.reg.bind(Ot, "enableFR"));
function Zt() {
    for (const e of jt)
        Je.value.trim() === e.chart && (null != e.name && (Ke.value = e.name), null != e.artist && (Qe.value = e.artist), null != e.level && it.updateLevelText(e.level), null != e.illustrator && (tt.value = e.illustrator), null != e.charter && (et.value = e.charter), null != e.music && It.has(e.music) && (We.value = e.music), null != e.image && Rt.has(e.image) && (Ue.value = e.image, Ue.dispatchEvent(new Event("change"))), null != e.aspectRatio && (Ne.value = e.aspectRatio.toString(), xt.resize(e.aspectRatio)), null != e.noteScale && (Pe.value = e.noteScale.toString(), app.setNoteScale(e.noteScale)), null != e.backgroundDim && (je.value = e.backgroundDim.toString(), app.brightness = e.backgroundDim), null != e.offset && ($e.value = e.offset.toString()))
}
Jt.checkbox.addEventListener("change", (e => app.enableFR = e.target.checked)),
Jt.checkbox.dispatchEvent(new Event("change")), 
Ze.addEventListener("change", (e => app.mirrorView(Number(e.target.value)))),
Ot.reg("selectFlip", Ze),
Ge.addEventListener("change", (e => {
    var t;
    for (let i = 0; i < e.target.options.length; i++) if (e.target.options[i].value == 'x' + app.speed) e.target.options.remove(i);
	app.speed = 2 ** ((null !== (t = {slowest: -9, slower: -4, faster: 3, fastest: 5} [e.target.value.toLowerCase()]) && void 0 !== t ? t : 0) / 12);
	if (e.target.selectedIndex == 6) {
        app.speed = Number(prompt('speed'));
		e.target.options.add(new Option('x' + app.speed + '(自定义)', 'x' + app.speed));
		e.target.selectedIndex = 7;
    }
}));
const Gt = new B;
!function () {
    const e = {},
    t = {};
    let s = 0,
    n = 0;
    const i = async(i, a, o, r) => {
        t[i] = a,
        n = Object.values(t).reduce(((e, t) => e + t), 0),
        await(o instanceof Promise ? o : Promise.resolve(o)),
        e[i] = (e[i] || 0) + 1,
        s = Object.values(e).reduce(((e, t) => e + t), 0),
        vt(`读取文件：${s}/${n}`),
        e[i] === t[i] && null != r && r(),
        h()
    };
    gt.handleFile = i;
    let a = 0;
    const o = {
        createAudioBuffer: async e => V.decode(e)
    },
    r = new R({
        handler: async e => D.read(e, o)
    });
    function l(e) {
        switch (console.log(e), e.type) {
        case "line":
            Nt.push(...e.data);
            break;
        case "info":
            jt.push(...e.data);
            break;
        case "media": {
                const t = d(e.pathname, It);
                It.set(t, e.data),
                We.appendChild(c(t, e.pathname)),
                We.dispatchEvent(new Event("change"));
                break
            }
        case "image": {
                const t = d(e.pathname, Rt);
                Rt.set(t, new Bt(e.data)),
                Ue.appendChild(c(t, e.pathname)),
                Ue.dispatchEvent(new Event("change"));
                break
            }
        case "chart": {
                e.msg && e.msg.forEach((t => {
                        bt("string" == typeof t ? t : {
                            ...t,
                            target: e.pathname
                        })
                    })),
                e.info && jt.push(...e.info),
                e.line && Nt.push(...e.line);
                const t = d(e.pathname, Dt);
                Dt.set(t, e.data),
                Ft.set(t, e.md5),
                Pt.set(t, e.format),
                Je.appendChild(c(t, e.pathname)),
                Je.dispatchEvent(new Event("change"));
                break
            }
        default:
            console.warn(`Unsupported file: ${e.pathname}`),
            console.log(e.data),
            bt(`不支持的文件：${e.pathname}\n${e.data||"Error: Unknown File Type"}`)
        }
    }
    function c(e, t) {
        const s = document.createElement("option"),
        n = /(^|\/)\./.test(t);
        return s.innerHTML = n ? "" : t,
        s.value = e,
        n && s.classList.add("hide"),
        s
    }
    function h() {
        s === n ? (De.classList.remove("disabled"), Zt()) : De.classList.add("disabled")
    }
    function d(e, t) {
        let s = e;
        for (; t.has(s); )
            s += "\n";
        return s
    }
    r.addEventListener("loadstart", (() => vt("加载zip组件..."))),
    r.addEventListener("read", (e => {
            i("zip", r.total, l(e.detail))
        })),
    rt.addEventListener("click", Gt.uploadFile.bind(Gt)),
    lt.addEventListener("click", Gt.uploadFile.bind(Gt)),
    ct.addEventListener("click", Gt.uploadDir.bind(Gt)),
    Gt.addEventListener("change", h),
    Gt.addEventListener("progress", (e => {
            if (!e.total)
                return;
            const t = Math.floor(e.loaded / e.total * 100);
            vt(`加载文件：${t}% (${Vs(e.loaded)}/${Vs(e.total)})`)
        })),
    Gt.addEventListener("load", (e => {
            const {
                file: {
                    name: t,
                    webkitRelativePath: s
                },
                buffer: n
            } = e,
            c = n.byteLength > 4 && 1347093252 === new DataView(n).getUint32(0, !1),
            h = {
                pathname: s || t,
                buffer: n
            };
            c ? r.read(h) : (async() => {
                a++;
                const e = await D.read(h, o);
                await i("file", a, l(e))
            })()
        }))
}
(), gt.uploader = Gt;
const Kt = String(pe[1][3]).startsWith("b"), Qt = "./src/pack.json";
const es = new class {
    constructor() {
        t(this, "list"),
        this.list = []
    }
    activate(e, t, s, n) {
        const {
            list: i
        } = this,
        a = i.findIndex((s => s.type === e && s.id === t));
        -1 !== a && i.splice(a, 1),
        i.push(new P(e, t, s, n))
    }
    moving(e, t, s, n) {
        const i = this.list.find((s => s.type === e && s.id === t));
        i && i.move(s, n)
    }
    deactivate(e, t) {
        const s = this.list.find((s => s.type === e && s.id === t));
        s && (s.isActive = !1)
    }
    update() {
        const {
            list: e
        } = this;
        for (let t = 0; t < e.length; t++) {
            const s = e[t];
            s.isActive ? (s.isTapped = !0, s.isMoving = !1) : e.splice(t--, 1)
        }
    }
    clear(e) {
        for (const t of this.list)
            t.type === e && this.deactivate(e, t.id)
    }
}, ts = () => {
    n.onchange && document.removeEventListener(n.onchange, ts),
    es.clear("keyboard"),
    xt.setFull(n.check()),
    xt.resize()
}, qwqIn = new o, ns = new o, is = new o
window.as = {
    time: [0, 0, 0, 0],
    func: [async() => Promise.resolve().then(Ws), async() => Promise.resolve().then(qs).then(qs), async() => Promise.resolve().then((() => save ? createSave() : _t.toggle())), async() => {
            const e = xt.getFull();
            try {
                if (await n.toggle(), !xt.setFull(n.check()) || (n.onchange && document.addEventListener(n.onchange, ts), !Ut.checked))
                    return;
                await i.lockLandscape()
            } catch (t) {
                console.warn(t),
                xt.setFull(!e)
            } finally {
                xt.resize()
            }
        }
    ],
    click(e) {
        const t = performance.now();
        t - this.time[e] < 300 && this.func[e]().catch((e => {
                console.warn(e);
                const t = e instanceof Error ? e.message : String(e);
                gt.toast(`按太多下了！(${t})`)
            })),
        this.time[e] = t
    },
    activate(e, t) {
        const {
            lineScale: s
        } = app;
        e < 1.5 * s && t < 1.5 * s && this.click(0),
        e > canvasos.width - 1.5 * s && t < 1.5 * s && this.click(1),
        e < 1.5 * s && t > canvasos.height - 1.5 * s && this.click(2),
        e > canvasos.width - 1.5 * s && t > canvasos.height - 1.5 * s && this.click(3),
        is.second > 0 && (gt.pressTime = gt.pressTime > 0 ? -is.second : is.second)
    }
};
function os(e, t) {
    const {
        offsetX: s,
        offsetY: n
    } = e, {
        offsetX: i,
        offsetY: a,
        cosr: o,
        sinr: r
    } = t;
    return Math.abs((s - i) * o + (n - a) * r) || 0
}
function rs(e, t) {
    const {
        offsetX: s,
        offsetY: n
    } = e, {
        offsetX: i,
        offsetY: a,
        cosr: o,
        sinr: r
    } = t;
    return Math.abs((s - i) * o + (n - a) * r) + Math.abs((s - i) * r - (n - a) * o) || 0
}
const ls = {};
let cs = 0, hs = 0, ds = 0, fs = 0, us = 0, ps = 0, gs = !1, ms = !1, vs = !1;
const bs = new q, ws = new q, ys = new class {
    constructor() {
        t(this, "tick"),
        t(this, "time"),
        t(this, "fps"),
        this.tick = 0,
        this.time = performance.now(),
        this.fps = 0
    }
    get fpsStr() {
        const {
            fps: e
        } = this;
        return e < 10 ? e.toPrecision(2) : e.toFixed(0)
    }
    get disp() {
        return .5 / this.fps || 0
    }
    addTick(e = 10) {
        return ++this.tick >= e && (this.tick = 0, this.fps = 1e3 * e / (-this.time + (this.time = performance.now()))),
        this.fps
    }
}, xs = new class {
    constructor() {
        t(this, "callback"),
        t(this, "lastTime"),
        t(this, "interval"),
        t(this, "id"),
        this.callback = () => {},
        this.lastTime = 0,
        this.interval = Number.EPSILON,
        this.id = null,
        this._animate = this._animate.bind(this)
    }
    start() {
        null === this.id && (this.lastTime = performance.now(), this.id = requestAnimationFrame(this._animate.bind(this)))
    }
    stop() {
        null !== this.id && (cancelAnimationFrame(this.id), this.id = null)
    }
    setCallback(e) {
        if ("function" != typeof e)
            throw new TypeError("callback is not a function");
        this.callback = e
    }
    setFrameRate(e) {
        this.interval = Math.abs(1e3 / e),
        isFinite(this.interval) || (this.interval = Number.EPSILON)
    }
    _animate() {
        this.id = requestAnimationFrame(this._animate.bind(this));
        const e = performance.now(),
        t = e - this.lastTime;
        t > this.interval && (this.lastTime = e - t % this.interval, this.callback(e))
    }
};
xs.setCallback((function () {
		const lineScale = app.lineScale
        ys.addTick();
        const {
            lineScale: e
        } = app;
        if (cs = performance.now(), app.resizeCanvas(), ns.second < .67) {
            !function () {
                if (null == app.chart)
                    throw new Error("Not initialized: Chart");
                !gs && qwqIn.second >= 3 && Ct.eq("play") && (gs = !0, Ts(app.bgMusic), null != app.bgVideo && Ms(app.bgVideo)),
                Ct.eq("play") && gs && !ms && (fs = hs + (cs - ds) / 1e3),
                fs < 0 && (fs = 0),
                fs >= ps && (ms = !0),
                Ye.checked && ms && !vs && (vs = !0, ns.play()),
                us = Math.max(fs - (app.chart.offset + Number($e.value) / 1e3 || 0) / app.speed, 0),
                app.updateByTime(us),
                Rs.update(),
                Cs.update(),
                As.update();
                for (const e of es.list)
                    "keyboard" !== e.type && (e.isTapped ? e.isMoving ? Rs.add(ae.move(e.offsetX, e.offsetY)) : e.isActive && Rs.add(ae.hold(e.offsetX, e.offsetY)) : Rs.add(ae.tap(e.offsetX, e.offsetY)));
                if (gs) {
                    const e = judgeWidth * canvasos.width;
                    Bs.addEvent(app.notes, us),
                    Bs.execute(app.drags, us, e),
                    Bs.execute(app.flicks, us, e),
                    Bs.execute(app.tapholds, us, e)
                }
                es.update(),
                Es.bgImage = Ps.getImageBlur(),
                Es.bgVideo = app.bgVideo,
                Es.progress = (gt.awawa ? ps - fs : fs) / ps,
                Es.name = Ke.value || Ke.placeholder,
                Es.artist = Qe.value,
                Es.illustrator = `Illustration designed by ${tt.value||tt.placeholder}`,
                Es.charter = `Level designed by ${et.value||et.placeholder}`,
                Es.level = it.text,
                yt.combo > 2 ? (Es.combo = `${yt.combo}`, Es.combo2 = 1 === app.playMode ? "Autoplay" : "combo") : (Es.combo = "", Es.combo2 = ""),
                Es.showStat = !0,
                Es.customForeDraw = null,
                Es.customBackDraw = null
            }
            ();
            for (const e of gt.now.values())
                e(fs * app.speed);
            !function () {
                const {
                    lineScale: e,
                    wlen: t,
                    hlen: s
                } = app, {
                    bgImage: n,
                    bgVideo: i
                } = Es;
                if (ctxos.clearRect(0, 0, canvasos.width, canvasos.height), ctxos.globalAlpha = 1, ctxos.drawImage(n, ...ce(n, canvasos, 1)), gs && null != i && !gt.awawa) {
                    const {
                        videoWidth: e,
                        videoHeight: t
                    } = i;
                    ctxos.drawImage(i, ...ce({
                            width: e,
                            height: t
                        }, canvasos, 1))
                }
                if (qwqIn.second >= 2.5 && !yt.lineStatus && Ns(0, e), ctxos.resetTransform(), ctxos.fillStyle = "#000", ctxos.globalAlpha = app.brightness, ctxos.fillRect(0, 0, canvasos.width, canvasos.height), qwqIn.second >= 2.5 && null != Es.customBackDraw && Es.customBackDraw(ctxos), qwqIn.second >= 2.5 && Ns(yt.lineStatus ? 2 : 1, e), ctxos.resetTransform(), qwqIn.second >= 3 && 0 === ns.second && (function () {
					if (hideNote) return;
                        for (const e of app.holds)
                            Xs(e, us);
                            for (const e of app.dragsReversed)
                                Hs(e);
                            for (const e of app.tapsReversed)
                                $s(e);
                            for (const e of app.flicksReversed)
                                Ys(e)
                        }
                            (), Xt.checked)) {
                        ctxos.font = `${e}px Custom,Noto Sans SC`,
                        ctxos.textAlign = "center";
                        for (const t of app.linesReversed)
                            ctxos.setTransform(t.cosr, t.sinr, -t.sinr, t.cosr, t.offsetX, t.offsetY), ctxos.globalAlpha = 1, ctxos.fillStyle = "violet", ctxos.fillRect(.2 * -e, .2 * -e, .4 * e, .4 * e), ctxos.fillStyle = "yellow", ctxos.globalAlpha = (t.alpha + .5) / 1.5, ctxos.fillText(t.lineId.toString(), 0, .3 * -e);
                        for (const t of app.notesReversed)
                            t.visible && (ctxos.setTransform(t.cosr, t.sinr, -t.sinr, t.cosr, t.offsetX, t.offsetY), ctxos.globalAlpha = 1, ctxos.fillStyle = "lime", ctxos.fillRect(.2 * -e, .2 * -e, .4 * e, .4 * e), ctxos.fillStyle = "cyan", ctxos.globalAlpha = t.seconds > us ? 1 : .5, ctxos.fillText(t.name, 0, .3 * -e))
                    }
                Cs.animate(),
                Ht.checked && As.animate(),
                ctxos.globalAlpha = 1,
                ctxos.setTransform(canvasos.width / 1920, 0, 0, canvasos.width / 1920, 0, e * (qwqIn.second < .67 ? ft(1.5 * qwqIn.second) - 1 : -ft(1.5 * ns.second)) * 1.75),
                ctxos.drawImage(ls.ProgressBar, 1920 * Es.progress - 1920, 0),
                ctxos.resetTransform();
                for (const e of gt.after.values())
                    e();
                if (ctxos.fillStyle = "#fff", qwqIn.second < 3) {
                    qwqIn.second < .67 ? ctxos.globalAlpha = ft(1.5 * qwqIn.second) : qwqIn.second >= 2.5 && (ctxos.globalAlpha = ft(6 - 2 * qwqIn.second)),
                    ctxos.textAlign = "center",
                    js(Es.name, t, .75 * s, 1.1 * e, canvasos.width - 1.5 * e),
                    js(Es.artist, t, .75 * s + 1.25 * e, .55 * e, canvasos.width - 1.5 * e),
                    js(Es.illustrator, t, 1.25 * s + .55 * e, .55 * e, canvasos.width - 1.5 * e),
                    js(Es.charter, t, 1.25 * s + 1.4 * e, .55 * e, canvasos.width - 1.5 * e),
                    ctxos.globalAlpha = 1,
                    ctxos.setTransform(1, 0, 0, 1, t, s);
                    const n = 48 * e * (qwqIn.second < .67 ? (e => 1 - Math.cos(e * Math.PI / 2))(1.5 * qwqIn.second) : 1),
                    i = .15 * e;
                    qwqIn.second >= 2.5 && (ctxos.globalAlpha = ft(6 - 2 * qwqIn.second)),
                    ctxos.drawImage(He.checked ? ls.JudgeLineMP : ls.JudgeLine, -n / 2, -i / 2, n, i)
                }
                ctxos.globalAlpha = 1,
                ctxos.setTransform(1, 0, 0, 1, 0, e * (qwqIn.second < .67 ? ft(1.5 * qwqIn.second) - 1 : -ft(1.5 * ns.second)) * 1.75),
                Es.showStat && (ctxos.font = .95 * e + "px Custom,Noto Sans SC", ctxos.textAlign = "right", ctxos.fillText(yt.scoreStr, canvasos.width - .65 * e, 1.375 * e), Yt.checked && (ctxos.font = .66 * e + "px Custom,Noto Sans SC", ctxos.fillText(yt.accStr, canvasos.width - .65 * e, 2.05 * e))),
                ctxos.textAlign = "center",
                ctxos.font = 1.32 * e + "px Custom,Noto Sans SC",
                ctxos.fillText(Es.combo, t, 1.375 * e),
                ctxos.globalAlpha = qwqIn.second < .67 ? ft(1.5 * qwqIn.second) : 1 - ft(1.5 * ns.second),
                ctxos.font = .66 * e + "px Custom,Noto Sans SC",
                ctxos.fillText(Es.combo2, t, 2.05 * e),
                ctxos.globalAlpha = 1,
                ctxos.setTransform(1, 0, 0, 1, 0, e * (qwqIn.second < .67 ? 1 - ft(1.5 * qwqIn.second) : ft(1.5 * ns.second)) * 1.75),
                ctxos.textAlign = "right",
                js(Es.level, canvasos.width - .75 * e, canvasos.height - .66 * e, .63 * e, t - e),
                ctxos.textAlign = "left",
                js(Es.name, .65 * e, canvasos.height - .66 * e, .63 * e, t - e),
                ctxos.resetTransform(),
                ctxos.fillStyle = "#fff",
                qwqIn.second < .67 ? ctxos.globalAlpha = ft(1.5 * qwqIn.second) : ctxos.globalAlpha = 1 - ft(1.5 * ns.second),
                ctxos.font = .4 * e + "px Custom,Noto Sans SC",
                ctxos.textAlign = "left",
                Es.showStat && _t.checked ? (() => {
					ctxos.fillText(`${pt(gt.awawa?ps-fs:fs)}/${pt(ps)}${At.text}`, .05 * e, .6 * e);
					ctxos.fillText(yt.format, canvasos.width - 4.35 * e, .6 * e);
					ctxos.textAlign = "right";
					ctxos.fillText(ys.fpsStr, canvasos.width - .05 * e, .6 * e);
				})() : 114514,
                Es.showStat && _t.checked && (ctxos.textAlign = "right", [yt.noteRank[6], yt.noteRank[7], yt.noteRank[5], yt.noteRank[4], yt.noteRank[1], yt.noteRank[3], yt.noteRank[2]].forEach(((t, s) => {
                            ctxos.fillStyle = ["#fe7b93", "#0ac3ff", "lime", "#f0ed69", "lime", "#0ac3ff", "#999"][s],
                            ctxos.fillText(t.toString(), canvasos.width - .05 * e, canvasos.height / 2 + e * (s - 2.8) * .5)
                        })), ctxos.fillStyle = "#fff", ctxos.textAlign = "left", ctxos.fillText(`DSP:  ${yt.curDispStr}`, .05 * e, canvasos.height / 2 - .15 * e), ctxos.fillText(`AVG:  ${yt.avgDispStr}`, .05 * e, canvasos.height / 2 + .35 * e), ctxos.textAlign = "center", yt.combos.forEach(((t, s) => {
                            ctxos.fillStyle = ["#fff", "#0ac3ff", "#f0ed69", "#a0e9fd", "#fe4365"][s],
                            ctxos.fillText(t.toString(), e * (s + .55) * 1.1, canvasos.height - .1 * e)
                        }))),
                qwqIn.second >= 2.5 && qwqIn.second < 3 ? ctxos.globalAlpha = 1 - ft(6 - 2 * qwqIn.second) : ctxos.globalAlpha = 1 - ft(1.5 * ns.second),
                qwqIn.second >= 2.5 && null != Es.customForeDraw && Es.customForeDraw(ctxos),
                qwqIn.second >= 2.5 && null != gt.filter && gt.filter(ctxos, fs, cs / 1e3),
                _e.checked && Rs.animate(),
                ctxos.resetTransform(),
				ctxos.drawImage(pause, lineScale * 0.6, lineScale * 0.7, lineScale * 0.63, lineScale * 0.7),
				qwqIn.isPaused ? (() => {
					ctxos.fillStyle = '#000';
					ctxos.globalAlpha = 0.5;
					ctxos.fillRect(0, 0, canvasos.width, canvasos.height);
					ctxos.globalAlpha = 1;
					ctxos.font = `${lineScale * 0.75}px Saira, SyHybrid, Noto Sans SC`;
					ctxos.fillStyle = '#FFF';
					ctxos.globalAlpha = 1;
					ctxos.textAlign = 'center';
					ctxos.textBaseline = 'middle';
					ctxos.fillText('Game Paused', canvasos.width / 2, canvasos.height / 2);
					ctxos.textAlign = 'right';
					ctxos.textBaseline = 'alphabetic';
				})() : 114514;
            }
            ()
        }
        null != Ss && function (e) {
            ctxos.resetTransform(),
            ctxos.clearRect(0, 0, canvasos.width, canvasos.height),
            ctxos.globalAlpha = 1;
            const t = Ps.getImageBlur();
            ctxos.drawImage(t, ...ce(t, canvasos, 1)),
            ctxos.fillStyle = "#000",
            ctxos.globalAlpha = app.brightness,
            ctxos.fillRect(0, 0, canvasos.width, canvasos.height),
            ctxos.globalCompositeOperation = "destination-out",
            ctxos.globalAlpha = 1;
            const s = 3.7320508075688776;
            ctxos.setTransform(canvasos.width - canvasos.height / s, 0, -canvasos.height / s, canvasos.height, canvasos.height / s, 0),
            ctxos.fillRect(0, 0, 1, ut(Os(.94 * (is.second - .13)))),
            ctxos.resetTransform(),
            ctxos.globalCompositeOperation = "destination-over";
            const n = (canvasos.width - canvasos.height / s) / (16 - 9 / s);
            ctxos.setTransform(n / 120, 0, 0, n / 120, app.wlen - 8 * n, app.hlen - 4.5 * n),
            ctxos.drawImage(ls.LevelOver4, 183, 42, 1184, 228),
            ctxos.globalAlpha = Os((is.second - .27) / .83),
            ctxos.drawImage(ls.LevelOver1, 102, 378),
            ctxos.globalCompositeOperation = "source-over",
            ctxos.globalAlpha = 1,
            ctxos.drawImage(ls.LevelOver5, 700 * ut(Os(1.25 * is.second)) - 369, 91, 20, 80),
            ctxos.fillStyle = "#fff",
            ctxos.textAlign = "left",
            js(Ke.value || Ke.placeholder, 700 * ut(Os(1.25 * is.second)) - 320, 160, 80, 1500);
            const i = js(it.text, 700 * ut(Os(1.25 * is.second)) - 317, 212, 30, 750);
            ctxos.font = "30px Custom,Noto Sans SC",
            ctxos.globalAlpha = Os(3.75 * (is.second - 1.87));
            const a = 293 + 100 * Os(3.75 * (is.second - 1.87)),
            o = 410 - 164 * Os(2.14 * (is.second - 1.87));
            ctxos.drawImage(ls.LevelOver3, 661 - a / 2, 545 - a / 2, a, a),
            ctxos.drawImage(ls.Ranks[yt.rankStatus], 661 - o / 2, 545 - o / 2, o, o),
            ctxos.globalAlpha = Os(2.5 * (is.second - .87)),
            ctxos.fillStyle = e.newBestColor,
            ctxos.fillText(e.newBestStr, 898, 433),
            ctxos.fillStyle = "#fff",
            ctxos.textAlign = "center",
            ctxos.fillText(e.scoreBest, 1180, 433),
            ctxos.globalAlpha = Os(2.5 * (is.second - 1.87)),
            ctxos.textAlign = "right",
            ctxos.fillText(e.scoreDelta, 1414, 433),
            ctxos.globalAlpha = Os(1.5 * (is.second - .95)),
            ctxos.textAlign = "left",
            ctxos.fillText(yt.accStr, 352, 550),
            ctxos.fillText(yt.maxcombo.toString(), 1528, 550),
            ctxos.fillStyle = e.textAboveColor,
            ctxos.fillText(1 === app.speed ? "" : e.textAboveStr.replace("{SPEED}", app.speed.toFixed(2)), 383 + Math.min(i, 750), 212),
            ctxos.fillStyle = e.textBelowColor,
            ctxos.fillText(e.textBelowStr, 1355, 595),
            ctxos.fillStyle = "#fff",
            ctxos.textAlign = "center",
            ctxos.font = "86px Custom,Noto Sans SC",
            ctxos.globalAlpha = Os(2 * (is.second - 1.12)),
            ctxos.fillText(yt.scoreStr, 1075, 569),
            ctxos.font = "26px Custom,Noto Sans SC",
            ctxos.globalAlpha = Os(2.5 * (is.second - .87)),
            ctxos.fillText(yt.perfect.toString(), 891, 650),
            ctxos.globalAlpha = Os(2.5 * (is.second - 1.07)),
            ctxos.fillText(yt.good.toString(), 1043, 650),
            ctxos.globalAlpha = Os(2.5 * (is.second - 1.27)),
            ctxos.fillText(yt.noteRank[6].toString(), 1196, 650),
            ctxos.globalAlpha = Os(2.5 * (is.second - 1.47)),
            ctxos.fillText(yt.noteRank[2].toString(), 1349, 650),
            ctxos.font = "22px Custom,Noto Sans SC";
            const r = Os(5 * (gt.pressTime > 0 ? is.second - gt.pressTime : .2 - is.second - gt.pressTime));
            ctxos.globalAlpha = .8 * Os(2.5 * (is.second - .87)) * r,
            ctxos.fillStyle = "#696",
            ctxos.fill(new Path2D("M841,718s-10,0-10,10v80s0,10,10,10h100s10,0,10-10v-80s0-10-10-10h-40l-10-20-10,20h-40z")),
            ctxos.globalAlpha = .8 * Os(2.5 * (is.second - 1.07)) * r,
            ctxos.fillStyle = "#669",
            ctxos.fill(new Path2D("M993,718s-10,0-10,10v80s0,10,10,10h100s10,0,10-10v-80s0-10-10-10h-40l-10-20-10,20h-40z")),
            ctxos.fillStyle = "#fff",
            ctxos.globalAlpha = Os(2.5 * (is.second - .97)) * r,
            ctxos.fillText(`Early: ${yt.noteRank[5]}`, 891, 759),
            ctxos.fillText(`Late: ${yt.noteRank[1]}`, 891, 792),
            ctxos.globalAlpha = Os(2.5 * (is.second - 1.17)) * r,
            ctxos.fillText(`Early: ${yt.noteRank[7]}`, 1043, 759),
            ctxos.fillText(`Late: ${yt.noteRank[3]}`, 1043, 792),
            ctxos.resetTransform(),
            ctxos.globalCompositeOperation = "destination-over",
            ctxos.globalAlpha = 1,
            ctxos.fillStyle = "#000";
            const l = Ps.getImage();
            ctxos.drawImage(l, ...ce(l, canvasos, 1)),
            ctxos.fillRect(0, 0, canvasos.width, canvasos.height),
            ctxos.globalCompositeOperation = "source-over"
        }
        (Ss),
        St.globalAlpha = 1;
        const t = Ps.getImageBlur();
        St.drawImage(t, ...ce(t, Lt, 1.1)),
        St.fillStyle = "#000",
        St.globalAlpha = .4,
        St.fillRect(0, 0, Lt.width, Lt.height),
        St.globalAlpha = 1,
        St.drawImage(canvasos, (Lt.width - canvasos.width) / 2, 0);
        for (const e of gt.afterAll.values())
            e();
        St.globalCompositeOperation = "difference",
        St.font = .4 * e + "px Custom,Noto Sans SC",
        St.fillStyle = "#fff",
        St.globalAlpha = .8,
        St.textAlign = "right",
        St.fillText(Es.showStat && _t.checked ? `${pe[0]} v${pe[1].join(".")} - Code by lchzh3473 & memzzmem` : '', (Lt.width + canvasos.width) / 2 - .1 * e, Lt.height - .1 * e),
        St.globalCompositeOperation = "source-over"
    }));
const ks = () => {
    "hidden" === document.visibilityState && Ct.eq("play") && Ws()
};
document.addEventListener("visibilitychange", ks), document.addEventListener("pagehide", ks);
let Ls = !1, Ss = null;
const Es = {
    bgImage: null,
    bgVideo: null,
    bgMusicHack: e => {},
    progress: 0,
    name: "",
    artist: "",
    illustrator: "",
    charter: "",
    level: "",
    combo: "",
    combo2: "",
    showStat: !1,
    customForeDraw: null,
    customBackDraw: null
};
function Ts(e, t) {
    ds = performance.now(),
    null != e && (Es.bgMusicHack = bs.play(e, {
            offset: (null != t ? t : 0) || 0,
            playbackrate: app.speed,
            interval: qt.checked ? 1 : 0
        }))
}
async function Ms(e, t) {
    e.currentTime = (null != t ? t : 0) || 0,
    e.playbackRate = app.speed,
    e.muted = !0,
    await e.play()
}
const Cs = new ie({
    updateCallback: e => cs >= e.time + e.duration,
    iterateCallback(e) {
        var t;
        const s = (cs - e.time) / e.duration, {
            effects: n
        } = e;
        ctxos.globalAlpha = 1,
        ctxos.setTransform(6 * app.noteScaleRatio, 0, 0, 6 * app.noteScaleRatio, e.offsetX, e.offsetY),
        (null !== (t = n[Math.floor(s * n.length)]) && void 0 !== t ? t : n[n.length - 1]).full(ctxos),
        ctxos.fillStyle = e.color,
        ctxos.globalAlpha = 1 - s;
        const i = 30 * (((.2078 * s - 1.6524) * s + 1.6399) * s + .4988);
        for (const t of e.direction) {
            const e = t[0] * (9 * s / (8 * s + 1));
            ctxos.fillRect(e * Math.cos(t[1]) - i / 2, e * Math.sin(t[1]) - i / 2, i, i)
        }
    }
}), As = new ie({
    updateCallback: e => cs >= e.time + e.duration,
    iterateCallback(e) {
        const t = (cs - e.time) / e.duration;
        ctxos.setTransform(1, 0, 0, 1, e.offsetX, e.offsetY),
        ctxos.font = `bold ${app.noteScaleRatio*(256+128*(((.2078*t-1.6524)*t+1.6399)*t+.4988))}px Custom,Noto Sans SC`,
        ctxos.textAlign = "center",
        ctxos.fillStyle = e.color,
        ctxos.globalAlpha = 1 - t,
        ctxos.fillText(e.text, 0, 128 * -app.noteScaleRatio)
    }
}), Bs = {
    list: [],
    addEvent(e, t) {
        const {
            list: s
        } = this;
        if (s.length = 0, 1 === app.playMode) {
            const n = Math.min(ys.disp, .04);
            for (const i of e) {
                if (i.scored)
                    continue;
                const e = i.seconds - t;
                1 === i.type ? e < n && (s[s.length] = new N(i.offsetX, i.offsetY, 1)) : 2 === i.type ? e < n && (s[s.length] = new N(i.offsetX, i.offsetY, 2)) : 3 === i.type ? i.holdTapTime ? s[s.length] = new N(i.offsetX, i.offsetY, 2) : e < n && (s[s.length] = new N(i.offsetX, i.offsetY, 1)) : 4 === i.type && e < n && (s[s.length] = new N(i.offsetX, i.offsetY, 3))
            }
        } else if (Ct.eq("play"))
            for (const e of es.list)
                e.isTapped || (s[s.length] = new N(e.offsetX, e.offsetY, 1)), e.isActive && (s[s.length] = new N(e.offsetX, e.offsetY, 2)), "keyboard" === e.type && (s[s.length] = new N(e.offsetX, e.offsetY, 3)), e.flicking && !e.flicked && (s[s.length] = new N(e.offsetX, e.offsetY, 3, e))
    },
    execute(e, t, s) {
        const {
            list: n
        } = this;
        for (const i of e) {
            if (i.scored) continue;
            const e = i.seconds - t;
            if (e > jumpTime || qwqIn.isPaused || noJudge) break;
			if (preventBad) for (const e of n) e.preventBad = !0;
            if (!(1 !== i.type && e > badEarly))
                if (e < badLate && i.frameCount > 4 && !i.holdStatus)
                    i.status = 2, yt.addCombo(2, i.type, i.index), i.scored = !0;
                else if (2 === i.type) {
                    if (e > 0)
                        for (const e of n) 1 === e.type && (os(e, i) > s || (e.preventBad = !0));
                    if (4 !== i.status) {
                        for (const e of n)
                            if (2 === e.type && !(os(e, i) > s)) {
                                i.status = 4;
                                break
                            }
                    } else
                        e < 0 && (ws.play(ls.HitSong1), fuck(), Cs.add(oe.perfect(i.projectX, i.projectY, i)), yt.addCombo(4, 2, i.index), i.scored = !0)
                } else if (4 === i.type) {
                    if (e > 0 || 4 !== i.status)
                        for (const e of n)
                            1 === e.type && (os(e, i) > s || (e.preventBad = !0));
                    if (4 !== i.status)
                        for (const e of n) {
                            if (3 !== e.type || os(e, i) > s)
                                continue;
                            let n = rs(e, i),
                            a = i,
                            o = !1;
                            for (const r of i.nearNotes) {
                                if (r.status)
                                    continue;
                                if (r.seconds - t > badEarly)
                                    break;
                                if (os(e, r) > s)
                                    continue;
                                const i = rs(e, r);
                                i < n && (n = i, a = r, o = !0)
                            }
                            if (null == e.event) {
                                if (a.status = 4, !o)
                                    break
                            } else if (!e.event.flicked && (a.status = 4, e.event.flicked = !0, !o))
                                break
                        }
                    else
                        e < 0 && (ws.play(ls.HitSong2), fuck(), Cs.add(oe.perfect(i.projectX, i.projectY, i)), yt.addCombo(4, 4, i.index), i.scored = !0)
                } else {
                    if (3 === i.type && i.holdTapTime) {
                        if ((performance.now() - i.holdTapTime) * i.holdTime >= 16e3 * i.holdSeconds && (i.holdStatus % 4 == 0 || i.holdStatus % 4 == 1 ? Cs.add(oe.perfect(i.projectX, i.projectY, i)) : i.holdStatus % 4 == 3 && Cs.add(oe.good(i.projectX, i.projectY, i)), i.holdTapTime = performance.now()), e + i.holdSeconds < .2) {
                            i.status || yt.addCombo(i.status = i.holdStatus, 3, i.index),
                            e + i.holdSeconds < 0 && (i.scored = !0);
                            continue
                        }
                        if (holdBroken) i.holdBroken = !0
                    }
                    for (const a of n) {
                        if (i.holdTapTime) {
                            if (2 !== a.type)
                                continue;
                            if (os(a, i) <= s) {
                                i.holdBroken = !1;
                                break
                            }
                            continue
                        }
                        if (1 !== a.type || a.judged || os(a, i) > s)
                            continue;
                        let n = e,
                        o = rs(a, i),
                        r = i,
                        l = !1;
                        for (const e of i.nearNotes) {
                            if (e.status || e.holdTapTime)
                                continue;
                            const i = e.seconds - t;
                            if (i > jumpTime)
                                break;
                            if (3 === e.type && i > badEarly || os(a, e) > s)
                                continue;
                            const c = rs(a, e);
                            c < o && (n = i, o = c, r = e, l = !0)
                        }
                        if (n > badEarly) {
                            if (a.preventBad)
                                continue;
                            r.status = 6,
                            r.badTime = performance.now()
                        } else {
                            const e = r;
                            yt.addDisp(Math.max(n, .04 * (-1 - e.frameCount) || 0)),
                            ws.play(ls.HitSong0), fuck(), 
                            n > goodEarly ? (e.holdStatus = 7, Cs.add(oe.good(e.projectX, e.projectY, e)), As.add(re.early(e.projectX, e.projectY))) : n > greatEarly ? (e.holdStatus = 5, Cs.add(oe.perfect(e.projectX, e.projectY, e)), As.add(re.early(e.projectX, e.projectY))) : n > greatLate || e.frameCount < 1 ? (e.holdStatus = 4, Cs.add(oe.perfect(e.projectX, e.projectY, e))) : n > goodLate || e.frameCount < 2 ? (e.holdStatus = 1, Cs.add(oe.perfect(e.projectX, e.projectY, e)), As.add(re.late(e.projectX, e.projectY))) : (e.holdStatus = 3, Cs.add(oe.good(e.projectX, e.projectY, e)), As.add(re.late(e.projectX, e.projectY))),
                            1 === e.type && (e.status = e.holdStatus)
                        }
                        if (r.status ? (yt.addCombo(r.status, 1, i.index), r.scored = !0) : (r.holdTapTime = performance.now(), r.holdBroken = !1), a.judged = !0, r.statOffset = n, !l)
                            break
                    }
                    Ct.eq("play") && i.holdTapTime && i.holdBroken && (i.status = 2, yt.addCombo(2, 3, i.index), i.scored = !0)
                }
        }
    }
}, Rs = new ie({
    updateCallback: e => e.time++ > 0,
    iterateCallback(e) {
        ctxos.globalAlpha = .85,
        ctxos.setTransform(1, 0, 0, 1, e.offsetX, e.offsetY),
        ctxos.fillStyle = e.color,
        ctxos.beginPath(),
        ctxos.arc(0, 0, .5 * app.lineScale, 0, 2 * Math.PI),
        ctxos.fill()
    }
}), Is = new s(Lt);
function Ds(e) {
    const t = Lt.getBoundingClientRect();
    return {
        x: (e.clientX - t.left) / Lt.offsetWidth * Lt.width - (Lt.width - canvasos.width) / 2,
        y: (e.clientY - t.top) / Lt.offsetHeight * Lt.height
    }
}
Is.setMouseEvent({
    mousedownCallback(e) {
        const t = e.button, {
            x: s,
            y: n
        } = Ds(e);
        1 === t ? es.activate("mouse", 4, s, n) : 2 === t ? es.activate("mouse", 2, s, n) : es.activate("mouse", 1 << t, s, n),
        as.activate(s, n)
    },
    mousemoveCallback(e) {
        const t = e.buttons, {
            x: s,
            y: n
        } = Ds(e);
        for (let e = 1; e < 32; e <<= 1) t & e ? es.moving("mouse", e, s, n) : es.deactivate("mouse", e);
		if (n / Lt.height < 0.05 && t && qwqIn.isPaused && timeChange) gt.time = s / Lt.width * ps;
    },
    mouseupCallback(e) {
        const t = e.button;
        1 === t ? es.deactivate("mouse", 4) : 2 === t ? es.deactivate("mouse", 2) : es.deactivate("mouse", 1 << t)
    }
}), Is.setKeyboardEvent({
    keydownCallback(e) {
		if (e.key == 'ArrowLeft') {
			gt.time -= 5; 
			return;
		}
		if (e.key == 'ArrowRight') {
			gt.time += 5; 
			return;
		}
		if (e.key == 'Backspace' && save) {
			createSave();
			return;
		}
		if (e.key == '-' && save) {
			as.func[1]();
			return;
		}
        Ct.eq("stop") || ("Shift" === e.key ? qe.click() : null == es.list.find((t => "keyboard" === t.type && t.id === e.code)) && es.activate("keyboard", e.code, NaN, NaN))
    },
    keyupCallback(e) {
        Ct.eq("stop") || "Shift" !== e.key && es.deactivate("keyboard", e.code)
    }
}), self.addEventListener("blur", (() => {
        es.clear("keyboard")
    })), Is.setTouchEvent({
    touchstartCallback(e) {
        for (const t of e.changedTouches) {
            const {
                x: e,
                y: s
            } = Ds(t);
            es.activate("touch", t.identifier, e, s),
            as.activate(e, s)
        }
    },
    touchmoveCallback(e) {
        for (const t of e.changedTouches) {
            const {
                x: e,
                y: s
            } = Ds(t);
            es.moving("touch", t.identifier, e, s)
			if (s / Lt.height < 0.05 && qwqIn.isPaused && timeChange && e / Lt.width * ps * 1.5 < ps) gt.time = e / Lt.width * ps * 1.5;
        }
    },
    touchendCallback(e) {
        for (const t of e.changedTouches)
            es.deactivate("touch", t.identifier)
    },
    touchcancelCallback(e) {
        for (const t of e.changedTouches)
            es.deactivate("touch", t.identifier)
    }
});

const Fs = {
    note: {},
    hitFX: {},
    async update(e, t, s, n = !1) {
        this.note[e] = new le(t, s, n),
        "Tap" === e && (this.note.TapBad = new le(await async function (e, t, s = 512) {
                const n = ee("#6c4343"),
                i = W(e.width, e.height, {
                    willReadFrequently: !0
                });
                i.drawImage(e, 0, 0);
                for (let t = 0; t < e.height; t += s)
                    for (let a = 0; a < e.width; a += s) {
                        const e = i.getImageData(a, t, s, s);
                        for (let t = 0; t < e.data.length / 4; t++)
                            e.data[4 * t] = n[0], e.data[4 * t + 1] = n[1], e.data[4 * t + 2] = n[2], e.data[4 * t + 3] *= n[3] / 255;
                        i.putImageData(e, a, t)
                    }
                return createImageBitmap(i.canvas)
            }
                    (t), s))
    },
    async updateFX(e, t, s, n, i = !1, a) {
        const o = await se(e, s, n),
        r = o.map((async e => new le(await te(e, "rgba(255,236,160,0.8823529)"), t))),
        l = o.map((async e => new le(await te(e, "rgba(180,225,255,0.9215686)"), t)));
        e.close(),
        this.hitFX.Perfect = {
            effects: await Promise.all(r),
            numOfParts: i ? 0 : 4,
            duration: 0 | Number(a) || 500
        },
        this.hitFX.Good = {
            effects: await Promise.all(l),
            numOfParts: i ? 0 : 3,
            duration: 0 | Number(a) || 500
        },
        o.forEach((e => e.close()))
    }
};
window.addEventListener("load", (() => {
        (async() => {
            if (Lt.classList.add("fade"), vt("初始化..."), await async function ({
                    messageCallback: e = e => {},
                    warnCallback: t = e => {},
                    errorCallback: s = (e, t, s) => {},
                    mobileCallback: n = () => {},
                    orientNotSupportCallback: o = () => {}
                } = {}) {
                const r = (e, t) => {
                    const n = (e => null === e ? "Null" : void 0 === e ? "Undefined" : e.constructor.name)(e);
                    let i = String(e),
                    a = String(e);
                    if (e instanceof Error) {
                        var o;
                        const t = null !== (o = e.stack) && void 0 !== o ? o : "Stack not available";
                        i = e.name === n ? e.message : `${e.name}: ${e.message}`;
                        const s = t.indexOf(i) + 1;
                        a = s ? `${i}\n${t.slice(s+i.length)}` : `${i}\n    ${t.split("\n").join("\n    ")}`
                    }
                    null != t && (i = t);
                    const r = `[${n}] ${i.split("\n")[0]}`,
                    l = `[${n}] ${a}`;
                    s(r, Utils.escapeHTML(l))
                };
                self.addEventListener("error", (e => r(e.error, e.message))),
                self.addEventListener("unhandledrejection", (e => r(e.reason)));
                const l = async(t, n, i) => {
                    if (!i())
                        return !0;
                    const a = `错误：${t}组件加载失败（点击查看详情）`,
                    o = `${t}组件加载失败，请检查您的网络连接然后重试：`,
                    r = `${t}组件加载失败，请检查浏览器兼容性`;
                    return e(`加载${t}组件...`),
                    await function (...e) {
                        const t = Array.from(e[0]instanceof Array ? e[0] : e, (e => new URL(e, location).href)),
                        s = function  * (e) {
                            yield * e
                        }
                        (t),
                        n = e => new Promise(((i, a) => {
                                    if (!e)
                                        return void a(new DOMException(`All urls are invalid\n${t.join("\n")}`, "NetworkError"));
                                        const o = document.createElement("script");
                                        o.onload = () => i(o),
                                        o.onerror = () => n(s.next().value).then((e => i(e))).catch((e => a(e))),
                                        o.src = e,
                                        location.port || (o.crossOrigin = "anonymous"),
                                        document.head.appendChild(o)
                                    }));
                            return n(s.next().value)
                        }
                        (n).catch((e => {
                                const t = e instanceof Error ? e.message : String(e);
                                s(a, t.replace(/.+/, o), !0)
                            })),
                        !i() || (s(a, r, !0), !1)
                    };
                    if (await Utils.addFont("Titillium Web", {
                            alt: "Custom"
                        }), e("检查浏览器兼容性..."), (void 0 !== navigator.standalone || navigator.platform.includes("Linux") && 5 === navigator.maxTouchPoints) && n(), function (e) {
                        if (navigator.userAgent.includes("MiuiBrowser")) {
                            const t = /MiuiBrowser\/(\d+\.\d+)/.exec(navigator.userAgent);
                            (null == t || parseFloat(t[1]) < 17.4) && e("检测到小米浏览器且版本低于17.4，可能存在切后台声音消失的问题")
                        }
                    }
                        (t), !await l("ImageBitmap兼容", `./js/lib/createImageBitmap.js?ver=${ver}`, (() => a("createImageBitmap"))))
                        return -1;
                    e("加载音频组件...");
                    const c = "" !== (new Audio).canPlayType("audio/ogg");
                    if (!await l("ogg格式兼容", `./js/lib/oggmented-bundle.js?ver=${ver}`, (() => !c && a("oggmented"))))
                        return -4;
                    V.init(c ? self.AudioContext : self.oggmented.OggmentedAudioContext);
                    const h = document.createElement("canvas").toDataURL("image/webp").includes("data:image/webp");
                    return await l("webp格式兼容", `./js/lib/webp-bundle.js?ver=${ver}`, (() => !h && a("webp"))) ? (await async function (e) {
                        await i.checkSupport() || e()
                    }
                        (o), 0) : -5
                }
                    ({
                        messageCallback: vt,
                        warnCallback: bt,
                        errorCallback: wt,
                        mobileCallback: () => ot.style.display = "none",
                        orientNotSupportCallback: () => {
                            Ut.checked = !1,
                            Ut.container.classList.add("disabled"),
                            Ut.label.textContent += "(当前设备或浏览器不支持)"
                        }
                    }))return;
            await import(`./reader.js?ver=${ver}`);
            const e = await async function (e) {
                const t = await(await fetch(e)).text();
                try {
                    return JSON.parse(t)
                } catch (e) {
                    return wt("错误：解析资源时出现问题（点击查看详情）", Utils.escapeHTML(`解析资源时出现问题：\n${e.message}\n原始数据：\n${t}`), !0),
                    null
                }
            }
            (Qt).catch((() => null)) || {
                image: {},
                audio: {},
                alternative: {},
                format: ""
            };
            await async function (e) {
                let t = 0,
                s = 0;
                const n = {};
                Object.assign(n, e.image),
                Object.assign(n, e.audio);
                const i = [];
                return "raw" === e.format ? (i.push(...Object.entries(e.image).map((async([e, n]) => {
                                const [a, o] = n.split("|");
                                console.log(a, o),
                                await fetch(a, {
                                    referrerPolicy: "no-referrer"
                                }).then((async e => e.blob())).then((async s => {
                                        const n = await createImageBitmap(s);
                                        ls[e] = n,
                                        vt(`加载资源：${Math.floor(t++/i.length*100)}%`)
                                    })).catch((() => {
                                        s++,
                                        bt(`资源加载失败，请检查您的网络连接然后重试：\n${new URL(a,location.toString()).toString()}`)
                                    }))
                            }))), i.push(...Object.entries(e.audio).map((async([e, n]) => {
                                await fetch(n, {
                                    referrerPolicy: "no-referrer"
                                }).then((async e => e.arrayBuffer())).then((async s => {
                                        ls[e] = await V.decode(s),
                                        vt(`加载资源：${Math.floor(t++/i.length*100)}%`)
                                    })).catch((() => {
                                        s++,
                                        bt(`资源加载失败，请检查您的网络连接然后重试：\n${new URL(n,location.toString()).toString()}`)
                                    }))
                            })))) : i.push(...Object.entries(n).map((async([n, a]) => {
                            const [o, r] = a.split("|");
                            await fetch(o, {
                                referrerPolicy: "no-referrer"
                            }).then((async e => e.blob())).then((async s => {
                                    const a = await createImageBitmap(s);
                                    if (null != r && r.startsWith("m")) {
                                        const t = Z.decode(a, Number(r.slice(1)));
                                        a.close(),
                                        ls[n] = await V.decode(t).catch((async t => {
                                                    const s = await fetch(e.alternative[n], {
                                                        referrerPolicy: "no-referrer"
                                                    }).then((async e => e.blob()));
                                                    return createImageBitmap(s).then(Z.decodeAlt).then((async e => V.decode(e))).catch((e => {
                                                            const t = e instanceof Error ? e : new Error("Unknown error");
                                                            return bt(`音频加载存在问题，将导致以下音频无法正常播放：\n${n}(${t.message})\n如果多次刷新问题仍然存在，建议更换设备或浏览器。`),
                                                            V.mute(1)
                                                        }))
                                                }))
                                    } else
                                        ls[n] = a;
                                    vt(`加载资源：${Math.floor(t++/i.length*100)}%`)
                                })).catch((e => {
                                    console.error(e),
                                    wt(`错误：${s++}个资源加载失败（点击查看详情）`, `资源加载失败，请检查您的网络连接然后重试：\n${new URL(o,location.toString()).toString()}`, !0)
                                }))
                        }))),
                await Promise.all(i), {
                    loadedNum: t,
                    errorNum: s
                }
            }
            (e),
            await async function (e, t) {
                const s = ["Tap", "TapHL", "Drag", "DragHL", "HoldHead", "HoldHeadHL", "Hold", "HoldHL", "HoldEnd", "Flick", "FlickHL", "HitFXRaw"];
                null == e.image && (e.image = {});
                const {
                    image: n
                } = e;
                for (const e of s)
                    null == n[e] && (n[e] = "|8080");
                if (null == t.Tap) {
                    const e = W(1089, 200);
                    e.lineWidth = 32,
                    e.strokeStyle = "#fff",
                    e.stroke(new Path2D("M 0 0 L 1089 0 L 1089 200 L 0 200 Z")),
                    e.strokeStyle = "#0ac3e1",
                    e.stroke(new Path2D("M 50 50 L 1039 50 L 1039 150 L 50 150 Z")),
                    t.Tap = await createImageBitmap(e.canvas)
                }
                if (null == t.TapHL) {
                    const e = W(1089, 200);
                    e.lineWidth = 32,
                    e.strokeStyle = "#fdfd66",
                    e.stroke(new Path2D("M 0 0 L 1089 0 L 1089 200 L 0 200 Z")),
                    e.strokeStyle = "#0ac3e1",
                    e.stroke(new Path2D("M 50 50 L 1039 50 L 1039 150 L 50 150 Z")),
                    t.TapHL = await createImageBitmap(e.canvas)
                }
                if (null == t.Drag) {
                    const e = W(1089, 160);
                    e.lineWidth = 32,
                    e.strokeStyle = "#fff",
                    e.stroke(new Path2D("M 0 0 L 1089 0 L 1089 160 L 0 160 Z")),
                    e.strokeStyle = "#f0ed69",
                    e.stroke(new Path2D("M 50 50 L 1039 50 L 1039 110 L 50 110 Z")),
                    t.Drag = await createImageBitmap(e.canvas)
                }
                if (null == t.DragHL) {
                    const e = W(1089, 160);
                    e.lineWidth = 32,
                    e.strokeStyle = "#fdfd66",
                    e.stroke(new Path2D("M 0 0 L 1089 0 L 1089 160 L 0 160 Z")),
                    e.strokeStyle = "#f0ed69",
                    e.stroke(new Path2D("M 50 50 L 1039 50 L 1039 110 L 50 110 Z")),
                    t.DragHL = await createImageBitmap(e.canvas)
                }
                if (null == t.HoldHead) {
                    const e = W(1089, 100);
                    e.lineWidth = 32,
                    e.strokeStyle = "#fff",
                    e.stroke(new Path2D("M 0 0 L 0 100 L 1089 100 L 1089 0")),
                    e.strokeStyle = "#96ebfc",
                    e.stroke(new Path2D("M 50 0 L 50 50 L 1039 50 L 1039 0")),
                    t.HoldHead = await createImageBitmap(e.canvas)
                }
                if (null == t.HoldHeadHL) {
                    const e = W(1089, 100);
                    e.lineWidth = 32,
                    e.strokeStyle = "#fdfd66",
                    e.stroke(new Path2D("M 0 0 L 0 100 L 1089 100 L 1089 0")),
                    e.strokeStyle = "#96ebfc",
                    e.stroke(new Path2D("M 50 0 L 50 50 L 1039 50 L 1039 0")),
                    t.HoldHeadHL = await createImageBitmap(e.canvas)
                }
                if (null == t.Hold) {
                    const e = W(1089, 1900);
                    e.lineWidth = 32,
                    e.strokeStyle = "#fff",
                    e.stroke(new Path2D("M 0 0 L 0 1900 M 1089 0 L 1089 1900")),
                    e.strokeStyle = "#96ebfc",
                    e.stroke(new Path2D("M 50 0 L 50 1900 M 1039 0 L 1039 1900")),
                    t.Hold = await createImageBitmap(e.canvas)
                }
                if (null == t.HoldHL) {
                    const e = W(1089, 1900);
                    e.lineWidth = 32,
                    e.strokeStyle = "#fdfd66",
                    e.stroke(new Path2D("M 0 0 L 0 1900 M 1089 0 L 1089 1900")),
                    e.strokeStyle = "#96ebfc",
                    e.stroke(new Path2D("M 50 0 L 50 1900 M 1039 0 L 1039 1900")),
                    t.HoldHL = await createImageBitmap(e.canvas)
                }
                if (null == t.HoldEnd) {
                    const e = W(1089, 100);
                    e.lineWidth = 32,
                    e.strokeStyle = "#fff",
                    e.stroke(new Path2D("M 0 100 L 0 0 L 1089 0 L 1089 100")),
                    e.strokeStyle = "#96ebfc",
                    e.stroke(new Path2D("M 50 100 L 50 50 L 1039 50 L 1039 100")),
                    t.HoldEnd = await createImageBitmap(e.canvas)
                }
                if (null == t.Flick) {
                    const e = W(1089, 300);
                    e.lineWidth = 32,
                    e.strokeStyle = "#fff",
                    e.stroke(new Path2D("M 0 0 L 1089 0 L 1089 300 L 0 300 Z")),
                    e.strokeStyle = "#fe4365",
                    e.stroke(new Path2D("M 50 50 L 1039 50 L 1039 250 L 50 250 Z")),
                    t.Flick = await createImageBitmap(e.canvas)
                }
                if (null == t.FlickHL) {
                    const e = W(1089, 300);
                    e.lineWidth = 32,
                    e.strokeStyle = "#fdfd66",
                    e.stroke(new Path2D("M 0 0 L 1089 0 L 1089 300 L 0 300 Z")),
                    e.strokeStyle = "#fe4365",
                    e.stroke(new Path2D("M 50 50 L 1039 50 L 1039 250 L 50 250 Z")),
                    t.FlickHL = await createImageBitmap(e.canvas)
                }
                if (null == t.Rank) {
                    const e = ["#fffb00", "#a937e7", "#ea61df", "#ff9e22", "#00a844", "#00e8de", "#e4e4e4"],
                    s = [5232301, 4532785, 16267326, 18415150, 16301615, 31491134, 1088575],
                    n = W(256, 1792);
                    for (let t = 0; t < 7; t++) {
                        n.fillStyle = "#fff",
                        n.fillRect(0, 256 * t, 256, 256),
                        n.fillStyle = "#303030",
                        n.fillRect(16, 256 * t + 16, 224, 224),
                        n.fillStyle = e[t];
                        const i = s[t],
                        a = 32,
                        o = (256 - 5 * a) / 2;
                        for (let e = 0; e < 25; e++)
                            if (i >> e & 1) {
                                const s = o + e % 5 * a,
                                i = o + Math.floor(e / 5) * a + 256 * t;
                                n.fillRect(s, i, a, a)
                            }
                    }
                    t.Rank = await createImageBitmap(n.canvas)
                }
                if (null == t.HitFXRaw) {
                    const e = W(256, 7680);
                    e.strokeStyle = "#fff";
                    for (let t = 0; t < 30; t++) {
                        const s = t / 30;
                        e.lineWidth = (1 - s) ** 2 * 25,
                        e.globalAlpha = 1 - s;
                        const n = s ** .2 * 224;
                        e.strokeRect(128 - n / 2, 256 * t + 128 - n / 2, n, n)
                    }
                    t.HitFXRaw = await createImageBitmap(e.canvas)
                }
                if (null == t.LevelOver1) {
                    const e = W(1716, 325);
                    e.fillStyle = "#000",
                    e.globalAlpha = .8,
                    e.fillRect(0, 0, 1716, 325),
                    e.fillStyle = "#989898",
                    e.fillRect(0, 94, 1716, 137),
                    e.globalAlpha = 1,
                    e.fillStyle = "white",
                    e.textAlign = "right",
                    e.font = "bold 30px Custom",
                    e.fillText("ACC:", 240, 172),
                    e.fillText("Max combo:", 1420, 172),
                    e.textAlign = "center",
                    e.font = "bold 22px Custom",
                    e.fillText("Perfect", 788, 304),
                    e.fillText("Good", 942, 304),
                    e.fillText("Bad", 1096, 304),
                    e.fillText("Miss", 1250, 304),
                    t.LevelOver1 = await createImageBitmap(e.canvas)
                }
                if (null == t.LevelOver4) {
                    const e = W(633, 122),
                    s = e.createLinearGradient(24, 0, 633, 0);
                    s.addColorStop(0, "rgba(0,0,0,0.78125)"),
                    s.addColorStop(1, "rgba(0,0,0,0)"),
                    e.fillStyle = s,
                    e.fillRect(24, 24, 609, 72),
                    t.LevelOver4 = await createImageBitmap(e.canvas)
                }
                if (null == t.LevelOver5) {
                    const e = W(11, 43);
                    e.fillStyle = "#fff",
                    e.fillRect(3, 1, 7, 40),
                    t.LevelOver5 = await createImageBitmap(e.canvas)
                }
                const i = ["HitFXRaw", "Rank", "LevelOver1", "LevelOver3", "LevelOver4", "LevelOver5"];
                for (const e of i)
                    null == t[e] && (t[e] = await createImageBitmap(W(1, 1).canvas));
                if (null == t.JudgeLine) {
                    const e = W(1920, 3);
                    e.fillStyle = "#fff",
                    e.fillRect(0, 0, 1920, 3),
                    t.JudgeLine = await createImageBitmap(e.canvas)
                }
                if (null == t.ProgressBar) {
                    const e = W(1919, 11);
                    e.fillStyle = "#919191",
                    e.fillRect(0, 0, 1916, 11),
                    e.fillStyle = "#fff",
                    e.fillRect(1916, 0, 3, 11),
                    t.ProgressBar = await createImageBitmap(e.canvas)
                }
                null == t.HitSong0 && (t.HitSong0 = V.triangle(.075, 880, .5)),
                null == t.HitSong1 && (t.HitSong1 = V.triangle(.05, 1318, .5)),
                null == t.HitSong2 && (t.HitSong2 = V.triangle(.075, 1760, .5)),
                null == t.LevelOver0_v1 && (t.LevelOver0_v1 = V.noise(27.83)),
                null == t.LevelOver1_v1 && (t.LevelOver1_v1 = V.noise(27.83)),
                null == t.LevelOver2_v1 && (t.LevelOver2_v1 = V.noise(27.83)),
                null == t.LevelOver3_v1 && (t.LevelOver3_v1 = V.noise(27.83))
            }
            (e, ls),
            await Promise.all(["Tap", "TapHL", "Drag", "DragHL", "HoldHead", "HoldHeadHL", "Hold", "HoldHL", "HoldEnd", "Flick", "FlickHL"].map((async t => Fs.update(t, ls[t], 8080 / Number(e.image[t].split("|")[1]))))),
            await Fs.updateFX(ls.HitFXRaw, 8080 / Number(e.image.HitFXRaw.split("|")[1])),
            ls.NoImageBlack = await createImageBitmap(new ImageData(new Uint8ClampedArray(4).fill(0), 1, 1)),
            ls.NoImageWhite = await createImageBitmap(new ImageData(new Uint8ClampedArray(4).fill(255), 1, 1)),
            ls.JudgeLineMP = await te(ls.JudgeLine, "#feffa9"),
            ls.JudgeLineFC = await te(ls.JudgeLine, "#a2eeff"),
            ls.Ranks = await se(ls.Rank),
            ls.Rank.close(),
            ls.mute = V.mute(1),
            0 !== (() => {
                const e = W(1, 1);
                return e.drawImage(ls.JudgeLine, 0, 0),
                e.getImageData(0, 0, 1, 1).data[0]
            })() ? (vt("等待上传文件..."), tips(), De.classList.remove("disabled"), ht.classList.remove("disabled"), Ct.dispatchEvent(new CustomEvent("change"))) : wt("检测到图片加载异常，请关闭所有应用程序然后重试")
        })()
    }), {
    once: !0
});
const Ps = {
    isBlur: !1,
    image: null,
    getImage() {
        return this.image ? this.image.base : ls.NoImageWhite
    },
    getImageBlur() {
        return this.image ? this.isBlur ? this.image.blur : this.image.base : ls.NoImageWhite
    }
};
function Ns(e, t) {
    const s = 1 - ft(1.5 * ns.second);
    for (const n of app.linesReversed)
        if (e ^ Number(n.imageD) && ns.second < .67) {
            ctxos.globalAlpha = n.alpha,
            ctxos.setTransform(n.cosr * s, n.sinr, -n.sinr * s, n.cosr, app.wlen + (n.offsetX - app.wlen) * s, n.offsetY);
            const e = (n.imageU ? 18.75 * t : canvasos.height) * n.imageS / 1080,
            i = e * n.imageW * n.imageA,
            a = e * n.imageH;
            if (!hideLine) ctxos.drawImage(n.imageL[n.imageC && He.checked ? yt.lineStatus : 0], -i / 2, -a / 2, i, a)
        }
    ctxos.globalAlpha = 1
}
function js(e, t, s, n, i) {
    ctxos.font = `${n}px Custom,Noto Sans SC`;
    const a = ctxos.measureText(e).width;
    return a > i && (ctxos.font = n / a * i + "px Custom,Noto Sans SC"),
    ctxos.fillText(e, t, s),
    a
}
function Os(e) {
    return e < 0 ? 0 : e > 1 ? 1 : e
}
function $s(e) {
    const t = e.isMulti && app.multiHint,
    s = app.noteScaleRatio;
    !e.visible || e.scored && null == e.badTime || (ctxos.setTransform(s * e.cosr, s * e.sinr, -s * e.sinr, s * e.cosr, e.offsetX, e.offsetY), null == e.badTime ? (ctxos.globalAlpha = e.alpha || (e.showPoint && Xt.checked ? .45 : 0), gt.awawa && (ctxos.globalAlpha *= Math.max(1 + (us - e.seconds) / 1.5, 0)), Fs.note[t ? "TapHL" : "Tap"].full(ctxos)) : (ctxos.globalAlpha = 1 - Os((performance.now() - e.badTime) / 500), Fs.note.TapBad.full(ctxos)))
}
function Hs(e) {
    const t = e.isMulti && app.multiHint,
    s = app.noteScaleRatio;
    !e.visible || e.scored && null == e.badTime || (ctxos.setTransform(s * e.cosr, s * e.sinr, -s * e.sinr, s * e.cosr, e.offsetX, e.offsetY), null == e.badTime && (ctxos.globalAlpha = e.alpha || (e.showPoint && Xt.checked ? .45 : 0), gt.awawa && (ctxos.globalAlpha *= Math.max(1 + (us - e.seconds) / 1.5, 0)), Fs.note[t ? "DragHL" : "Drag"].full(ctxos)))
}
function Xs(e, t) {
    const s = e.isMulti && app.multiHint,
    n = app.noteScaleRatio;
    if (!e.visible || e.seconds + e.holdSeconds < t)
        return;
    ctxos.globalAlpha = e.alpha || (e.showPoint && Xt.checked ? .45 : 0),
    gt.awawa && (ctxos.globalAlpha *= Math.max(1 + (us - e.seconds) / 1.5, 0)),
    ctxos.setTransform(n * e.cosr, n * e.sinr, -n * e.sinr, n * e.cosr, e.offsetX, e.offsetY);
    const i = app.scaleY / n * e.speed * app.speed,
    a = i * e.holdSeconds;
    e.seconds > t ? (Fs.note[s ? "HoldHeadHL" : "HoldHead"].head(ctxos), Fs.note[s ? "HoldHL" : "Hold"].body(ctxos, -a, a)) : Fs.note[s ? "HoldHL" : "Hold"].body(ctxos, -a, a - i * (t - e.seconds)),
    Fs.note.HoldEnd.tail(ctxos, -a)
}
function Ys(e) {
    const t = e.isMulti && app.multiHint,
    s = app.noteScaleRatio;
    !e.visible || e.scored && null == e.badTime || (ctxos.setTransform(s * e.cosr, s * e.sinr, -s * e.sinr, s * e.cosr, e.offsetX, e.offsetY), null == e.badTime && (ctxos.globalAlpha = e.alpha || (e.showPoint && Xt.checked ? .45 : 0), gt.awawa && (ctxos.globalAlpha *= Math.max(1 + (us - e.seconds) / 1.5, 0)), Fs.note[t ? "FlickHL" : "Flick"].full(ctxos)))
}
ze.addEventListener("change", (() => {
        Ps.isBlur = ze.checked
    })), ze.dispatchEvent(new Event("change"));
const _s = new Map;
class zs {
    constructor(e) {
        t(this, "image"),
        t(this, "imageFC"),
        t(this, "imageAP"),
        t(this, "imageMP"),
        this.image = e,
        this.imageFC = null,
        this.imageAP = null,
        this.imageMP = null
    }
    async getFC() {
        return null == this.imageFC && (this.imageFC = await te(this.image, "#a2eeff")),
        this.imageFC
    }
    async getAP() {
        return this.imageAP = await Promise.resolve(null),
        this.imageAP
    }
    async getMP() {
        return null == this.imageMP && (this.imageMP = await te(this.image, "#feffa9")),
        this.imageMP
    }
}
const Us = e => {
    const t = _s.get(e) || new zs(e);
    return _s.has(e) || _s.set(e, t),
    t
};
function Vs(e = 0) {
    let t = e;
    return t < 1024 ? `${t}B` : (t /= 1024) < 1024 ? `${t.toFixed(2)}KB` : (t /= 1024) < 1024 ? `${t.toFixed(2)}MB` : (t /= 1024) < 1024 ? `${t.toFixed(2)}GB` : (t /= 1024) < 1024 ? `${t.toFixed(2)}TB` : (t /= 1024) < 1024 ? `${t.toFixed(2)}PB` : (t /= 1024) < 1024 ? `${t.toFixed(2)}EB` : (t /= 1024) < 1024 ? `${t.toFixed(2)}ZB` : (t /= 1024) < 1024 ? `${t.toFixed(2)}YB` : (t /= 1024, `${t}BB`)
}
async function qs() {
    if (Ct.eq("stop")) {
        if (!Je.value)
            return void gt.error("未选择任何谱面");
        for (const e of gt.before.values())
            await e();
        const e = It.get(We.value) || {
            audio: null,
            video: null
        };
        app.bgMusic = e.audio,
        app.bgVideo = e.video,
        app.prerenderChart(gt.modify(Dt.get(Je.value)));
		for (const i in app.notes) app.notes[i].index = Number(i);
        const t = Ft.get(Je.value),
        s = Pt.get(Je.value);
        yt.level = it.getLevelNumber(),
        null != app.chart && yt.reset(app.chart.numOfNotes, t, s, Ge.value), await async function ({
            onwarn: e = e => {}
        } = {}) {
            var t;
            for (const e of app.lines)
                e.imageW = 6220.8, e.imageH = 7.68, e.imageL = [ls.JudgeLine, ls.JudgeLineMP, null, ls.JudgeLineFC], e.imageS = 1, e.imageA = 1, e.imageD = !1, e.imageC = !0, e.imageU = !0;
            for (const s of Nt)
                if (Je.value === s.chart) {
                    if (null == s.lineId) {
                        e("未指定判定线id");
                        continue
                    }
                    const n = app.lines[Number(s.lineId)];
                    if (null == n) {
                        e(`指定id的判定线不存在：${s.lineId}`);
                        continue
                    }
                    let i = null == s.image ? null : null == (t = Rt.get(s.image)) ? void 0 : t.base;
                    i || (null != s.image && e(`图片不存在：${s.image}`), i = ls.NoImageBlack),
                    n.imageW = i.width,
                    n.imageH = i.height;
                    const a = Us(i);
                    n.imageL = await Promise.all([i, a.getMP(), a.getAP(), a.getFC()]),
                    null != s.scaleOld && (n.imageS = 1080 * Math.abs(s.scaleOld) / i.height, n.imageU = s.scaleOld > 0),
                    null != s.scale && (n.imageS = s.scale),
                    null != s.aspect && (n.imageA = s.aspect),
                    null != s.useBackgroundDim && (n.imageD = s.useBackgroundDim),
                    null != s.useLineColor && (n.imageC = s.useLineColor),
                    null != s.useLineScale && (n.imageU = s.useLineScale)
                }
        }
        ({
            onwarn: bt
        }),
        ps = app.duration / app.speed,
        gs = !1,
        ms = !1,
        vs = !1,
        fs = 0,
        Ye.checked || qwqIn.addTime(3e3),
        V.play(ls.mute, {
            loop: !0
        }),
        xs.start(),
        qwqIn.play(),
        Is.activate(),
        Ct.emit("play")
		if (save) {
			for (const i in saveData.addCombo) {
			    if (saveData.addCombo[i] == null || (saveData.addCombo[i][0] % 4 == 2 && autoSave)) {
			        saveData.addCombo.splice(i, saveData.addCombo.length - i);
			        continue;
			    }
			    yt.addCombo(saveData.addCombo[i][0], saveData.addCombo[i][1]);
			    app.notes[i].scored = !0;
			}
			window.addCombo = JSON.parse(JSON.stringify(saveData.addCombo));
		}
		setTimeout(() => {
			if (save) {
				const time = app.notes[saveData.addCombo.length].seconds - 0.5;
				gt.time = time < saveData.time ? time : saveData.time;
			} else gt.time = startTime;
		}, 50);
    } else {
        Ct.emit("stop"),
        Is.deactive(),
        V.stop(),
        xs.stop(),
        Ls = !1,
        Ss = null,
        Rs.clear(),
        Cs.clear(),
        As.clear(),
        qwqIn.reset(),
        ns.reset(),
        is.reset(),
        hs = 0,
        ds = 0,
        ps = 0;
        for (const e of gt.end.values())
            await e()
    }
}
async function Ws() {
    Ct.eq("stop") || Ls || (Ct.eq("play") ? (null != app.bgVideo && app.bgVideo.pause(), qwqIn.pause(), Ye.checked && ms && ns.pause(), hs = fs, V.stop(), V.play(ls.mute, {loop: !0}), Ct.emit("pause")) : (null != app.bgVideo && await Ms(app.bgVideo, fs * app.speed), qwqIn.play(), Ye.checked && ms && ns.play(), gs && !ms && Ts(app.bgMusic, fs * app.speed), Ct.emit("play")))
}
at.addEventListener("change", (e => {
        const t = Number(e.target.value);
        app.musicVolume = Math.min(1, 1 / t),
        app.soundVolume = Math.min(1, t),
        V.test((() => {
                bs.gainNode.gain.value = app.musicVolume,
                ws.gainNode.gain.value = app.soundVolume
            }))
    })), Ot.reg("selectVolume", at), Xe.addEventListener("change", (e => {
        app.playMode = e.target.checked ? 1 : 0
    })), Xe.dispatchEvent(new Event("change")), zt.checkbox.addEventListener("change", (e => {
        app.setLowResFactor(e.target.checked ? .5 : 1)
    })), zt.checkbox.dispatchEvent(new Event("change")), Ue.onchange = () => {
    const e = Rt.get(Ue.value);
    Ps.image = e || null,
    e && e.setBlur()
}, Je.addEventListener("change", Zt), function () {
    const e = document.createElement("input");
    Object.assign(e, {
        type: "number",
        min: 25,
        max: 1e3,
        value: 60
    }),
    e.style.cssText += ";width:50px;margin-left:10px",
    e.addEventListener("change", (function () {
            const e = Number(this.value);
            e < 25 && (this.value = "25"),
            e > 1e3 && (this.value = "1000"),
            xs.setFrameRate(Number(this.value))
        })),
    Ot.reg("maxFrameNumber", e, !1),
    Vt.container.appendChild(e),
    Vt.checkbox.addEventListener("change", (function () {
            e.classList.toggle("disabled", !this.checked),
            this.checked ? e.dispatchEvent(new Event("change")) : xs.setFrameRate(0)
        })),
    Vt.checkbox.dispatchEvent(new Event("change"))
}
(), Ct.addEventListener("change", (function () {
        Lt.classList.toggle("fade", this.eq("stop")),
        dt.classList.toggle("fade", this.ne("stop")),
        Ve.value = this.eq("stop") ? "播放" : "停止",
        qe.value = this.eq("pause") ? "继续" : "暂停",
        qe.classList.toggle("disabled", this.eq("stop"));
        for (const e of document.body.querySelectorAll(".disabled-when-playing"))
            e.classList.toggle("disabled", this.ne("stop"))
    })), Ve.addEventListener("click", (function () {
		if (!Ge.selectedIndex) window.reverse.on();
		else window.reverse.off();
		tips();
        (async() => {
            this.classList.contains("disabled") || (this.classList.add("disabled"), await qs(), this.classList.remove("disabled"))
        })()
    })), qe.addEventListener("click", (function () {
        (async() => {
            this.classList.contains("disabled") || (this.classList.add("disabled"), await Ws(), this.classList.remove("disabled"))
        })()
    })), $e.addEventListener("input", (function () {
        const e = Number(this.value);
        e < -400 && (this.value = "-400"),
        e > 600 && (this.value = "600")
    })), At.reg(Ct, "change", (() => gt.awawa ? "Reversed" : "")), At.reg(Ze, "change", (e => ["", "FlipX", "FlipY", "FlipX&Y"][Number(e.value)])), At.reg(Ge, "change", (e => e.value)), At.reg(Ct, "change", (e => e.eq("pause") ? "Paused" : ""));
const Js = (e, t) => {
    Ke.addEventListener("input", ((e, t) => {
            let s = 0;
            return () => {
                clearTimeout(s),
                s = self.setTimeout(e, 1e3)
            }
        })((() => {
                Ke.value === e && (t(), Ke.value = "", Ke.dispatchEvent(new Event("input")))
            })))
}, Zs = (e, t) => new ne(e).appendBefore($t.container).hook(t);
gt.fireModal = function (e = "", t = "") {
    const s = document.createElement("div");
    s.classList.add("cover-dark", "fade");
    const n = document.createElement("div");
    n.classList.add("cover-view", "fade");
    const i = document.createElement("div");
    i.classList.add("view-nav"),
    "string" == typeof e ? i.innerHTML = e : i.appendChild(e);
    const a = document.createElement("div");
    return a.classList.add("view-content"),
    "string" == typeof t ? a.innerHTML = t : a.appendChild(t),
    a.addEventListener("custom-done", (() => s.click())),
    n.append(i, a),
    requestAnimationFrame((() => {
            me(".main").append(s, n),
            requestAnimationFrame((() => {
                    s.classList.remove("fade"),
                    n.classList.remove("fade")
                }))
        })),
    s.addEventListener("click", (() => {
            s.classList.add("fade"),
            s.addEventListener("transitionend", (() => {
                    s.remove()
                })),
            n.classList.add("fade"),
            n.addEventListener("transitionend", (() => {
                    n.remove()
                }))
        })),
    a
}, gt.toast = (e = "") => gt.fireModal("<p>提示</p>", `<p style="white-space:pre;text-align:left;display:inline-block;">${e}</p>`), gt.error = (e = "") => gt.fireModal("<p>错误</p>", `<p style="white-space:pre;text-align:left;display:inline-block;">${e}</p>`), gt.define = e => e, gt.use = async e => {
    const t = await e.then((e => e.default));
    for (const e of t.contents)
        if ("command" === e.type)
            Js(e.meta[0], e.meta[1]);
        else if ("script" === e.type)
            e.meta[0](me);
        else {
            if ("config" !== e.type)
                throw new TypeError(`Unknown Plugin Type: ${e.type}`);
            Zs(e.meta[0], e.meta[1])
        }
    return console.log(t), t
}, self.hook = gt;
const Gs = gt;
gt.stat = yt, gt.app = app, gt.res = ls, gt.audio = V, gt.sendText = vt, gt.sendWarning = bt, gt.sendError = wt, gt.frameAnimater = xs, gt.timeEnd = is, gt.bgms = It, gt.inputName = Ke, gt.selectbgm = We, gt.selectchart = Je, gt.chartsMD5 = Ft, gt.noteRender = Fs, gt.reader = D, gt.ZipReader = R, gt.status = Ot, gt.tmps = Es, gt.awawa = !1, gt.pause = async() => Ct.eq("play") && Ws(), Object.defineProperty(gt, "playing", {
    get: () => Ct.eq("play")
}), Object.defineProperty(gt, "time", {
    get: () => fs,
    set(e) {
        (async() => {
            if (Ct.eq("stop") || Ls || e > ps || e < 0)
                return;
            const t = Ct.eq("play");
            t && await Ws(),
            fs = e,
            hs = fs,
            app.seekLineEventIndex(),
            t && await Ws().catch((e => console.error(e)))
        })()
    }
});
const Ks = {
    color: "black",
    value: 0,
    setValueCurve(...e) {
        if (!(e.length &= -2))
            return;
        const t = performance.now(),
        s = this.value;
        requestAnimationFrame((function n(i) {
                const a = requestAnimationFrame(n);
                let o = .001 * (i - t);
                o < 0 && (o = 0);
                for (let t = 0; t < e.length; t += 2) {
                    if (o < e[t]) {
                        const n = 0 === t ? s : e[t - 1],
                        i = e[t + 1];
                        return void(Ks.value = n + (i - n) * o / e[t])
                    }
                    o -= e[t]
                }
                o >= 0 && (Ks.value = e[e.length - 1], cancelAnimationFrame(a))
            }))
    }
};
gt.cover = Ks, gt.afterAll.set("main::cover", (() => {
        Ks.value > 0 && (St.fillStyle = Ks.color, St.globalAlpha = Ks.value, St.fillRect(0, 0, Lt.width, Lt.height))
    })), new URLSearchParams(location.search).has("iframe") && (document.body.classList.add("iframe"), xt.setFull(!0), xt.resize(), as.func[3] = async() => Promise.resolve(window.parent.postMessage("full", "*"))), self.onmessage = e => {
    if (console.log("onmessage", e), e.data instanceof File) {
        const t = new FileReader;
        t.readAsArrayBuffer(e.data),
        t.onload = () => {
            Gt.fireLoad(e.data, t.result)
        }
    } else
        "play" === e.data && qs()
};


window.randomNote = () => {
    const rand = 1 + Math.random() * (tap + drag + hold + flick - 1 + 1) | 0;
    if (0 < rand && rand <= tap) return 1;
    if (tap < rand && rand <= tap + drag) return 2;
    if (tap + drag < rand && rand <= tap + drag + hold) return 3;
    if (tap + drag + hold < rand && rand <= tap + drag + hold + flick) return 4;
}

window.createSave = () => {
	saveData.addCombo = JSON.parse(JSON.stringify(window.addCombo));
	saveData.time = gt.time;
}

setInterval(() => {
	if (save && autoSave && gt.time > 1) createSave();
	if (Math.floor(ps) == Math.floor(gt.time) && ps != 0 && !Ls) stop();
}, 500);

window.stop = () => {	
	V.stop();
	qe.classList.add("disabled");
	ctxos.globalCompositeOperation = "source-over";
	ctxos.resetTransform();
	ctxos.globalAlpha = 1;
	const e = Ps.getImageBlur();
	ctxos.drawImage(e, ...ce(e, canvasos, 1));
	ctxos.fillStyle = "#000";
	ctxos.globalAlpha = app.brightness;
	ctxos.fillRect(0, 0, canvasos.width, canvasos.height);
	Ls = !0;
	setTimeout(() => {
	    const e = it.getDifficultyIndex();
	    bs.play(ls[`LevelOver${e<0?2:e}_v1`], {
	        loop: !0
	    })
	    is.reset();
	    is.play();
	    yt.level = it.getLevelNumber();
	    Ss = yt.getData(1 === app.playMode || test, Ge.value);
	}, 1e3);
}

window.app = app;
window.qwqIn = qwqIn;
window.Ls = Ls;
window.gt = gt;
window.Kt = Kt;

window.exports = {
	o: h,
	p: r,
	r: D,
	s: F,
	a: v,
	b: b,
	c: w,
	m: C,
	I: Z,
	d: l,
	w: (e, o) => {
	    const t = new MutationObserver((() => {
	                const n = document.getElementById(e);
	                n && (console.log(n), o(n), t.disconnect())
	            }));
	    t.observe(document.body, {
	        childList: !0,
	        subtree: !0
	    });
	}
}

const fuck = () => {
	if (fuckMode) {
			const a = ge('select-flip')
			a.value = a.value == '2' ? '0' : '2';
			a.selectedIndex = a.value;
			app.mirrorView(Number(a.value))
	}
}

const bb = ge('betterBlur');
window.rt = Rt

const xhr = new XMLHttpRequest;
xhr.open('get', './src/image/Pause.png');
xhr.responseType = 'arraybuffer';
xhr.send();
xhr.onload = () => {
	createImageBitmap(new Blob([xhr.response])).then((e)=>{
		window.pause = e
	})
}