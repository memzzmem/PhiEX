const e = hook.define({
    name: "Gauge",
    description: "Apply gauge",
    contents: [{
            type: "config",
            meta: ["启用收集条", function (e, s) {
                    e.addEventListener("change", (() => {
                            e.checked ? (hook.now.set("gauge", h), hook.after.set("gauge", c)) : (hook.now.delete("gauge"), hook.after.delete("gauge"))
                        })),
                    t.reg("enableGauge", e)
                }
            ]
        }
    ]
}), {
    status: t,
    stat: s,
    app: a
} = hook, o = [null, 0, 0, 0, 0, 0, 0, 0];
let i = 0, n = 0;
const d = {
    value: 100,
    delta: -1,
    speedInit: 0,
    speed: 0,
    speed2: 0,
    factor: .5,
    factor2: Math.SQRT1_2,
    dead: !1,
    tick(e) {
        this.dead || (this.delta = this.speedInit * e, this.delta += this.speed * (1 - this.factor ** e), this.delta += this.speed2 * (1 - this.factor2 ** e), this.value = Math.min(100, this.value + this.delta), this.delta /= e || 1 / 0, this.value <= 0 && (this.dead = !0), this.speed *= this.factor ** e, this.speed2 *= this.factor2 ** e)
    },
    reset() {
        this.value = 100,
        this.delta = -1,
        this.speedInit = 0,
        this.speed = 0,
        this.speed2 = 0,
        this.factor = .5,
        this.factor2 = Math.SQRT1_2,
        this.dead = !1
    }
};
function h(e) {
    if (o[0] !== a.chart && function () {
        const {
            chart: e
        } = a;
        d.reset(),
        i = function (e, t) {
            let a = 0;
            return a = e < 400 ? 80 / e + .2 : e < 600 ? 32 / e + .2 : 96 / e + .08,
            s.level >= 16 && (a *= .8),
            a
        }
        (e.numOfNotes),
        d.speedInit = -i * e.numOfNotes / (a.duration + .5),
        console.log("initGauge"),
        o[0] = e;
        for (let e = 1; e < 8; e++)
            o[e] = s.noteRank[e]
    }
        (), d.dead) {
        for (const e of a.notes)
            e.scored || (e.status = 2, s.addCombo(2, e.type), e.scored = !0);
        return void(hook.time = a.duration)
    }
    const {
        noteRank: t
    } = s;
    t[6] > o[6] && (d.speed2 -= 18),
    t[5] > o[5] && (d.speed += i * (t[5] - o[5])),
    t[4] > o[4] && (d.speed += i * (t[4] - o[4]) * 2),
    t[1] > o[1] && (d.speed += i * (t[1] - o[1])),
    t[2] > o[2] && (d.speed2 -= 18);
    for (let e = 1; e < 8; e++)
        o[e] = s.noteRank[e];
    hook.playing && d.tick(e - n),
    n = e
}
function c() {
    const e = d.value / 100,
    t = d.delta,
    s = `rgba(${255*f(-t)},${255*f(1+t)},${255*f(1+t)},1)`;
    l("#3f3b71", 1),
    l(s, e)
}
function l(e, t) {
    const {
        ctxfg: s,
        canvasfg: o,
        lineScale: i
    } = a;
    s.fillStyle = e,
    s.fillRect(o.width / 2 - 6 * i * f(t), .2 * i, 12 * i * f(t), .2 * i)
}
function f(e) {
    return e < 0 ? 0 : e > 1 ? 1 : e
}
export {
    e as default
};