function e(e) {
    const t = JSON.parse(JSON.stringify(e)),
    n = [{
            startTime: -999999,
            endTime: 0,
            start: t[0] ? t[0].start : 0,
            end: t[0] ? t[0].start : 0,
            start2: t[0] ? t[0].start2 : 0,
            end2: t[0] ? t[0].start2 : 0
        }
    ];
    t.push({
        startTime: 0,
        endTime: 1e9,
        start: t[t.length - 1] ? t[t.length - 1].end : 0,
        end: t[t.length - 1] ? t[t.length - 1].end : 0,
        start2: t[t.length - 1] ? t[t.length - 1].end2 : 0,
        end2: t[t.length - 1] ? t[t.length - 1].end2 : 0
    });
    for (const e of t) {
        const t = n[n.length - 1];
        e.startTime > e.endTime || t.endTime > e.endTime || (t.endTime === e.startTime ? n.push(e) : t.endTime < e.startTime ? n.push({
                startTime: t.endTime,
                endTime: e.startTime,
                start: t.end,
                end: t.end,
                start2: t.end2,
                end2: t.end2
            }, e) : t.endTime > e.startTime && n.push({
                startTime: t.endTime,
                endTime: e.endTime,
                start: (e.start * (e.endTime - t.endTime) + e.end * (t.endTime - e.startTime)) / (e.endTime - e.startTime),
                end: t.end,
                start2: (e.start2 * (e.endTime - t.endTime) + e.end2 * (t.endTime - e.startTime)) / (e.endTime - e.startTime),
                end2: t.end2
            }))
    }
    const s = [n.shift()];
    for (const e of n) {
        const t = s[s.length - 1],
        n = t.endTime - t.startTime,
        o = e.endTime - e.startTime;
        e.startTime === e.endTime || (t.end === e.start && t.end2 === e.start2 && (t.end - t.start) * o == (e.end - e.start) * n && (t.end2 - t.start2) * o == (e.end2 - e.start2) * n ? (t.endTime = e.endTime, t.end = e.end, t.end2 = e.end2) : s.push(e))
    }
    return JSON.parse(JSON.stringify(s))
}
function t(e, t) {
    const n = e.end;
    e.end = e.start,
    e.start = n;
    const s = e.end2;
    e.end2 = e.start2,
    e.start2 = s;
    const o = t - e.endTime;
    e.endTime = t - e.startTime,
    e.startTime = o
}
function n(e, t) {
    e.time = t - e.time,
    3 === e.type && (e.speed *= e.holdTime, e.holdTime = 1)
}
function s(e, t) {
    const n = t - e.endTime;
    e.endTime = t - e.startTime,
    e.startTime = n
}
function o(e) {
    let t = 0;
    e.speedEvents.sort(((e, t) => e.startTime - t.startTime));
    for (const n of e.speedEvents)
        n.startTime < 0 && (n.startTime = 0), n.floorPosition = t, t += (n.endTime - n.startTime) * n.value / e.bpm * 1.875;
    e.speedEvents[e.speedEvents.length - 1].endTime = 1e9;
    for (const t of e.notesAbove) {
        let n = 0,
        s = 0,
        o = 0;
        for (const i of e.speedEvents)
            if (!(t.time % 1e9 > i.endTime)) {
                if (t.time % 1e9 < i.startTime)
                    break;
                n = i.floorPosition,
                s = i.value,
                o = t.time % 1e9 - i.startTime
            }
        t.floorPosition = n + s * o / e.bpm * 1.875
    }
    for (const t of e.notesBelow) {
        let n = 0,
        s = 0,
        o = 0;
        for (const i of e.speedEvents)
            if (!(t.time % 1e9 > i.endTime)) {
                if (t.time % 1e9 < i.startTime)
                    break;
                n = i.floorPosition,
                s = i.value,
                o = t.time % 1e9 - i.startTime
            }
        t.floorPosition = n + s * o / e.bpm * 1.875
    }
}
function i(t) {
    t.judgeLineDisappearEvents.sort(((e, t) => e.startTime - t.startTime)),
    t.judgeLineMoveEvents.sort(((e, t) => e.startTime - t.startTime)),
    t.judgeLineRotateEvents.sort(((e, t) => e.startTime - t.startTime)),
    t.judgeLineDisappearEvents = e(t.judgeLineDisappearEvents),
    t.judgeLineMoveEvents = e(t.judgeLineMoveEvents),
    t.judgeLineRotateEvents = e(t.judgeLineRotateEvents)
}
let r = 0;
function a(r, a) {
    const d = r.duplicate();
    d.offset = -d.offset;
    for (const r of d.judgeLineList) {
        const d = a * r.bpm / 1.875;
        for (const e of r.speedEvents)
            s(e, d);
        for (const e of r.notesAbove)
            n(e, d);
        for (const e of r.notesBelow)
            n(e, d);
        o(r),
        r.judgeLineDisappearEvents = e(r.judgeLineDisappearEvents),
        r.judgeLineMoveEvents = e(r.judgeLineMoveEvents),
        r.judgeLineRotateEvents = e(r.judgeLineRotateEvents);
        for (const e of r.judgeLineDisappearEvents)
            t(e, d);
        for (const e of r.judgeLineMoveEvents)
            t(e, d);
        for (const e of r.judgeLineRotateEvents)
            t(e, d);
        i(r)
    }
    return d.duplicate()
}
hook.before.set("kfcFkXqsVw50", (() => {
        const e = hook.bgms.get(hook.selectbgm.value).audio;
        if (null != e && lastmode != r) {
			for (let t = 0; t < e.numberOfChannels; t++) e.getChannelData(t).reverse();
			lastmode = r;
		}
        hook.awawa = r,
        hook.modify = hook.awawa ? e => a(e, hook.app.duration) : e => e
    })), function () {
    const e = document.querySelector(".title");
    if (!(e instanceof HTMLElement))
        return;
    let t = NaN;
    const n = () => (isNaN(t) && (t = performance.now()), e.style.cssText += `;filter:hue-rotate(${(performance.now()-t)/4}deg)`, performance.now() - t > 3473 && 401 * Math.random() < 1 ? 1 : 0);
    !function (e, t, n, s) {
        let o = null;
        function i() {
            o = requestAnimationFrame(i),
            t() && (cancelAnimationFrame(o), n(), e.removeEventListener("mousedown", i), e.removeEventListener("mouseup", r), e.removeEventListener("mouseleave", r), e.removeEventListener("touchstart", i), e.removeEventListener("touchend", r), e.removeEventListener("touchcancel", r))
        }
        function r() {
            cancelAnimationFrame(o),
            s()
        }
        e.addEventListener("mousedown", i),
        e.addEventListener("mouseup", r),
        e.addEventListener("mouseleave", r),
        e.addEventListener("touchstart", i, {
            passive: !0
        }),
        e.addEventListener("touchend", r),
        e.addEventListener("touchcancel", r)
    }
	window.n = n;
    (e, n, (() => {
            hook.fireModal("<p>Tip</p>", "<p>Reverse Mode is on...</p>"),
            r = new Map
        }), (() => {
            e.style.cssText += ";filter:hue-rotate(0deg);",
            t = NaN
        }))
}();

window.lastmode = 0;
window.reverse =  {
	on: () => r = 1,
	off: () => r = 0
}

setInterval(window.n, 20);

export {
    a as reverse
};